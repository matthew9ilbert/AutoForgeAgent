import React from 'react';
import { AlertCircle } from 'lucide-react';

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean, error: Error | null }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Workspace Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full w-full p-4 text-center bg-sf-bg">
          <div className="bg-[#FF453A]/10 p-4 rounded-2xl mb-3">
            <AlertCircle size={48} className="text-[#FF453A]" />
          </div>
          <h2 className="text-xl font-bold mb-2">Workspace Error</h2>
          <p className="text-sm opacity-70 mb-3 max-w-md">
            Something went wrong while rendering this workspace. The issue has been isolated to prevent the IDE from crashing.
          </p>
          <div className="font-mono text-xs bg-black/40 p-4 rounded-xl border border-white/5 text-[#FF453A] max-w-lg overflow-auto">
            {this.state.error?.message}
          </div>
          <button 
            className="btn-primary mt-3"
            onClick={() => this.setState({ hasError: false, error: null })}
          >
            Retry Workspace
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
