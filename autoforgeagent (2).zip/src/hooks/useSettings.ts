import { useState, useEffect } from 'react';

export function useSettings() {
  const [smartRouting, setSmartRoutingState] = useState(() => {
    return localStorage.getItem('sf_smart_routing') !== 'false';
  });

  const setSmartRouting = (enabled: boolean) => {
    localStorage.setItem('sf_smart_routing', enabled ? 'true' : 'false');
    setSmartRoutingState(enabled);
  };

  return { smartRouting, setSmartRouting };
}
