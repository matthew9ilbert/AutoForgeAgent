import { useEffect } from 'react';
import { useWorkspacePresets } from './useWorkspacePresets';
import { useNavigate } from 'react-router';

export function useGlobalShortcuts() {
  const { presets, activatePreset } = useWorkspacePresets();
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid triggering when typing in inputs
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      
      const isCmdOrCtrl = e.metaKey || e.ctrlKey;
      
      // Presets: Cmd/Ctrl + 1-9
      if (isCmdOrCtrl && !e.shiftKey && e.key >= '1' && e.key <= '9') {
        const index = parseInt(e.key) - 1;
        if (index < presets.length) {
          e.preventDefault();
          activatePreset(presets[index].id);
        }
      }
      
      // Agent Actions: Cmd/Ctrl + Shift + C/D/T
      if (isCmdOrCtrl && e.shiftKey) {
        if (e.key.toLowerCase() === 'c') {
          e.preventDefault();
          // Dispatch custom event to open chat
          window.dispatchEvent(new CustomEvent('sf_agent_action', { detail: { action: 'chat' } }));
        } else if (e.key.toLowerCase() === 'd') {
          e.preventDefault();
          window.dispatchEvent(new CustomEvent('sf_agent_action', { detail: { action: 'debug' } }));
        } else if (e.key.toLowerCase() === 't') {
          e.preventDefault();
          window.dispatchEvent(new CustomEvent('sf_agent_action', { detail: { action: 'test' } }));
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [presets, activatePreset, navigate]);
}
