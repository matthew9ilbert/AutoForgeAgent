import { useState, useEffect } from 'react';
import { getFallbackConfig, saveFallbackConfig, saveBackendConfig } from '../utils/configLoader';

export function usePersistedState<T>(key: string, initialValue: T | (() => T)): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [state, setState] = useState<T>(() => {
    try {
      const config = getFallbackConfig() || {};
      const savedValue = config[key];
      if (savedValue !== undefined && savedValue !== null) {
        return savedValue;
      }
    } catch (error) {
      console.warn(`Error reading config key "${key}":`, error);
    }
    return typeof initialValue === 'function' ? (initialValue as () => T)() : initialValue;
  });

  useEffect(() => {
    try {
      const config = getFallbackConfig() || {};
      config[key] = state;
      saveFallbackConfig(config);
      saveBackendConfig(config).catch(e => console.error("Error saving to backend", e));
    } catch (error) {
      console.warn(`Error setting config key "${key}":`, error);
    }
  }, [key, state]);

  return [state, setState];
}
