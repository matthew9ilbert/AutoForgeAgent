import { usePersistedState } from './usePersistedState';

export interface WorkspacePreset {
  id: string;
  name: string;
  workspaces: string[];
}

const defaultPresets: WorkspacePreset[] = [
  { id: 'all', name: 'All Workspaces', workspaces: [] },
  { id: 'dev', name: 'Development', workspaces: ['/', '/testing', '/schema', '/agents', '/kanban'] },
  { id: 'design', name: 'Design', workspaces: ['/', '/ideas', '/visualizer', '/design', '/archive'] },
  { id: 'ops', name: 'Operations', workspaces: ['/', '/auditing', '/profiler', '/migrations', '/rollbacks'] },
  { id: 'security', name: 'Security', workspaces: ['/', '/guardrails', '/a11y', '/testing'] }
];

export function useWorkspacePresets() {
  const [activeId, setActiveId] = usePersistedState<string>('workspace_preset', 'all');

  const activatePreset = (id: string) => {
    setActiveId(id);
  };

  const activePreset = defaultPresets.find(p => p.id === activeId) || defaultPresets[0];

  return {
    presets: defaultPresets,
    activePreset,
    activatePreset
  };
}
