import { useEffect } from 'react';
import { useMonaco } from '@monaco-editor/react';

import { useRef } from 'react';

export function useCodeIntelligence() {
  const monaco = useMonaco();
  const registered = useRef(false);

  useEffect(() => {
    if (!monaco || registered.current) return;
    registered.current = true;

    // Register inline completion provider (ghost text)
    const inlineProvider = monaco.languages.registerInlineCompletionsProvider('typescript', {
      provideInlineCompletions: async (model: any, position: any) => {
        const textUntilPosition = model.getValueInRange({
          startLineNumber: position.lineNumber,
          startColumn: 1,
          endLineNumber: position.lineNumber,
          endColumn: position.column
        });
        
        if (textUntilPosition.trim().endsWith('const test =')) {
          return {
            items: [{
              insertText: ' "AI Ghost Text Example";'
            }]
          };
        }
        return { items: [] };
      },
      freeInlineCompletions: () => {}
    } as any);

    // Register code action provider (auto-repair quick fix)
    const codeActionProvider = monaco.languages.registerCodeActionProvider('typescript', {
      provideCodeActions: (model: any, range: any, context: any, token: any) => {
        const actions = context.markers.map((marker: any) => {
          return {
            title: "🤖 AI Auto-Repair: Fix this issue",
            diagnostics: [marker],
            kind: "quickfix",
            edit: {
              edits: [
                {
                  resource: model.uri,
                  versionId: undefined,
                  textEdit: {
                    range: marker,
                    text: "// 🤖 repaired by AI\n"
                  }
                }
              ]
            },
            isPreferred: true
          };
        });
        return {
          actions: actions as any,
          dispose: () => {}
        };
      }
    });

    const hoverProvider = monaco.languages.registerHoverProvider('typescript', {
      provideHover: (model, position) => {
        const markers = monaco.editor.getModelMarkers({ resource: model.uri });
        const marker = markers.find(m => 
          position.lineNumber >= m.startLineNumber && position.lineNumber <= m.endLineNumber &&
          position.column >= m.startColumn && position.column <= m.endColumn
        );
        if (marker) {
          return {
            range: marker,
            contents: [
              { value: `**Diagnostic**: ${marker.message}` },
              { value: `[✨ Auto-Repair](command:ai.autoRepair)` }
            ]
          };
        }
        return null;
      }
    });

    // We can't register the command here easily without editor instance, but the user can use the quick fix (lightbulb) as well.

  }, [monaco]);
  
  return { monaco };
}
