import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { getAppState, saveAppState } from '../utils/configLoader';

export function useAppSync() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isRestored, setIsRestored] = useState(false);
  const [initialWorkspaceState, setInitialWorkspaceState] = useState<{ activeTab?: string }>({});

  useEffect(() => {
    let mounted = true;
    
    const initSync = () => {
      try {
        const state = getAppState();
        if (state.lastRoute && state.lastRoute !== location.pathname) {
          navigate(state.lastRoute, { replace: true });
        }
        if (state.activeTab) {
          setInitialWorkspaceState({ activeTab: state.activeTab });
        }
        saveAppState({ lastRoute: state.lastRoute || location.pathname });
      } catch (error) {
        console.warn("Failed to load local state:", error);
      } finally {
        if (mounted) setIsRestored(true);
      }
    };
    
    initSync();
    
    return () => { mounted = false; }
  }, []); // Run once on mount

  useEffect(() => {
    if (!isRestored) return;
    saveAppState({ lastRoute: location.pathname });
  }, [location.pathname, isRestored]);

  const updateWorkspaceState = (state: { activeTab?: string }) => {
    if (isRestored) {
      saveAppState(state);
    }
  };

  return { isRestored, initialWorkspaceState, updateWorkspaceState };
}
