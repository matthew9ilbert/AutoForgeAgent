import React, { createContext, useContext, useState, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';
import { toast } from 'sonner';

export interface TaskUpdate {
  message: string;
  task_id: string;
  status: string;
  agent: string;
  timestamp: string;
}

interface SwarmContextType {
  socket: Socket | null;
  activity: TaskUpdate[];
  status: string;
  currentTaskId: string | null;
  tasks: any[];
  agents: any[];
  launchTask: (input: string, projectName: string, enableAider: boolean, enableDocker: boolean) => Promise<void>;
}

const SwarmContext = createContext<SwarmContextType | undefined>(undefined);

export function SwarmProvider({ children }: { children: React.ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [activity, setActivity] = useState<TaskUpdate[]>([]);
  const [status, setStatus] = useState('Ready');
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
  const [tasks, setTasks] = useState<any[]>([]);
  const [agents, setAgents] = useState<any[]>([]);

  useEffect(() => {
    // Determine the API URL correctly. If we're proxying through Vite, we can just use the current host or an environment variable.
    // In our SwarmForge context, it's typically http://localhost:8000
    // But since it might not be running or we want to allow configuration, let's default to localhost:8000.
    const newSocket = io('/', { transports: ['websocket'] });

    newSocket.on('connect', () => {
      console.log('Connected to SwarmForge backend');
    });

    newSocket.on('swarm_update', (data: TaskUpdate) => {
      setActivity(prev => [data, ...prev].slice(0, 100));
      setStatus(data.status);
      
      if (data.status === 'error') {
        toast.error(`${data.agent}: ${data.message}`);
      } else if (data.status === 'completed') {
        toast.success(`${data.agent} completed task.`);
      } else if (data.status === 'intervention') {
        toast.warning(`${data.agent} requires user intervention.`);
      }
    });

    newSocket.on('connect_error', () => {
      // toast.error('Failed to connect to SwarmForge backend. Is it running?');
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const launchTask = async (input: string, projectName: string, enableAider: boolean, enableDocker: boolean) => {
    if (!input.trim()) return;
    try {
      const response = await fetch(`/api/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_input: input,
          project_name: projectName,
          enable_aider: enableAider,
          enable_docker_build: enableDocker
        })
      });
      const data = await response.json();
      setCurrentTaskId(data.task_id);
      toast.success('Task launched successfully!');
    } catch (error) {
      console.error('Task launch failed:', error);
      toast.error('Task launch failed. Simulating autonomous agent activity for demo purposes...');
      
      // Simulation for demo purposes
      setCurrentTaskId('task-' + Date.now());
      
      const agents = ['Swarm Supervisor', 'Core Dev', 'Test Sentinel', 'UI Artisan'];
      
      setTimeout(() => {
        setActivity(prev => [{ message: `Analyzing task: "${input}"`, task_id: 'mock', status: 'running', agent: 'Swarm Supervisor', timestamp: new Date().toISOString() }, ...prev]);
        toast.info('Swarm Supervisor initiated task analysis.');
      }, 1000);
      
      setTimeout(() => {
        setActivity(prev => [{ message: `Identified 3 sub-tasks. Dispatching to Core Dev and UI Artisan.`, task_id: 'mock', status: 'running', agent: 'Swarm Supervisor', timestamp: new Date().toISOString() }, ...prev]);
      }, 3000);
      
      setTimeout(() => {
        setActivity(prev => [{ message: `Drafting initial component structures.`, task_id: 'mock', status: 'running', agent: 'UI Artisan', timestamp: new Date().toISOString() }, ...prev]);
      }, 5000);
      
      setTimeout(() => {
        setActivity(prev => [{ message: `Setting up database schemas and API endpoints.`, task_id: 'mock', status: 'running', agent: 'Core Dev', timestamp: new Date().toISOString() }, ...prev]);
      }, 6000);

      setTimeout(() => {
        setActivity(prev => [{ message: `Dependency resolution failed for 'missing-lib'.`, task_id: 'mock', status: 'error', agent: 'Core Dev', timestamp: new Date().toISOString() }, ...prev]);
        toast.error('Core Dev encountered an error: Dependency resolution failed.');
      }, 8000);

      setTimeout(() => {
        setActivity(prev => [{ message: `Self-healing: Attempting to install missing dependency...`, task_id: 'mock', status: 'running', agent: 'Core Dev', timestamp: new Date().toISOString() }, ...prev]);
      }, 10000);

      setTimeout(() => {
        setActivity(prev => [{ message: `Dependency installed successfully. Resuming build.`, task_id: 'mock', status: 'running', agent: 'Core Dev', timestamp: new Date().toISOString() }, ...prev]);
        toast.success('Core Dev successfully recovered from error.');
      }, 12000);

      setTimeout(() => {
        setActivity(prev => [{ message: `Waiting for user to approve database schema changes.`, task_id: 'mock', status: 'intervention', agent: 'Swarm Supervisor', timestamp: new Date().toISOString() }, ...prev]);
        toast.warning('User intervention required by Swarm Supervisor.');
      }, 15000);

      setTimeout(() => {
        setActivity(prev => [{ message: `Task components completed and verified.`, task_id: 'mock', status: 'completed', agent: 'Test Sentinel', timestamp: new Date().toISOString() }, ...prev]);
        toast.success('Test Sentinel completed verification.');
      }, 20000);

    }
  };

  return (
    <SwarmContext.Provider value={{ socket, activity, status, currentTaskId, tasks, agents, launchTask }}>
      {children}
    </SwarmContext.Provider>
  );
}

export function useSwarm() {
  const context = useContext(SwarmContext);
  if (context === undefined) {
    throw new Error('useSwarm must be used within a SwarmProvider');
  }
  return context;
}
