import React, { useState, useEffect, useRef, useCallback, Suspense, lazy } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router';
import { SwarmProvider } from './contexts/SwarmContext';
import { Toaster, toast } from 'sonner';
import { Layers, MessageSquare, Users, Settings as SettingsIcon, Search as SearchIcon, RefreshCw, Network, Database, Terminal } from 'lucide-react';
import { ErrorBoundary } from './ErrorBoundary';
import { AnimatePresence, motion } from 'motion/react';
import { usePersistedState } from './hooks/usePersistedState';
import { useAppSync } from './hooks/useAppSync';
import { useWorkspacePresets } from './hooks/useWorkspacePresets';
import { useTheme } from './hooks/useTheme';
import { useGlobalShortcuts } from './hooks/useGlobalShortcuts';
import { loadConfig, saveFallbackConfig } from './utils/configLoader';
import { Breadcrumbs } from './components/Breadcrumbs';
import { RightWorkspace } from './components/RightWorkspace';
import { CommandPalette } from './components/CommandPalette';

// Lazy loaded workspace components
const AIChat = lazy(() => import('./components/AIChat').then(m => ({ default: m.AIChat })));
const Kanban = lazy(() => import('./components/Kanban').then(m => ({ default: m.Kanban })));
const Teams = lazy(() => import('./components/Teams').then(m => ({ default: m.Teams })));
const SchemaBuilder = lazy(() => import('./components/SchemaBuilder').then(m => ({ default: m.SchemaBuilder })));
const Installer = lazy(() => import('./components/Installer').then(m => ({ default: m.Installer })));
const Settings = lazy(() => import('./components/Settings').then(m => ({ default: m.Settings })));
const Agents = lazy(() => import('./components/Agents').then(m => ({ default: m.Agents })));
const Testing = lazy(() => import('./components/Testing').then(m => ({ default: m.Testing })));
const Search = lazy(() => import('./components/Search').then(m => ({ default: m.Search })));

function WorkspaceSkeleton() {
  return (
    <div className="flex flex-col gap-3 w-full h-full pb-4 pt-4 animate-pulse">
      <div className="h-12 bg-white/5 rounded-xl w-1/3 mb-3"></div>
      <div className="flex flex-col gap-3">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="flex gap-3 items-center p-4 bg-sf-bg/20 rounded-xl border border-white/5 h-[88px]">
             <div className="w-10 h-10 rounded-lg bg-white/10 shrink-0"></div>
             <div className="flex flex-col gap-2 w-full">
                <div className="h-4 bg-white/10 rounded w-1/4"></div>
                <div className="h-3 bg-white/10 rounded w-1/2"></div>
             </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActivityBar({ isOnline }: { isOnline: boolean }) {
  const location = useLocation();

  const navItems = [
    { label: 'AI Workspace', path: '/', icon: <MessageSquare size={20} /> },
    { label: 'Kanban', path: '/kanban', icon: <Layers size={20} /> },
    { label: 'TDD Loop', path: '/testing', icon: <RefreshCw size={20} /> },
    { label: 'Code Search', path: '/search', icon: <SearchIcon size={20} /> },
    { label: 'Agents', path: '/agents', icon: <Users size={20} /> },
    { label: 'Agentic Workflows', path: '/teams', icon: <Network size={20} /> },
    { label: 'Schema Builder', path: '/schema', icon: <Database size={20} /> },
    { label: 'Installer', path: '/installer', icon: <Terminal size={20} /> },
  ];

  const { activePreset } = useWorkspacePresets();
  const visibleNavItems = activePreset.id === 'all' 
    ? navItems 
    : navItems.filter(item => item.path === '/' || activePreset.workspaces.includes(item.path));


  return (
    <aside className="w-[60px] sm:w-[68px] shrink-0 h-full border-r border-sf-border bg-sf-panel flex flex-col items-center py-4 gap-3 z-20 relative safe-pl overflow-y-auto overflow-x-hidden scrollbar-hide">
      <div className="bg-sf-accent text-white p-2.5 rounded-xl mb-3 shadow-lg shadow-sf-accent/20 shrink-0">
        <Layers size={22} />
      </div>
      
      <div className="flex flex-col gap-3 flex-grow justify-start w-full items-center">
        {visibleNavItems.map((item) => {

          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              title={item.label}
              className={`p-3 rounded-xl transition-all ${
                isActive ? 'bg-sf-accent/20 text-sf-accent border border-sf-accent/30' : 'text-sf-ink/50 hover:bg-white/5 hover:text-sf-ink border border-transparent'
              }`}
            >
              {item.icon}
            </Link>
          );
        })}
      </div>
      
      <div className="mt-auto mb-2 flex flex-col items-center gap-3">
        <Link
          to="/settings"
          title="Settings"
          className={`p-3 rounded-xl transition-all ${
            location.pathname === '/settings' ? 'bg-sf-accent/20 text-sf-accent border border-sf-accent/30' : 'text-sf-ink/50 hover:bg-white/5 hover:text-sf-ink border border-transparent'
          }`}
        >
          <SettingsIcon size={20} />
        </Link>
         <div className="relative flex h-3 w-3" title={isOnline ? "Network Online" : "Network Offline"}>
            {isOnline ? (
              <>
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#30D158] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[#30D158]"></span>
              </>
            ) : (
              <span className="relative inline-flex rounded-full h-3 w-3 bg-[#FF453A]"></span>
            )}
          </div>
      </div>
    </aside>
  );
}

function MainLayout() {
  useGlobalShortcuts();
  const [leftPaneWidth, setLeftPaneWidth] = usePersistedState('leftPaneWidth', 420);
  const { isRestored, initialWorkspaceState, updateWorkspaceState } = useAppSync();
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  const location = useLocation();
  const isDragging = useRef(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  };

  const handleMouseUp = useCallback(() => {
    if (isDragging.current) {
      isDragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      if (leftPaneRef.current) {
        const newWidth = parseInt(leftPaneRef.current.style.width, 10);
        if (!isNaN(newWidth)) {
          setLeftPaneWidth(newWidth);
        }
      }
    }
  }, []);

  const leftPaneRef = useRef<HTMLDivElement>(null);
  
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging.current) return;
    
    // Activity bar is ~60-68px wide
    const activityBarWidth = window.innerWidth >= 640 ? 68 : 60;
    const newWidth = e.clientX - activityBarWidth;
    
    // Constrain width
    if (newWidth >= 280 && newWidth <= window.innerWidth - 300) {
      if (leftPaneRef.current) {
        leftPaneRef.current.style.width = `${newWidth}px`;
      }
      // Note: we don't call setLeftPaneWidth here to avoid React re-renders during drag
      // We only sync the state on mouse up
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  if (!isRestored) {
    return <div className="h-[100dvh] w-full flex items-center justify-center bg-sf-bg"><div className="text-sf-accent/50 text-sm animate-pulse">Restoring workspace...</div></div>;
  }

  const handleGlobalInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    // Dismiss keyboard on exterior tap by blurring active element if it's an input/textarea
    const target = e.target as HTMLElement;
    if (
      document.activeElement &&
      document.activeElement instanceof HTMLElement &&
      document.activeElement.tagName !== 'BODY' &&
      target.tagName !== 'INPUT' &&
      target.tagName !== 'TEXTAREA' &&
      target.tagName !== 'SELECT' &&
      !target.isContentEditable &&
      !target.closest('input, textarea, select, [contenteditable="true"]')
    ) {
      document.activeElement.blur();
    }
  };

  return (
        <div 
          className="h-[100dvh] w-full flex overflow-hidden bg-sf-bg relative"
          onMouseDownCapture={handleGlobalInteraction}
          onTouchStartCapture={handleGlobalInteraction}
        >
          <ActivityBar isOnline={isOnline} />
          
          {!isOnline && (
            <div className="absolute bottom-4 right-4 z-50 bg-sf-panel border border-sf-border shadow-2xl rounded-xl p-3 flex items-center gap-3 animate-in slide-in-from-bottom-5">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
              <span className="text-sm font-medium text-white/80">Application is offline. Using cached state.</span>
            </div>
          )}
          
          <div 
            ref={leftPaneRef}
            className="shrink-0 h-full overflow-hidden relative flex flex-col bg-sf-bg z-10 shadow-2xl"
            style={{ width: `${leftPaneWidth}px` }}
          >
            <main className="flex flex-col overflow-hidden relative h-full w-full">
              <Breadcrumbs />
              <div className="flex flex-col flex-1 min-h-0 relative">
                
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={location.pathname}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        transition={{ duration: 0.2, ease: 'easeInOut' }}
                        className="absolute inset-0 overflow-y-auto overflow-x-hidden"
                      >
                        <Routes location={location} key={location.pathname}>
                      <Route path="/" element={<AIChat />} />
                      <Route path="/kanban" element={<Kanban />} />
                      <Route path="/settings" element={<Settings />} />
                      <Route path="/agents" element={<Agents />} />
                      <Route path="/teams" element={<Teams />} />
                      <Route path="/schema" element={<SchemaBuilder />} />
                      <Route path="/installer" element={<Installer />} />
                      <Route path="/testing" element={<Testing />} />
                      <Route path="/search" element={<Search />} />
                        </Routes>
                      </motion.div>
                    </AnimatePresence>
                  
              </div>
            </main>
          </div>

          <div 
            className="w-[3px] cursor-col-resize bg-sf-border hover:bg-sf-accent active:bg-sf-accent z-30 shrink-0 transition-colors relative"
            onMouseDown={handleMouseDown}
          >
             <div className="absolute inset-y-0 -left-2 -right-2"></div>
          </div>
          
          <div className="flex-grow h-full min-w-0 relative z-0">
             <RightWorkspace initialState={initialWorkspaceState} onStateChange={updateWorkspaceState} />
          </div>
        </div>
  );
}


export default function App() {
  useTheme();


  useEffect(() => {
    const handleAgentAction = (e: any) => {
      const action = e.detail?.action;
      if (action === 'chat') {
        toast.success('Agent Chat initialized', { description: 'Opening chat interface...' });
      } else if (action === 'debug') {
        toast.info('Agent Debugger started', { description: 'Analyzing current view...' });
      } else if (action === 'test') {
        toast.info('Test Generator active', { description: 'Writing unit tests...' });
      }
    };
    window.addEventListener('sf_agent_action', handleAgentAction);
    return () => window.removeEventListener('sf_agent_action', handleAgentAction);
  }, []);

    return (
      <ErrorBoundary>
        <Suspense fallback={<div className="h-[100dvh] w-full flex items-center justify-center bg-sf-bg"><div className="text-sf-accent/50 text-sm animate-pulse">Loading workspace...</div></div>}>
          <SwarmProvider>
            <CommandPalette />
            <Toaster theme="dark" position="bottom-right" toastOptions={{ className: 'backdrop-blur-xl bg-sf-panel border-sf-border text-sf-ink rounded-2xl shadow-xl' }} />
            <MainLayout />
          </SwarmProvider>
        </Suspense>
      </ErrorBoundary>
  );
}