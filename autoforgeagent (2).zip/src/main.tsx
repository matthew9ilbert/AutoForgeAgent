import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Suppress Monaco Editor cancellation errors from polluting the console
window.addEventListener('unhandledrejection', (event) => {
  if (event.reason && event.reason.name === 'Canceled' || (event.reason && event.reason.message === 'Canceled') || (event.reason && event.reason.type === 'cancelation')) {
    event.preventDefault();
  }
});

import { BrowserRouter } from 'react-router';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
);
