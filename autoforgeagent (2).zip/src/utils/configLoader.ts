export interface AppConfig {
  providers?: any[];
  accessUrls?: any[];
  workspaceState?: {
    activeTab?: string;
    lastRoute?: string;
    leftPaneWidth?: number;
    [key: string]: any;
  };
  [key: string]: any;
}

const STORAGE_KEY = 'app_config_json';

export async function fetchBackendConfig(): Promise<AppConfig | null> {
    try {
        const res = await fetch('/api/config');
        if (res.ok) {
            return await res.json();
        }
    } catch (e) {
        console.error('Error fetching backend config:', e);
    }
    return null;
}

export async function saveBackendConfig(config: AppConfig) {
    try {
        await fetch('/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });
    } catch (e) {
        console.error('Error saving backend config:', e);
    }
}

export function getFallbackConfig(): AppConfig | null {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (data) return JSON.parse(data);
  } catch (e) {
    console.error(e);
  }
  return null;
}

export function saveFallbackConfig(config: AppConfig) {
  try {
    const existing = getFallbackConfig() || {};
    const merged = { ...existing, ...config };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
  } catch (e) {
    console.error(e);
  }
}

export async function loadConfig(fileHandle?: any): Promise<AppConfig | null> {
  const backendConfig = await fetchBackendConfig();
  if (backendConfig && Object.keys(backendConfig).length > 0) {
      saveFallbackConfig(backendConfig);
      return backendConfig;
  }
  
  try {
    if (fileHandle) {
      const file = await fileHandle.getFile();
      const text = await file.text();
      const config = JSON.parse(text);
      saveFallbackConfig(config);
      await saveBackendConfig(config);
      return config;
    }
  } catch (e) {
    console.error('Error reading from file handle:', e);
  }
  return getFallbackConfig();
}

export async function saveConfig(config: AppConfig, fileHandle?: any): Promise<void> {
  saveFallbackConfig(config);
  await saveBackendConfig(config);
  try {
    if (fileHandle && 'createWritable' in fileHandle) {
      const writable = await fileHandle.createWritable();
      await writable.write(JSON.stringify(config, null, 2));
      await writable.close();
    }
  } catch (e) {
    console.error('Error saving to file handle:', e);
  }
}

export async function promptForFile(): Promise<any | null> {
  try {
    if ('showOpenFilePicker' in window) {
      const [fileHandle] = await (window as any).showOpenFilePicker({
        types: [{
          description: 'JSON Config File',
          accept: { 'application/json': ['.json'] },
        }],
      });
      return fileHandle;
    }
  } catch (e) {
    console.error('File picker cancelled or failed', e);
  }
  return null;
}

export async function promptForSaveFile(): Promise<any | null> {
  try {
    if ('showSaveFilePicker' in window) {
      const fileHandle = await (window as any).showSaveFilePicker({
        suggestedName: 'config.json',
        types: [{
          description: 'JSON Config File',
          accept: { 'application/json': ['.json'] },
        }],
      });
      return fileHandle;
    }
  } catch (e) {
    console.error('Save file picker cancelled or failed', e);
  }
  return null;
}

// App State Helpers
export function getAppState() {
    return getFallbackConfig()?.workspaceState || {};
}

export function saveAppState(state: Partial<AppConfig['workspaceState']>) {
    const config = getFallbackConfig() || {};
    config.workspaceState = { ...config.workspaceState, ...state };
    saveFallbackConfig(config);
    // Note: We don't await saveBackendConfig here to avoid blocking UI unnecessarily on every pane resize
    saveBackendConfig(config).catch(console.error);
}
