import { getFallbackConfig, saveBackendConfig, AppConfig } from './configLoader';

export class GoogleServicesManager {
  static getServiceToken(serviceName: string): string | null {
    const config = getFallbackConfig();
    return config?.googleTokens?.[serviceName] || null;
  }

  static async setServiceToken(serviceName: string, token: string): Promise<void> {
    const config = getFallbackConfig() || {};
    if (!config.googleTokens) {
      config.googleTokens = {};
    }
    config.googleTokens[serviceName] = token;
    
    // Also save to backend config.json
    await saveBackendConfig(config);
  }

  static getServices() {
    return [
      'Drive', 'Sheets', 'Gmail', 'Calendar', 'Docs',
      'Tasks', 'Chat', 'Forms', 'Keep', 'Contacts', 'Meet'
    ];
  }
}
