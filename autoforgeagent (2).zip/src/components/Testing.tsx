import React, { useState } from 'react';
import { WorkspacePlaceholder } from './WorkspacePlaceholder';
import { PlaceholderList } from './Placeholder';
import { WorkspaceHeader } from './WorkspaceHeader';
import { TestTube, Play, CheckCircle2, XCircle, Clock, RefreshCw } from 'lucide-react';

export function Testing() {
  const [isRunning, setIsRunning] = useState(false);
  const [activeTest, setActiveTest] = useState<string | null>(null);

  const tests = [
    { id: 1, name: 'Auth Module: Login', status: 'passed', time: '142ms' },
    { id: 2, name: 'Auth Module: Session JWT', status: 'passed', time: '89ms' },
    { id: 3, name: 'Agents: State transitions', status: 'failed', time: '12ms', error: 'Expected state "idle" but got "running"' },
    { id: 4, name: 'Swarm: Launch task', status: 'pending', time: '-' },
    { id: 5, name: 'IDE: Command Palette shortcut', status: 'pending', time: '-' },
    { id: 6, name: 'API: User Profile Fetch', status: 'pending', time: '-' },
    { id: 7, name: 'Settings: Dark Mode Toggle', status: 'pending', time: '-' },
  ];

  const handleRunAll = () => {
    setIsRunning(true);
    setActiveTest('Agents: State transitions');
    setTimeout(() => {
      setIsRunning(false);
      setActiveTest(null);
    }, 3000);
  };

  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader 
        title="Automated TDD Pipeline" 
        subtitle="Unit & End-to-End Testing"
        actions={
          <button 
            className="btn-primary flex items-center gap-2"
            onClick={handleRunAll}
            disabled={isRunning}
          >
            {isRunning ? <RefreshCw size={16} className="animate-spin" /> : <Play size={16} />}
            {isRunning ? 'Running Tests...' : 'Run All Tests'}
          </button>
        }
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 flex-1">
        <div className="card flex flex-col col-span-2 min-h-[400px]">
            <div className="label mb-3">Test Execution Plan</div>
            <div className="flex flex-col gap-3 flex-1  overflow-x-hidden break-words pr-2 ">
                {tests.length === 0 ? <WorkspacePlaceholder title="No Tests Found" icon={<TestTube size={24} />} /> : <>
                <PlaceholderList count={Math.max(0, 5 - tests.length)} type="compact" heightClass="h-[66px]" />
                {tests.map((test) => (
                    <div key={test.id} className={`p-4 rounded-xl border ${test.name === activeTest ? 'border-sf-accent bg-sf-accent/5' : 'border-sf-border bg-sf-bg/50'} flex flex-col gap-2 transition-colors`}>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                {test.status === 'passed' && <CheckCircle2 size={18} className="text-[#30D158]" />}
                                {test.status === 'failed' && <XCircle size={18} className="text-[#FF453A]" />}
                                {test.status === 'pending' && <Clock size={18} className="text-sf-ink/40" />}
                                <span className="font-semibold text-sm">{test.name}</span>
                            </div>
                            <span className="text-xs font-mono text-sf-ink/50">{test.time}</span>
                        </div>
                        {test.error && (
                            <div className="mt-2 p-3 bg-[#FF453A]/10 text-[#FF453A] text-xs font-mono rounded-lg border border-[#FF453A]/20">
                                {test.error}
                            </div>
                        )}
                    </div>
                ))}</>}
            </div>
        </div>

        <div className="card flex flex-col min-h-[400px] bg-sf-panel border border-sf-border">
            <div className="label mb-3">Test Driven AI</div>
            <p className="text-sm text-sf-ink/70 mb-3 leading-relaxed">
                Describe a feature, and the AI will automatically generate the required Vitest / Playwright test cases before writing the implementation code, ensuring regression-free deliverables.
            </p>
            <textarea 
                className="glass-input w-full  overflow-x-hidden break-words  p-3 resize-none mb-3"
                placeholder="e.g. Add a subscription tier to the user profile, ensure free users cannot access premium routes..."
            />
            <button className="btn-secondary w-full">Generate Tests</button>
        </div>
      </div>
    </div>
  );
}
