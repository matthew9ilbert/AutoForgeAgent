import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Paperclip, MoreVertical, Maximize2, Settings2, Command } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const initialMessage = `Autonomous AI App Factory
# Agentic IDE / Vibe Coding Architecture

### Mission
Build an autonomous AI software engineering platform that provides a seamless "agentic IDE" experience comparable to leading AI development environments. The platform shall function as a unified development operating system where the AI plans, edits, executes, validates, previews, and iteratively improves software with minimal user intervention while maintaining transparency, safety, and recoverability.
The user should primarily communicate objectives in natural language. The platform is responsible for determining implementation details, selecting tools, executing workflows, validating outcomes, and presenting progress.

### Core Development Philosophy
Every software modification shall follow a continuous autonomous engineering loop.
Observe -> Understand -> Plan -> Select Tools -> Execute -> Observe Results -> Validate -> Repair (if needed) -> Repeat -> Complete -> Document -> Archive Knowledge

The platform shall continue iterating until the defined success criteria are met or a configured policy requires user approval.

### Unified Agentic Workspace
The development environment shall integrate all major activities into a single workspace.
Components include:
- AI Assistant
- Code Editor
- File Explorer
- Terminal
- Runtime
- Live Preview
- Logs
- Agent Activity Feed
- Background Tasks
- Notifications
- Memory Panel

The user should never need to manually synchronize changes between these components.

### Instant Feedback Loop
The application shall minimize friction through:
- Automatic file synchronization
- Live code updates
- Hot reload
- Embedded previews
- Automatic log streaming
- Immediate test execution
- Continuous diagnostics

Whenever practical, users should see the impact of changes immediately.

### Safe Execution Environment
All AI-generated modifications shall execute inside an isolated workspace.
Requirements include: Workspace snapshots, File versioning, Rollback capability, Preview before deployment, Automatic backup, Crash recovery, Checkpoints.
No destructive change should occur without a recovery path.

### Autonomous Development Loop
Each objective follows this lifecycle:
1. Analyze the request.
2. Build an implementation plan.
3. Decompose into tasks.
4. Select the required agents.
5. Select the appropriate models.
6. Execute one task.
7. Observe outputs.
8. Validate against success criteria.
9. Repair failures.
10. Repeat until complete.

The system should avoid asking the user for routine implementation decisions that can be resolved through established project policies.

### Continuous Quality Gates
Every implementation must satisfy automated validation before progressing.
Required checks include: Build success, Static analysis, Unit tests, Integration tests, Security scanning, Accessibility validation, Documentation completeness, Performance thresholds.
Failed validations automatically generate follow-up repair work.

### User Experience Goals
The finished platform should provide an experience where the user can describe an idea in natural language and observe autonomous progress through planning, implementation, testing, previews, and validation within a single integrated workspace.
The environment should emphasize rapid feedback, continuous visibility, explainable automation, safe execution, and high-confidence iterative development rather than isolated code generation.`;

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: initialMessage,
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const newUserMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newUserMsg]);
    setInput('');
    
    // Simulate AI response
    setTimeout(() => {
      const newAIMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'I understand. I am analyzing the workspace to execute this request...',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, newAIMsg]);
    }, 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col w-full h-full bg-sf-bg relative">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-sf-border bg-sf-panel/50 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <Bot size={18} className="text-sf-accent" />
          <span className="font-semibold text-sm">AI Agent</span>
          <span className="text-[0.6rem] px-1.5 py-0.5 rounded-full bg-sf-accent/10 text-sf-accent border border-sf-accent/20">Gemini 1.5 Pro</span>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-1.5 text-sf-ink/60 hover:text-sf-ink rounded-lg hover:bg-sf-bg/50 transition-colors">
            <Settings2 size={16} />
          </button>
          <button className="p-1.5 text-sf-ink/60 hover:text-sf-ink rounded-lg hover:bg-sf-bg/50 transition-colors">
            <MoreVertical size={16} />
          </button>
        </div>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 min-h-[400px]">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-3 max-w-[95%] ${msg.role === 'user' ? 'self-end' : 'self-start'}`}>
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-full bg-sf-accent/10 border border-sf-accent/20 flex items-center justify-center shrink-0 mt-1">
                <Bot size={16} className="text-sf-accent" />
              </div>
            )}
            
            <div className={`p-3 rounded-2xl text-[0.85rem] leading-relaxed shadow-sm ${
              msg.role === 'user' 
                ? 'bg-sf-accent text-white rounded-tr-sm' 
                : 'bg-sf-panel border border-sf-border text-sf-ink rounded-tl-sm'
            }`}>
              <div className="whitespace-pre-wrap">{msg.content}</div>
            </div>

            {msg.role === 'user' && (
              <div className="w-8 h-8 rounded-full bg-sf-panel border border-sf-border flex items-center justify-center shrink-0 mt-1">
                <User size={16} className="text-sf-ink/60" />
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 bg-sf-panel/50 backdrop-blur-md border-t border-sf-border relative">
        <div className="relative flex items-end gap-2 bg-sf-bg border border-sf-border rounded-xl p-2 focus-within:border-sf-accent/50 transition-colors shadow-inner">
          <button className="p-2 text-sf-ink/40 hover:text-sf-accent rounded-lg transition-colors shrink-0">
            <Paperclip size={18} />
          </button>
          
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask AI to build, edit, or explain..."
            className="w-full bg-transparent border-none outline-none resize-none text-[0.85rem] max-h-32 min-h-[40px] py-2 placeholder:text-sf-ink/30"
            rows={input.split('\n').length > 1 ? Math.min(5, input.split('\n').length) : 1}
          />
          
          <button 
            onClick={handleSend}
            disabled={!input.trim()}
            className={`p-2 rounded-lg transition-all shrink-0 ${
              input.trim() 
                ? 'bg-sf-accent text-white hover:bg-sf-accent/90 shadow-md' 
                : 'bg-sf-bg border border-sf-border text-sf-ink/30'
            }`}
          >
            <Send size={16} className={input.trim() ? "translate-x-0.5" : ""} />
          </button>
        </div>
        <div className="flex justify-between items-center mt-2 px-1">
          <div className="flex gap-2">
            <span className="text-[0.6rem] font-mono text-sf-ink/40 flex items-center gap-1 bg-sf-bg/50 px-1.5 py-0.5 rounded border border-sf-border/50 cursor-pointer hover:text-sf-ink/70">
              <Command size={10} /> codebase
            </span>
          </div>
          <span className="text-[0.6rem] text-sf-ink/30">Shift + Enter for new line</span>
        </div>
      </div>
    </div>
  );
}
