import React, { useState } from 'react';
import { Workflow, Play, Zap, FileText, Bug, Rocket, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

interface Template {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  agents: string[];
}

const defaultTemplates: Template[] = [
  {
    id: 'tpl-1',
    name: 'Feature to Deployment',
    description: 'End-to-end pipeline covering planning, frontend, backend, testing, and deployment.',
    icon: <Rocket size={20} className="text-[#0A84FF]" />,
    agents: ['Executive AI', 'Frontend Engineer', 'Backend Engineer', 'Test Sentinel', 'Deployment Agent']
  },
  {
    id: 'tpl-2',
    name: 'Bug Hunt to PR',
    description: 'Automated defect tracking, fixing, and pull request generation pipeline.',
    icon: <Bug size={20} className="text-[#FF453A]" />,
    agents: ['Debugging Engineer', 'Refactoring Engineer', 'Unit Test Engineer', 'Code Reviewer']
  },
  {
    id: 'tpl-3',
    name: 'UI/UX Redesign Sync',
    description: 'Vision-based UI analysis and instant Tailwind CSS refactoring pipeline.',
    icon: <Zap size={20} className="text-[#FF9F0A]" />,
    agents: ['Vision Inspector', 'UI Designer', 'Frontend Engineer', 'Accessibility Reviewer']
  },
  {
    id: 'tpl-4',
    name: 'Docs & API Sync',
    description: 'Continuous documentation and API spec updates based on recent code changes.',
    icon: <FileText size={20} className="text-[#30D158]" />,
    agents: ['Technical Writer', 'API Documentation', 'Solution Architect']
  }
];

export function WorkflowTemplates() {
  const [templates, setTemplates] = useState<Template[]>(defaultTemplates);

  const runTemplate = (tpl: Template) => {
    toast.success(`Pipeline Started: ${tpl.name}`, { 
      description: `Orchestrating ${tpl.agents.length} agents: ${tpl.agents.join(', ')}...`
    });
    // Dispatch event to simulate running pipeline
    window.dispatchEvent(new CustomEvent('sf_pipeline_start', { detail: { template: tpl } }));
  };

  return (
    <div className="flex flex-col h-full gap-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {templates.map(tpl => (
          <div key={tpl.id} className="bg-black/20 border border-white/5 p-4 rounded-2xl hover:bg-black/40 hover:border-white/10 transition-all group flex flex-col justify-between min-h-[140px]">
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-3">
                  <div className="bg-sf-bg p-2 rounded-xl border border-white/5">
                    {tpl.icon}
                  </div>
                  <h3 className="font-semibold text-white/90 text-sm tracking-tight">{tpl.name}</h3>
                </div>
                <button 
                  onClick={() => runTemplate(tpl)}
                  className="btn-primary !h-8 !px-3 !bg-white/10 hover:!bg-sf-accent hover:!text-white !text-white/80 !border-none !shadow-none transition-colors"
                >
                  <Play size={12} className="fill-current" />
                  Run
                </button>
              </div>
              <p className="text-[0.75rem] text-white/50 leading-relaxed mt-2">{tpl.description}</p>
            </div>
            
            <div className="mt-3 flex flex-wrap items-center gap-1">
              {tpl.agents.map((agent, i) => (
                <React.Fragment key={agent}>
                  <span className="text-[0.65rem] bg-sf-panel px-1.5 py-0.5 rounded border border-sf-border text-white/70 whitespace-nowrap">
                    {agent}
                  </span>
                  {i < tpl.agents.length - 1 && <ChevronRight size={10} className="text-white/30" />}
                </React.Fragment>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
