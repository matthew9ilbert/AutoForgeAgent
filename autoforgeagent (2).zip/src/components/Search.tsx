import React, { useState, useEffect } from 'react';
import { WorkspacePlaceholder } from './WorkspacePlaceholder';
import { PlaceholderList } from './Placeholder';
import { useLocation } from 'react-router';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Search as SearchIcon, Code, FileText, ArrowRight, Wand2 } from 'lucide-react';

export function Search() {
  const [query, setQuery] = useState('');
  const location = useLocation();
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const q = params.get('q');
    if (q) setQuery(q);
  }, [location.search]);
  
  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader 
        title="Semantic Code Search" 
        subtitle="AI-Powered Structural Search & Refactoring"
      />
      
      <div className="card flex flex-col gap-3">
        <div className="flex flex-col gap-3">
            <div className="relative w-full">
                <SearchIcon className="absolute left-4 top-5 text-sf-accent" size={20} />
                <textarea 
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder='Try: "Find all places we handle authentication errors"' 
                    className="glass-input w-full pl-12 pr-4 py-4 text-lg bg-sf-bg/50 border-sf-accent/30 focus:border-sf-accent min-h-[60px] resize-y"
                />
            </div>
            <button className="btn-primary !py-1.5 !px-4 text-[0.75rem] flex items-center justify-center gap-2 self-start shrink-0">
                <Wand2 size={14} /> Semantic Search
            </button>
        </div>
        
        <div className="flex gap-2 items-start mt-2">
            <span className="text-[0.65rem] font-bold text-sf-ink/40 uppercase tracking-wider mt-1">Suggested:</span>
            <div className="flex flex-wrap gap-2">
                <span className="px-2.5 py-0.5 bg-white/5 border border-white/10 rounded-full text-[0.65rem] cursor-pointer hover:bg-white/10 transition-colors">"Update deprecated API endpoints"</span>
                <span className="px-2.5 py-0.5 bg-white/5 border border-white/10 rounded-full text-[0.65rem] cursor-pointer hover:bg-white/10 transition-colors">"Extract inline styles to Tailwind"</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 flex-1">
          <div className="card flex flex-col flex-1 overflow-hidden min-h-[400px]">
              <div className="label">Search Results (Structural Intent)</div>
              <div className="flex flex-col gap-3 mt-3  overflow-x-hidden break-words flex-1 pr-2 ">
                  {(() => {
    const results = [1, 2].map(i => ({ id: i, label: 'src/components/Auth' + i + '.tsx' }));
    return (
        <>
            {results.length === 0 ? <WorkspacePlaceholder title="No Results Found" icon={<SearchIcon size={24} />} /> : <>
            <PlaceholderList count={Math.max(0, 5 - results.length)} type="compact" heightClass="h-[106px]" />
            {results.map((item) => (
                      <div key={item.id} className="p-4 rounded-xl border border-sf-border bg-sf-bg/30">
                          <div className="flex items-center gap-2 mb-2">
                              <FileText size={14} className="text-sf-accent" />
                              <span className="font-mono text-xs opacity-70">{item.label}</span>
                          </div>
                          <pre className="text-[0.7rem] font-mono text-sf-ink/80 p-3 bg-black/40 rounded-lg overflow-x-hidden break-words whitespace-pre-wrap">
                              <code>
{`try {
  await login(user);
} catch (e) {
  // Matched: Authentication Error Handling
  toast.error(e.message);
}`}
                              </code>
                          </pre>
                      </div>
                  ))}
                  </>}</>
                  );
                  })()}
              </div>
          </div>
          
          <div className="card flex flex-col flex-1 overflow-hidden min-h-[400px] bg-sf-panel border border-sf-accent/20">
              <div className="label text-sf-accent">Refactoring Engine</div>
              <div className="mt-3 flex-1 flex flex-col ">
                  <p className="text-sm opacity-70 mb-3">Execute complex refactoring patterns simultaneously across all semantic matches.</p>
                  
                  <textarea 
                    className="glass-input w-full flex-1 p-4 font-mono text-sm resize-none  overflow-x-hidden break-words"
                    placeholder="Describe refactoring pattern... e.g. 'Standardize all auth errors to use the GlobalErrorHandler.capture() method instead of toast.'"
                  ></textarea>
                  
                  <div className="mt-3 flex justify-end gap-3">
                      <button className="btn-secondary">Preview Changes</button>
                      <button className="btn-primary">Apply Refactor</button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}
