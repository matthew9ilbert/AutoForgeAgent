import React, { useState } from 'react';
import { WorkspacePlaceholder } from './WorkspacePlaceholder';
import { toast } from '../lib/toast';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Plus, Save, Trash2, Edit2, Shield, Settings, Brain, Database, Wrench, Edit3, Bot } from 'lucide-react';
import * as ContextMenu from '@radix-ui/react-context-menu';
import { Tooltip } from './Tooltip';

interface Agent {
  id: string;
  tag: string;
  name: string;
  role: string;
  system_prompt: string;
  goals: string[];
  temperature: number;
  ai_provider: string;
  ai_model: string;
  capabilities: string[];
  permissions: string[];
  memory: string;
  tools: string[];
}

export function Agents() {
  const [agents, setAgents] = useState<Agent[]>([
  {
    "id": "uuid-ag-0",
    "tag": "#executive",
    "name": "Executive AI",
    "role": "Long-term vision, goals, prioritization",
    "system_prompt": "You are the Executive AI. Long-term vision, goals, prioritization.",
    "goals": [
      "Long-term vision, goals, prioritization"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "gpt-5.4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-0",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-1",
    "tag": "#orchestration",
    "name": "AI Supervisor",
    "role": "Runtime management, approvals, orchestration",
    "system_prompt": "You are the AI Supervisor. Runtime management, approvals, orchestration.",
    "goals": [
      "Runtime management, approvals, orchestration"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:14b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-1",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-2",
    "tag": "#coordination",
    "name": "Swarm Coordinator",
    "role": "Team formation and workload balancing",
    "system_prompt": "You are the Swarm Coordinator. Team formation and workload balancing.",
    "goals": [
      "Team formation and workload balancing"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-2",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-3",
    "tag": "#planning",
    "name": "Strategic Planner",
    "role": "Roadmaps, milestones, execution strategy",
    "system_prompt": "You are the Strategic Planner. Roadmaps, milestones, execution strategy.",
    "goals": [
      "Roadmaps, milestones, execution strategy"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "gpt-5.4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-3",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-4",
    "tag": "#product",
    "name": "Product Manager",
    "role": "Requirements, feature planning",
    "system_prompt": "You are the Product Manager. Requirements, feature planning.",
    "goals": [
      "Requirements, feature planning"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-3.5-flash",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-4",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-5",
    "tag": "#business",
    "name": "Business Analyst",
    "role": "Business logic, workflows",
    "system_prompt": "You are the Business Analyst. Business logic, workflows.",
    "goals": [
      "Business logic, workflows"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:14b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-5",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-6",
    "tag": "#research",
    "name": "Market Researcher",
    "role": "Competitive research",
    "system_prompt": "You are the Market Researcher. Competitive research.",
    "goals": [
      "Competitive research"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "perplexity-deep",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-6",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-7",
    "tag": "#research",
    "name": "Technical Researcher",
    "role": "APIs, SDKs, technologies",
    "system_prompt": "You are the Technical Researcher. APIs, SDKs, technologies.",
    "goals": [
      "APIs, SDKs, technologies"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "perplexity-reasoning",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-7",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-8",
    "tag": "#innovation",
    "name": "Innovation Agent",
    "role": "New ideas and features",
    "system_prompt": "You are the Innovation Agent. New ideas and features.",
    "goals": [
      "New ideas and features"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "grok-4-20-reasoning",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-8",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-9",
    "tag": "#architecture",
    "name": "Solution Architect",
    "role": "Overall architecture",
    "system_prompt": "You are the Solution Architect. Overall architecture.",
    "goals": [
      "Overall architecture"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "gpt-5.4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-9",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-10",
    "tag": "#backend",
    "name": "Backend Engineer",
    "role": "APIs and services",
    "system_prompt": "You are the Backend Engineer. APIs and services.",
    "goals": [
      "APIs and services"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "deepseek-v4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-10",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-11",
    "tag": "#frontend",
    "name": "Frontend Engineer",
    "role": "UI implementation",
    "system_prompt": "You are the Frontend Engineer. UI implementation.",
    "goals": [
      "UI implementation"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5-coder:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-11",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-12",
    "tag": "#mobile",
    "name": "Mobile Engineer",
    "role": "Mobile apps",
    "system_prompt": "You are the Mobile Engineer. Mobile apps.",
    "goals": [
      "Mobile apps"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "gpt-5.4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-12",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-13",
    "tag": "#database",
    "name": "Database Engineer",
    "role": "Data models and optimization",
    "system_prompt": "You are the Database Engineer. Data models and optimization.",
    "goals": [
      "Data models and optimization"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "deepseek-v4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-13",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-14",
    "tag": "#integration",
    "name": "API Integration Engineer",
    "role": "Third-party integrations",
    "system_prompt": "You are the API Integration Engineer. Third-party integrations.",
    "goals": [
      "Third-party integrations"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5-coder:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-14",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-15",
    "tag": "#devops",
    "name": "DevOps Engineer",
    "role": "CI/CD and infrastructure",
    "system_prompt": "You are the DevOps Engineer. CI/CD and infrastructure.",
    "goals": [
      "CI/CD and infrastructure"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "deepseek-v4-pro",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-15",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-16",
    "tag": "#review",
    "name": "Code Reviewer",
    "role": "Review code quality",
    "system_prompt": "You are the Code Reviewer. Review code quality.",
    "goals": [
      "Review code quality"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "gpt-5.4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-16",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-17",
    "tag": "#refactoring",
    "name": "Refactoring Engineer",
    "role": "Improve maintainability",
    "system_prompt": "You are the Refactoring Engineer. Improve maintainability.",
    "goals": [
      "Improve maintainability"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5-coder:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-17",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-18",
    "tag": "#debugging",
    "name": "Debugging Engineer",
    "role": "Investigate and fix defects",
    "system_prompt": "You are the Debugging Engineer. Investigate and fix defects.",
    "goals": [
      "Investigate and fix defects"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "deepseek-v4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-18",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-19",
    "tag": "#testing",
    "name": "Unit Test Engineer",
    "role": "Generate tests",
    "system_prompt": "You are the Unit Test Engineer. Generate tests.",
    "goals": [
      "Generate tests"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5-coder:3b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-19",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-20",
    "tag": "#testing",
    "name": "Integration Test Engineer",
    "role": "End-to-end testing",
    "system_prompt": "You are the Integration Test Engineer. End-to-end testing.",
    "goals": [
      "End-to-end testing"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5-coder:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-20",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-21",
    "tag": "#qa",
    "name": "QA Engineer",
    "role": "Functional validation",
    "system_prompt": "You are the QA Engineer. Functional validation.",
    "goals": [
      "Functional validation"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-3.5-flash",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-21",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-22",
    "tag": "#design",
    "name": "UI Designer",
    "role": "Interface creation",
    "system_prompt": "You are the UI Designer. Interface creation.",
    "goals": [
      "Interface creation"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "gpt-5.4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-22",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-23",
    "tag": "#ux",
    "name": "UX Reviewer",
    "role": "Workflow evaluation",
    "system_prompt": "You are the UX Reviewer. Workflow evaluation.",
    "goals": [
      "Workflow evaluation"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-3.5-flash",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-23",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-24",
    "tag": "#a11y",
    "name": "Accessibility Reviewer",
    "role": "Accessibility checks",
    "system_prompt": "You are the Accessibility Reviewer. Accessibility checks.",
    "goals": [
      "Accessibility checks"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-3.5-flash",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-24",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-25",
    "tag": "#vision",
    "name": "Vision Inspector",
    "role": "Screenshot and UI analysis",
    "system_prompt": "You are the Vision Inspector. Screenshot and UI analysis.",
    "goals": [
      "Screenshot and UI analysis"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5vl:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-25",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-26",
    "tag": "#docs",
    "name": "Technical Writer",
    "role": "Documentation",
    "system_prompt": "You are the Technical Writer. Documentation.",
    "goals": [
      "Documentation"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "kimi",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-26",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-27",
    "tag": "#docs",
    "name": "API Documentation",
    "role": "API references",
    "system_prompt": "You are the API Documentation. API references.",
    "goals": [
      "API references"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-3.5-flash",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-27",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-28",
    "tag": "#docs",
    "name": "Release Notes",
    "role": "Changelogs",
    "system_prompt": "You are the Release Notes. Changelogs.",
    "goals": [
      "Changelogs"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "phi3:3.8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-28",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-29",
    "tag": "#memory",
    "name": "Memory Manager",
    "role": "Context management",
    "system_prompt": "You are the Memory Manager. Context management.",
    "goals": [
      "Context management"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "phi3:3.8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-29",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-30",
    "tag": "#knowledge",
    "name": "Knowledge Librarian",
    "role": "Organize reusable assets",
    "system_prompt": "You are the Knowledge Librarian. Organize reusable assets.",
    "goals": [
      "Organize reusable assets"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-30",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-31",
    "tag": "#knowledge",
    "name": "Knowledge Graph Manager",
    "role": "Maintain relationships",
    "system_prompt": "You are the Knowledge Graph Manager. Maintain relationships.",
    "goals": [
      "Maintain relationships"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:14b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-31",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-32",
    "tag": "#background",
    "name": "Background Development Agent",
    "role": "Continuous maintenance",
    "system_prompt": "You are the Background Development Agent. Continuous maintenance.",
    "goals": [
      "Continuous maintenance"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "phi3:3.8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-32",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-33",
    "tag": "#maintenance",
    "name": "Technical Debt Agent",
    "role": "Refactoring opportunities",
    "system_prompt": "You are the Technical Debt Agent. Refactoring opportunities.",
    "goals": [
      "Refactoring opportunities"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-33",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-34",
    "tag": "#performance",
    "name": "Performance Optimizer",
    "role": "Improve efficiency",
    "system_prompt": "You are the Performance Optimizer. Improve efficiency.",
    "goals": [
      "Improve efficiency"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "deepseek-v4-pro",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-34",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-35",
    "tag": "#maintenance",
    "name": "Dependency Manager",
    "role": "Package updates",
    "system_prompt": "You are the Dependency Manager. Package updates.",
    "goals": [
      "Package updates"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-3.1-flash-lite",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-35",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-36",
    "tag": "#monitoring",
    "name": "Build Monitor",
    "role": "Monitor builds",
    "system_prompt": "You are the Build Monitor. Monitor builds.",
    "goals": [
      "Monitor builds"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "phi3:3.8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-36",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-37",
    "tag": "#deployment",
    "name": "Deployment Agent",
    "role": "Release management",
    "system_prompt": "You are the Deployment Agent. Release management.",
    "goals": [
      "Release management"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "deepseek-v4",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-37",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-38",
    "tag": "#recovery",
    "name": "Recovery Agent",
    "role": "Rollback and recovery",
    "system_prompt": "You are the Recovery Agent. Rollback and recovery.",
    "goals": [
      "Rollback and recovery"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:14b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-38",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-39",
    "tag": "#workflow",
    "name": "Workflow Designer",
    "role": "Build automation workflows",
    "system_prompt": "You are the Workflow Designer. Build automation workflows.",
    "goals": [
      "Build automation workflows"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-2.5-flash",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-39",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-40",
    "tag": "#scheduler",
    "name": "Scheduler",
    "role": "Background scheduling",
    "system_prompt": "You are the Scheduler. Background scheduling.",
    "goals": [
      "Background scheduling"
    ],
    "temperature": 0.5,
    "ai_provider": "Gemini",
    "ai_model": "gemini-2.5-flash-lite",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-40",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-41",
    "tag": "#events",
    "name": "Event Manager",
    "role": "Event routing",
    "system_prompt": "You are the Event Manager. Event routing.",
    "goals": [
      "Event routing"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "phi3:3.8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-41",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-42",
    "tag": "#tools",
    "name": "Tool Manager",
    "role": "External tool orchestration",
    "system_prompt": "You are the Tool Manager. External tool orchestration.",
    "goals": [
      "External tool orchestration"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen3:8b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-42",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-43",
    "tag": "#vision",
    "name": "OCR Agent",
    "role": "Text extraction",
    "system_prompt": "You are the OCR Agent. Text extraction.",
    "goals": [
      "Text extraction"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5vl:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-43",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-44",
    "tag": "#vision",
    "name": "UI Inspector",
    "role": "Layout and UI analysis",
    "system_prompt": "You are the UI Inspector. Layout and UI analysis.",
    "goals": [
      "Layout and UI analysis"
    ],
    "temperature": 0.5,
    "ai_provider": "Pollinations",
    "ai_model": "qwen-vision-pro",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-44",
    "tools": [
      "read_directory"
    ]
  },
  {
    "id": "uuid-ag-45",
    "tag": "#vision",
    "name": "Image Understanding",
    "role": "General image analysis",
    "system_prompt": "You are the Image Understanding. General image analysis.",
    "goals": [
      "General image analysis"
    ],
    "temperature": 0.5,
    "ai_provider": "Ollama",
    "ai_model": "qwen2.5vl:7b",
    "capabilities": [
      "general"
    ],
    "permissions": [
      "read_files"
    ],
    "memory": "mem-ag-45",
    "tools": [
      "read_directory"
    ]
  }
]);
  
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(agents[0].id);
  
  const selectedAgent = agents.find(a => a.id === selectedAgentId);

  const handleCreate = () => {
    const newAgent: Agent = {
        id: Math.random().toString(36).substr(2, 9),
        tag: '#new',
        name: 'New Agent',
        role: 'Pending Role',
        system_prompt: '',
        goals: [],
        temperature: 0.5,
        ai_provider: '',
        ai_model: '',
        capabilities: [],
        permissions: [],
        memory: '',
        tools: []
    };
    setAgents([...agents, newAgent]);
    setSelectedAgentId(newAgent.id);
  };

  const handleUpdate = (field: keyof Agent, value: any) => {
    if (!selectedAgentId) return;
    setAgents(prev => prev.map(a => a.id === selectedAgentId ? { ...a, [field]: value } : a));
  };

  const handleDelete = () => {
    if (!selectedAgentId) return;
    setAgents(prev => prev.filter(a => a.id !== selectedAgentId));
    setSelectedAgentId(null);
    toast.error('Agent node terminated.');
  };

  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
        <div className="flex flex-col items-start bg-sf-panel border border-sf-accent/30 p-4 rounded-xl mb-2 gap-3 shadow-[0_0_20px_rgba(10,132,255,0.1)]">
        <div className="flex items-center gap-3 min-w-0">
            <div className="bg-sf-accent/20 p-3 rounded-lg text-sf-accent shrink-0"><Wrench size={24}/></div>
            <div className="min-w-0">
                <h3 className="font-bold text-lg truncate">Custom Tool & API Builder</h3>
                <p className="text-[0.85rem] opacity-70 line-clamp-2">Give agents hands. Define custom webhooks, web search, or database query tools to assign directly into agent registries.</p>
            </div>
        </div>
        <button className="btn-primary shrink-0 w-full md:w-auto" onClick={() => toast.info('Opening Custom Tool Builder')}><Plus size={16}/> Create New Tool</button>
      </div>
      <WorkspaceHeader title="Agent Directory" subtitle="Node Configuration" />
        <div className="flex flex-col md:flex-row w-full gap-3 flex-1">
        
      <div className="w-full md:w-[320px] shrink-0 flex flex-col gap-3 min-h-[400px]">
          <div className="flex flex-col items-start gap-2 px-1 mb-2">
      <span className="label !mb-0">Directory</span>
      <button className="btn-secondary !h-7 !px-3 !text-[0.75rem]" onClick={handleCreate}><Plus size={12} /> New</button>
   </div>
   <div className="card flex flex-col gap-3 flex-1">
            {agents.length === 0 ? <WorkspacePlaceholder title="No Agents Configured" icon={<Bot size={24} />} /> : agents.map(agent => (
              <ContextMenu.Root key={agent.id}>
                <ContextMenu.Trigger asChild>
                  <div 
                      className={`p-4 rounded-2xl cursor-pointer transition-all border ${selectedAgentId === agent.id ? 'bg-sf-accent/10 border-sf-accent shadow-sm' : 'bg-sf-bg/50 border-sf-border hover:bg-sf-bg hover:border-sf-border/80'}`}
                      onClick={() => setSelectedAgentId(agent.id)}
                  >
                      <div className="flex justify-between items-start mb-1">
                          <span className="font-semibold text-[0.95rem] tracking-tight">{agent.name}</span>
                          <span className="text-[0.65rem] font-mono opacity-60 bg-white/5 px-2 py-0.5 rounded-md">{agent.tag}</span>
                      </div>
                      <Tooltip content={agent.role}>
                        <div className="text-[0.75rem] opacity-70 font-medium truncate">{agent.role}</div>
                      </Tooltip>
                  </div>
                </ContextMenu.Trigger>
                <ContextMenu.Portal>
                  <ContextMenu.Content className="min-w-[160px] bg-sf-panel/95 backdrop-blur-xl border border-sf-border rounded-xl shadow-2xl p-1 z-50 animate-in fade-in zoom-in-95">
                    <ContextMenu.Item className="flex items-center gap-2 px-2 py-1.5 text-sm outline-none cursor-default hover:bg-sf-accent hover:text-white rounded-lg" onClick={() => toast.info(`Rename ${agent.name}`)}>
                      <Edit3 size={14} /> Rename
                    </ContextMenu.Item>
                    <ContextMenu.Separator className="h-px bg-sf-border my-1" />
                    <ContextMenu.Item className="flex items-center gap-2 px-2 py-1.5 text-sm outline-none cursor-default hover:bg-[#FF453A] hover:text-white rounded-lg text-[#FF453A]" onClick={() => toast.error(`Delete ${agent.name}`)}>
                      <Trash2 size={14} /> Delete
                    </ContextMenu.Item>
                  </ContextMenu.Content>
                </ContextMenu.Portal>
              </ContextMenu.Root>
            ))}
          </div>
      </div>

      <div className="card flex-grow flex flex-col p-0 min-w-0 min-h-[400px] overflow-hidden bg-[#000000]/40 backdrop-blur-3xl border border-sf-border">
          {selectedAgent ? (
              <>
                  <div className="p-4 border-b border-sf-border bg-sf-panel/50 backdrop-blur-md sticky top-0 z-10 flex flex-col justify-between shrink-0 gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                          <div className="bg-sf-accent/20 p-2 rounded-xl text-sf-accent shrink-0"><Brain size={20} /></div>
                          <div className="min-w-0">
                              <div className="font-semibold truncate">{selectedAgent.name} Config</div>
                              <div className="text-[0.65rem] font-mono opacity-50 uppercase tracking-wider truncate">ID: {selectedAgent.id}</div>
                          </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 flex-wrap">
                          <button className="btn-icon !bg-[#FF453A]/10 hover:!bg-[#FF453A]/20 !border-[#FF453A]/20 !text-[#FF453A]" onClick={handleDelete} title="Delete Agent">
                              <Trash2 size={16} />
                          </button>
                          <button className="btn-primary" onClick={() => toast.success('Agent saved to SQLite database!')}><Save size={16} /> Save</button>
                      </div>
                  </div>
                  
                  <div className="flex flex-col p-4 space-y-3  flex-1">
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div className="col-span-2 md:col-span-1">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Display Name</label>
                              <input type="text" value={selectedAgent.name} onChange={e => handleUpdate('name', e.target.value)} className="glass-input w-full" />
                          </div>
                          <div className="col-span-2 md:col-span-1">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Categorical Tag</label>
                              <input type="text" value={selectedAgent.tag} onChange={e => handleUpdate('tag', e.target.value)} className="glass-input w-full font-mono" placeholder="#frontend" />
                          </div>
                          
                          <div className="col-span-2">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Primary Role</label>
                              <input type="text" value={selectedAgent.role} onChange={e => handleUpdate('role', e.target.value)} className="glass-input w-full" />
                          </div>

                          <div className="col-span-2">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">System Prompt</label>
                              <textarea value={selectedAgent.system_prompt} onChange={e => handleUpdate('system_prompt', e.target.value)} className="glass-input w-full min-h-[120px] font-mono text-[0.85rem] resize-y" spellCheck={false} />
                          </div>
                          
                          <div className="col-span-2 md:col-span-1">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Goals (comma separated)</label>
                              <textarea value={selectedAgent.goals.join(', ')} onChange={e => handleUpdate('goals', e.target.value.split(',').map(s => s.trim()))} className="glass-input w-full min-h-[80px]" />
                          </div>

                          <div className="col-span-2 md:col-span-1 flex flex-col gap-3">
                              <div>
                                  <div className="flex justify-between items-center mb-2 ml-1">
                                      <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60">Temperature</label>
                                      <span className="text-[0.75rem] font-mono text-sf-accent">{selectedAgent.temperature}</span>
                                  </div>
                                  <input type="range" min="0" max="1" step="0.1" value={selectedAgent.temperature} onChange={e => handleUpdate('temperature', parseFloat(e.target.value))} className="w-full accent-sf-accent" />
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                  <div>
                                      <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">AI Provider</label>
                                      <select value={selectedAgent.ai_provider} onChange={e => handleUpdate('ai_provider', e.target.value)} className="glass-input w-full">
  <option value="OpenAI">OpenAI</option>
  <option value="Anthropic">Anthropic</option>
  <option value="Google">Google</option>
  <option value="Groq">Groq</option>
  <option value="Ollama">Ollama</option>
</select>
                                  </div>
                                  <div>
                                      <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">AI Model</label>
                                      <select value={selectedAgent.ai_model} onChange={e => handleUpdate('ai_model', e.target.value)} className="glass-input w-full">
  <option value="gpt-4-turbo">gpt-4-turbo</option>
  <option value="gpt-4o">gpt-4o</option>
  <option value="claude-3-opus">claude-3-opus</option>
  <option value="claude-3-5-sonnet">claude-3-5-sonnet</option>
  <option value="gemini-1.5-pro">gemini-1.5-pro</option>
  <option value="gemini-1.5-flash">gemini-1.5-flash</option>
  <option value="llama3">llama3</option>
</select>
                                  </div>
                              </div>
                          </div>

                          <div className="col-span-2 grid grid-cols-1 md:grid-cols-3 gap-3 pt-4 border-t border-sf-border/50">
                              <div>
                                  <label className="flex items-center gap-2 text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-3 ml-1"><Database size={14} /> Capabilities</label>
                                  <select multiple value={selectedAgent.capabilities} onChange={e => handleUpdate('capabilities', Array.from(e.target.selectedOptions, option => option.value))} className="glass-input w-full text-[0.8rem]" style={{ minHeight: '80px' }}>
  <option value="react">react</option>
  <option value="regex">regex</option>
  <option value="python">python</option>
  <option value="architecture">architecture</option>
  <option value="data-science">data-science</option>
  <option value="design">design</option>
</select>
                              </div>
                              <div>
                                  <label className="flex items-center gap-2 text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-3 ml-1"><Shield size={14} /> Permissions</label>
                                  <select multiple value={selectedAgent.permissions} onChange={e => handleUpdate('permissions', Array.from(e.target.selectedOptions, option => option.value))} className="glass-input w-full text-[0.8rem]" style={{ minHeight: '80px' }}>
  <option value="write_files">write_files</option>
  <option value="read_files">read_files</option>
  <option value="execute_code">execute_code</option>
  <option value="internet_access">internet_access</option>
</select>
                              </div>
                              <div>
                                  <label className="flex items-center gap-2 text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-3 ml-1"><Wrench size={14} /> Tools</label>
                                  <select multiple value={selectedAgent.tools} onChange={e => handleUpdate('tools', Array.from(e.target.selectedOptions, option => option.value))} className="glass-input w-full text-[0.8rem]" style={{ minHeight: '80px' }}>
  <option value="file_writer">file_writer</option>
  <option value="code_executor">code_executor</option>
  <option value="search_engine">search_engine</option>
  <option value="linter">linter</option>
  <option value="browser">browser</option>
</select>
                              </div>
                          </div>
                      </div>
                  </div>
              </>
          ) : (
              <div className="flex-grow flex flex-col items-center justify-center opacity-40">
                  <Brain size={48} className="mb-3" strokeWidth={1.5} />
                  <div className="text-lg font-semibold">No Agent Selected</div>
                  <div className="text-sm mt-1">Select an agent from the directory to configure</div>
              </div>
          )}
            </div>
    </div>
    </div>
  );
}