import React from 'react';

interface WorkspacePlaceholderProps {
    title: string;
    icon: React.ReactNode;
}

export function WorkspacePlaceholder({ title, icon }: WorkspacePlaceholderProps) {
    return (
        <div className="flex flex-col items-center justify-center w-full min-h-[280px] bg-sf-bg/20 rounded-2xl border border-dashed border-sf-border/50 text-sf-ink/50 gap-3 opacity-70 p-4 text-center">
            <div className="w-12 h-12 rounded-xl border border-white/10 bg-white/5 flex items-center justify-center text-sf-ink/50">
                {icon}
            </div>
            <div className="text-sm font-medium">{title}</div>
        </div>
    );
}
