import React from 'react';

interface PlaceholderProps {
    type?: 'list' | 'text' | 'compact' | 'chart';
    heightClass?: string;
}

export function Placeholder({ type = 'list', heightClass = 'h-[88px]' }: PlaceholderProps) {
    if (type === 'compact') {
        return (
            <div className={`p-3 bg-sf-bg/20 rounded-xl border border-dashed border-sf-border/50 relative shadow-sm opacity-50 flex flex-col justify-center gap-2 w-full ${heightClass}`}>
                <div className="h-4 bg-white/5 rounded w-1/3"></div>
                <div className="h-2 bg-white/5 rounded w-1/4"></div>
            </div>
        );
    }
    
    if (type === 'text') {
        return (
            <div className={`flex items-start gap-3 border-b border-sf-border/30 pb-2 last:border-0 p-1.5 rounded opacity-40 w-full ${heightClass}`}>
                <span className="text-sf-ink/20 shrink-0">[--:--:--]</span>
                <span className="shrink-0 min-w-[90px] text-sf-ink/20">---</span>
                <span className="text-sf-ink/20 break-words font-medium">Waiting for activity...</span>
            </div>
        );
    }

    if (type === 'chart') {
        return (
            <div className={`flex gap-1 w-full opacity-20 border border-dashed border-white/20 rounded bg-white/5 ${heightClass}`}></div>
        );
    }

    // Default 'list' type
    return (
        <div className={`p-4 rounded-xl border border-dashed border-sf-border/50 bg-sf-bg/20 flex flex-col items-start gap-3 opacity-50 justify-center w-full ${heightClass}`}>
            <div className="flex items-center gap-3 w-full">
                <div className="w-8 h-8 rounded-lg border border-white/20 shrink-0"></div>
                <div className="flex flex-col gap-2 w-full">
                    <div className="h-4 bg-white/5 rounded w-1/4"></div>
                    <div className="h-3 bg-white/5 rounded w-1/2"></div>
                </div>
            </div>
        </div>
    );
}

export function PlaceholderList({ count, type = 'list', heightClass }: { count: number, type?: 'list' | 'text' | 'compact' | 'chart', heightClass?: string }) {
    if (count <= 0) return null;
    return (
        <>
            {[...Array(count)].map((_, i) => (
                <Placeholder key={`placeholder-${i}`} type={type} heightClass={heightClass} />
            ))}
        </>
    );
}
