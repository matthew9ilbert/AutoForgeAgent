import React, { useState, useEffect } from 'react';
import { z } from 'zod';
import { fetchBackendConfig, saveBackendConfig } from '../utils/configLoader';
import { Eye, EyeOff, Save, Loader2, Key } from 'lucide-react';
import { toast } from '../lib/toast';

const configSchema = z.object({
  googleTokens: z.record(
    z.string(),
    z.string()
      .min(10, 'Token must be at least 10 characters')
      .regex(/^\S+$/, 'Token cannot contain spaces')
      .optional()
      .or(z.literal(''))
  ).optional(),
});

export function SettingsPanel() {
  const [googleTokens, setGoogleTokens] = useState<Record<string, string>>({});
  const [showMasked, setShowMasked] = useState<Record<string, boolean>>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchBackendConfig().then(config => {
      if (config && config.googleTokens) {
        setGoogleTokens(config.googleTokens);
      }
    });
  }, []);

  const handleSave = async () => {
    setIsLoading(true);
    try {
      // Validate
      const parsed = configSchema.parse({ googleTokens });
      
      const config = await fetchBackendConfig() || {};
      config.googleTokens = parsed.googleTokens;
      await saveBackendConfig(config);
      toast.success('Settings saved successfully.');
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(`Validation failed: ${(error as any).errors[0].message}`);
      } else {
        toast.error('An unexpected error occurred.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const services = ['Drive', 'Sheets', 'Gmail', 'Calendar', 'Docs', 'Tasks', 'Chat', 'Forms', 'Keep', 'Contacts', 'Meet'];

  return (
    <div className="flex flex-col gap-4 p-4 max-w-2xl mx-auto w-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">Security Settings</h2>
        <button onClick={handleSave} disabled={isLoading} className="btn-primary flex items-center gap-2">
          {isLoading ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />}
          Save Config
        </button>
      </div>

      <div className="card p-6 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-6 relative">
        <div className="flex items-center gap-3 border-b border-sf-border pb-4">
            <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                <Key size={20} />
            </div>
            <div className="flex flex-col">
                <span className="font-semibold text-lg">API Credentials</span>
                <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">Secure Key Vault</span>
            </div>
        </div>

        <div className="flex flex-col gap-4">
          {services.map(service => (
            <div key={service} className="flex flex-col gap-1">
              <label className="text-sm font-medium text-white/80">{service} API Key</label>
              <div className="relative">
                <input
                  type={showMasked[service] ? "text" : "password"}
                  value={googleTokens[service] || ''}
                  onChange={(e) => setGoogleTokens({ ...googleTokens, [service]: e.target.value })}
                  className="glass-input w-full pr-10 font-mono text-sm"
                  placeholder={`Enter ${service} credentials...`}
                />
                <button
                  onClick={() => setShowMasked({ ...showMasked, [service]: !showMasked[service] })}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
                >
                  {showMasked[service] ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
