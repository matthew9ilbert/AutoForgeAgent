import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router';
import { useWorkspacePresets } from '../hooks/useWorkspacePresets';
import { Bot } from 'lucide-react';
import { Search, File, Layout, Users, Settings, Database, Lightbulb, Terminal, ArrowRight } from 'lucide-react';

export function CommandPalette() {
  const { presets, activatePreset, activePreset } = useWorkspacePresets();
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    } else {
      setSearch('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const items: { id: string; label: string; icon: React.ReactNode; path: string; shortcut?: string }[] = [
    { id: 'home', label: 'AI Workspace', icon: <Layout size={16} />, path: '/' },
    { id: 'agents', label: 'Agents', icon: <Users size={16} />, path: '/agents' },
    { id: 'schema', label: 'Schema Builder', icon: <Database size={16} />, path: '/schema' },
    { id: 'archive', label: 'Archive', icon: <Database size={16} />, path: '/archive' },
    { id: 'ideas', label: 'Ideation', icon: <Lightbulb size={16} />, path: '/ideas' },
    { id: 'settings', label: 'Settings', icon: <Settings size={16} />, path: '/settings' },
    { id: 'teams', label: 'Teams', icon: <Users size={16} />, path: '/teams' },
    { id: 'testing', label: 'TDD Loop', icon: <Terminal size={16} />, path: '/testing' },
    { id: 'visualizer', label: 'Visualizer', icon: <Layout size={16} />, path: '/visualizer' },
    { id: 'search', label: 'Code Search', icon: <Search size={16} />, path: '/search' },
    { id: 'auditing', label: 'Auditing', icon: <File size={16} />, path: '/auditing' },
    { id: 'migrations', label: 'Migrations', icon: <Database size={16} />, path: '/migrations' },
    { id: 'profiler', label: 'Profiler', icon: <Layout size={16} />, path: '/profiler' },
    { id: 'guardrails', label: 'Guardrails', icon: <File size={16} />, path: '/guardrails' },
    { id: 'rollbacks', label: 'Rollbacks', icon: <File size={16} />, path: '/rollbacks' },
    { id: 'a11y', label: 'A11y Auto-Fixer', icon: <File size={16} />, path: '/a11y' },
    { id: 'design', label: 'Design Sync', icon: <Layout size={16} />, path: '/design' },
    { id: 'api-sync', label: 'API Sync', icon: <Database size={16} />, path: '/api-sync' },
  ];

  const mockFiles: { id: string; label: string; icon: React.ReactNode; path: string; shortcut?: string }[] = [
    { id: 'f1', label: 'App.tsx', icon: <File size={16} />, path: '/search?q=App.tsx' },
    { id: 'f2', label: 'useAppSync.ts', icon: <File size={16} />, path: '/search?q=useAppSync.ts' },
    { id: 'f3', label: 'config.json', icon: <File size={16} />, path: '/settings' },
    { id: 'f4', label: 'schema.ts', icon: <Database size={16} />, path: '/schema' },
    { id: 'f5', label: 'vite.config.ts', icon: <File size={16} />, path: '/search?q=vite.config.ts' }
  ];
  
  
  const presetCommands = presets.map((p, i) => ({
    id: 'preset_' + p.id,
    label: 'Preset: ' + p.name + (activePreset.id === p.id ? ' (Active)' : ''),
    icon: <Layout size={16} />,
    path: '#preset:' + p.id,
    isPreset: true,
    shortcut: i < 9 ? '⌘' + (i + 1) : undefined
  }));
  
  const agentCommands: { id: string; label: string; icon: React.ReactNode; path: string; shortcut?: string }[] = [
    { id: 'agent_chat', label: 'Agent: Open Chat', icon: <Bot size={16} />, path: '#agent:chat', shortcut: '⌘⇧C' },
    { id: 'agent_debug', label: 'Agent: Debug Current View', icon: <Bot size={16} />, path: '#agent:debug', shortcut: '⌘⇧D' },
    { id: 'agent_test', label: 'Agent: Generate Tests', icon: <Bot size={16} />, path: '#agent:test', shortcut: '⌘⇧T' },
  ];
  
  const allSearchable: any[] = [...presetCommands, ...agentCommands, ...items, ...mockFiles];


  const filteredItems = search ? allSearchable.filter(item => item.label.toLowerCase().includes(search.toLowerCase())) : items;

  const handleSelect = (path: string) => {
    if (path.startsWith('#preset:')) {
       activatePreset(path.split(':')[1]);
       setIsOpen(false);
       return;
    }
    if (path.startsWith('#agent:')) {
       const action = path.split(':')[1];
       window.dispatchEvent(new CustomEvent('sf_agent_action', { detail: { action } }));
       setIsOpen(false);
       return;
    }
    navigate(path);
    setIsOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-16 sm:pt-32 pb-16 bg-black/50 backdrop-blur-sm overflow-y-auto" onPointerDown={() => setIsOpen(false)}>
      <div 
        className="w-full max-w-xl bg-[#0f172a] border border-sf-border shadow-2xl rounded-2xl overflow-hidden flex flex-col"
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center px-4 py-3 border-b border-sf-border">
          <Search size={20} className="text-white/50 mr-3" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search commands, files, or settings..."
            className="w-full bg-transparent border-none outline-none text-white font-medium text-lg placeholder-white/30"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-1 text-[0.6rem] font-bold text-white/40 uppercase tracking-wider">
            <span className="bg-white/10 px-1.5 py-0.5 rounded border border-white/5">ESC</span>
          </div>
        </div>
        
        <div className="flex flex-col max-h-[400px] overflow-y-auto p-2">
          {filteredItems.length === 0 ? (
            <div className="p-4 text-center text-white/50 text-sm">No results found for "{search}"</div>
          ) : (
            <>
              <div className="text-[0.65rem] font-bold text-white/40 uppercase tracking-wider px-3 py-2">Workspaces & Views</div>
              {filteredItems.map((item, i) => (
                <button
                  key={item.id}
                  className="flex items-center justify-between w-full p-3 hover:bg-white/5 rounded-xl transition-colors text-left group"
                  onClick={() => handleSelect(item.path)}
                >
                  <div className="flex items-center gap-3">
                    <div className="bg-sf-bg border border-white/5 p-2 rounded-lg text-white/60 group-hover:text-sf-accent transition-colors">
                      {item.icon}
                    </div>
                    <span className="font-semibold text-sm">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.shortcut && (
                      <span className="text-[0.6rem] font-bold bg-white/10 text-white/50 px-1.5 py-0.5 rounded border border-white/5">
                        {item.shortcut}
                      </span>
                    )}
                    <ArrowRight size={14} className="text-white/30 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </button>
              ))}
            </>
          )}
        </div>
        
        <div className="px-4 py-3 border-t border-sf-border bg-black/20 flex items-center justify-between text-[0.7rem] text-white/40 font-medium">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5"><span className="bg-white/10 px-1 py-0.5 rounded">↑</span><span className="bg-white/10 px-1 py-0.5 rounded">↓</span> to navigate</span>
            <span className="flex items-center gap-1.5"><span className="bg-white/10 px-1.5 py-0.5 rounded">↵</span> to select</span>
          </div>
        </div>
      </div>
    </div>
  );
}
