import { Link, useLocation } from 'react-router';
import { ChevronRight, Home } from 'lucide-react';

const routeMap: Record<string, string> = {
  '': 'Dashboard',
  'settings': 'Settings',
  'agents': 'Agents',
  'teams': 'Teams',
  'schema': 'Schema Builder',
  'archive': 'Archive',
  'ideas': 'Ideas',
  'testing': 'Testing',
  'visualizer': 'Visualizer',
  'search': 'Search',
  'guardrails': 'Guardrails',
  'auditing': 'Auditing',
  'migrations': 'Migrations',
  'profiler': 'Profiler',
  'installer': 'Installer',
  'rollbacks': 'Rollbacks',
  'a11y': 'Accessibility',
  'design': 'Design Sync',
  'api-sync': 'API Sync'
};

export function Breadcrumbs() {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);

  return (
    <nav className="flex items-center px-4 h-[52px] border-b border-sf-border bg-sf-bg/80 backdrop-blur-md z-20 shrink-0 text-sm">
      <Link to="/" className="text-sf-ink/50 hover:text-sf-accent transition-colors flex items-center gap-1.5" title="Dashboard">
        <Home size={14} />
      </Link>
      
      {pathnames.length > 0 && (
        <ChevronRight size={14} className="mx-2 text-sf-ink/30 shrink-0" />
      )}
      
      {pathnames.length === 0 && (
        <span className="text-sf-ink font-medium truncate" aria-current="page">
          Dashboard
        </span>
      )}
      
      {pathnames.map((value, index) => {
        const last = index === pathnames.length - 1;
        const to = `/${pathnames.slice(0, index + 1).join('/')}`;
        const label = routeMap[value] || value.charAt(0).toUpperCase() + value.slice(1);

        return (
          <div key={to} className="flex items-center min-w-0">
            {last ? (
              <span className="text-sf-ink font-medium truncate" aria-current="page">
                {label}
              </span>
            ) : (
              <>
                <Link to={to} className="text-sf-ink/60 hover:text-sf-accent transition-colors truncate">
                  {label}
                </Link>
                <ChevronRight size={14} className="mx-2 text-sf-ink/30 shrink-0" />
              </>
            )}
          </div>
        );
      })}
    </nav>
  );
}
