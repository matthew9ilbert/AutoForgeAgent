import React from 'react';

interface ListPlaceholderProps {
    count: number;
    height?: number; // fallback height for simple blocks
    className?: string; // class for the container
}

export function ListPlaceholder({ count, height = 80, className = "" }: ListPlaceholderProps) {
    if (count <= 0) return null;
    return (
        <>
            {[...Array(count)].map((_, index) => (
                <div 
                    key={`placeholder-${index}`} 
                    className={`flex flex-col gap-2 p-3 bg-sf-bg/20 rounded-xl border border-dashed border-sf-border/50 relative shadow-sm opacity-50 justify-center ${className}`}
                    style={{ height: `${height}px` }}
                >
                    <div className="flex items-center gap-3 w-full">
                        <div className="w-8 h-8 rounded-lg bg-white/5 shrink-0"></div>
                        <div className="flex flex-col gap-2 w-full">
                            <div className="h-4 bg-white/5 rounded w-1/3"></div>
                            <div className="h-2 bg-white/5 rounded w-1/4"></div>
                        </div>
                    </div>
                </div>
            ))}
        </>
    );
}
