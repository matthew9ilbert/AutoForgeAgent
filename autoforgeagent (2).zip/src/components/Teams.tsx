import React, { useState, useCallback } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Network, Plus, ShieldAlert, Code2, Play, Save, Settings2 } from 'lucide-react';
import { ReactFlow, MiniMap, Controls, Background, useNodesState, useEdgesState, addEdge, Node, Edge, Connection, Position } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { toast } from '../lib/toast';

const initialNodes: Node[] = [
  {
    id: 'input',
    type: 'default',
    data: { label: (
      <div className="flex flex-col items-center p-2">
        <div className="font-bold text-[0.8rem]">Code Generator</div>
        <div className="text-[0.65rem] opacity-70">Model: GPT-4-Turbo</div>
      </div>
    ) },
    position: { x: 50, y: 150 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #a855f7', borderRadius: '12px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'headless',
    type: 'default',
    data: { label: (
      <div className="flex flex-col items-center p-2 gap-2">
        <Play size={24} className="text-[#38bdf8]" />
        <div className="font-bold text-[0.8rem]">Headless Browser</div>
        <div className="text-[0.65rem] opacity-70">Vitest / Playwright UI</div>
      </div>
    ) },
    position: { x: 300, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #38bdf8', borderRadius: '12px', minWidth: '140px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'auditor',
    type: 'default',
    data: { label: (
      <div className="flex flex-col items-center p-2 gap-2">
        <ShieldAlert size={24} className="text-[#FF453A]" />
        <div className="font-bold text-[0.8rem]">Unit Tests</div>
        <div className="text-[0.65rem] opacity-70">Feedback Loop (ReAct)</div>
      </div>
    ) },
    position: { x: 550, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #FF453A', borderRadius: '12px', minWidth: '140px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  }
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'input', target: 'headless', animated: true, style: { stroke: '#38bdf8', strokeWidth: 2 } },
  { id: 'e2', source: 'headless', target: 'auditor', animated: true, style: { stroke: '#FF453A', strokeWidth: 2 } },
  { id: 'e3', source: 'auditor', target: 'input', animated: true, style: { stroke: '#a855f7', strokeWidth: 2 } }
];

export function Teams() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback((params: Connection | Edge) => setEdges((eds) => addEdge(params, eds)), [setEdges]);

  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader 
         title="Agentic Workflows" 
         subtitle="Visual Agent orchestration"
      />
      <div className="card flex flex-col flex-1 min-h-[500px]">
          <div className="flex-1 w-full mt-2 relative" style={{ width: '100%', height: '100%', minHeight: '500px' }}>
              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                fitView
              >
                <Background color="#ccc" gap={16} />
                <Controls />
                <MiniMap />
              </ReactFlow>
          </div>
      </div>
    </div>
  );
}
