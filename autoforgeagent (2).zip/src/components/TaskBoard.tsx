import React, { useState } from 'react';
import { useSettings } from '../hooks/useSettings';
import { useSwarm } from '../contexts/SwarmContext';
import { Play, CheckCircle2, Clock, AlertCircle, Cpu, GripVertical, Plus, Send } from 'lucide-react';

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'backlog' | 'in_progress' | 'review' | 'completed';
  priority: 'Highest' | 'High' | 'Normal' | 'Low';
  taskType: 'feature' | 'bug' | 'architecture' | 'ui' | 'docs' | 'test' | 'maintenance';
}

const initialTasks: Task[] = [
  { id: 'TASK-1', title: 'Implement Auth Flow', status: 'in_progress', priority: 'Highest', taskType: 'feature' },
  { id: 'TASK-2', title: 'Fix Header Alignment', status: 'backlog', priority: 'Low', taskType: 'ui' },
  { id: 'TASK-3', title: 'DB Schema Generation', status: 'completed', priority: 'Normal', taskType: 'architecture' },
  { id: 'TASK-4', title: 'Security Audit', status: 'review', priority: 'High', taskType: 'maintenance' },
  { id: 'TASK-5', title: 'Write Unit Tests', status: 'backlog', priority: 'Normal', taskType: 'test' },
];

export function TaskBoard() {
  const { smartRouting } = useSettings();
  const { launchTask } = useSwarm();
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<Task['priority']>('Normal');
  const [newTaskType, setNewTaskType] = useState<Task['taskType']>('feature');

  const handleSubmitToSwarm = (task: Task) => {
    // Bundle state (mocked as simple string) and task description
    const projectState = JSON.stringify(tasks.map(t => ({ id: t.id, status: t.status })));
    const payload = `Task: ${task.title}\nPriority: ${task.priority}\nType: ${task.taskType}\nCurrent Project State: ${projectState}`;
    
    // Submit to swarm using context
    launchTask(payload, 'react-example', true, false);
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    
    const newTask: Task = {
      id: `TASK-${tasks.length + 1}`,
      title: newTaskTitle.trim(),
      status: 'backlog',
      priority: newTaskPriority,
      taskType: newTaskType,
    };
    setTasks([...tasks, newTask]);
    setNewTaskTitle('');
  };
  
  // Model routing logic
  const getRecommendedModel = (type: string) => {
    if (!smartRouting) return 'gemini-3.5-flash';
    switch (type) {
      case 'feature': return 'qwen2.5-coder:7b';
      case 'bug': return 'deepseek-v4';
      case 'architecture': return 'gpt-5.4';
      case 'ui': return 'qwen2.5-coder:7b';
      case 'test': return 'qwen2.5-coder:3b';
      case 'maintenance': return 'phi3:3.8b';
      case 'docs': return 'kimi';
      default: return 'gemini-3.5-flash';
    }
  };

  const columns = [
    { id: 'backlog', title: 'Backlog', icon: <Clock size={14} className="text-white/50" /> },
    { id: 'in_progress', title: 'In Progress', icon: <Play size={14} className="text-[#0A84FF]" /> },
    { id: 'review', title: 'Review', icon: <AlertCircle size={14} className="text-[#FF9F0A]" /> },
    { id: 'completed', title: 'Completed', icon: <CheckCircle2 size={14} className="text-[#30D158]" /> }
  ];

  const getPriorityColor = (p: string) => {
    if (p === 'Highest') return 'text-[#FF453A] border-[#FF453A]/20 bg-[#FF453A]/10';
    if (p === 'High') return 'text-[#FF9F0A] border-[#FF9F0A]/20 bg-[#FF9F0A]/10';
    if (p === 'Normal') return 'text-[#0A84FF] border-[#0A84FF]/20 bg-[#0A84FF]/10';
    return 'text-white/50 border-white/10 bg-white/5';
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full min-h-[400px] pb-4">
      <form onSubmit={handleAddTask} className="flex gap-2 items-center bg-black/20 p-2 rounded-xl border border-white/5">
        <input
          type="text"
          value={newTaskTitle}
          onChange={(e) => setNewTaskTitle(e.target.value)}
          placeholder="New task title..."
          className="glass-input flex-1 text-sm bg-transparent"
        />
        <select
          value={newTaskPriority}
          onChange={(e) => setNewTaskPriority(e.target.value as Task['priority'])}
          className="glass-input text-sm bg-sf-panel"
        >
          <option value="Highest">Highest</option>
          <option value="High">High</option>
          <option value="Normal">Normal</option>
          <option value="Low">Low</option>
        </select>
        <select
          value={newTaskType}
          onChange={(e) => setNewTaskType(e.target.value as Task['taskType'])}
          className="glass-input text-sm bg-sf-panel"
        >
          <option value="feature">Feature</option>
          <option value="bug">Bug</option>
          <option value="architecture">Architecture</option>
          <option value="ui">UI</option>
          <option value="docs">Docs</option>
          <option value="test">Test</option>
          <option value="maintenance">Maintenance</option>
        </select>
        <button type="submit" className="btn-primary p-2 h-[34px] w-[34px] flex items-center justify-center shrink-0">
          <Plus size={16} />
        </button>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-3 w-full h-full">
      {columns.map(col => (
        <div key={col.id} className="flex flex-col bg-black/20 rounded-2xl border border-white/5 overflow-hidden w-full">
          <div className="p-3 border-b border-white/5 bg-black/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              {col.icon}
              <span className="font-semibold text-sm">{col.title}</span>
            </div>
            <span className="text-[0.65rem] font-mono bg-white/10 px-1.5 py-0.5 rounded text-white/50">
              {tasks.filter(t => t.status === col.id).length}
            </span>
          </div>
          
          <div className="flex-1 p-2 flex flex-col gap-2 overflow-y-auto min-h-[300px]">
            {tasks.filter(t => t.status === col.id).map(task => (
              <div key={task.id} className="bg-sf-panel border border-sf-border p-3 rounded-xl shadow-sm cursor-grab active:cursor-grabbing hover:border-white/20 transition-all flex flex-col gap-2">
                <div className="flex items-start justify-between gap-2">
                  <span className="font-semibold text-sm leading-tight text-white/90">{task.title}</span>
                  <GripVertical size={14} className="text-white/20 shrink-0 mt-0.5" />
                </div>
                
                <div className="flex flex-wrap items-center gap-1.5 mt-1">
                  <span className={`text-[0.6rem] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                  
                  {smartRouting && (
                    <span className="text-[0.6rem] font-mono flex items-center gap-1 bg-sf-accent/10 text-sf-accent border border-sf-accent/20 px-1.5 py-0.5 rounded">
                      <Cpu size={10} />
                      {getRecommendedModel(task.taskType)}
                    </span>
                  )}
                  <button onClick={() => handleSubmitToSwarm(task)} className="ml-auto text-[0.6rem] font-bold uppercase tracking-wider flex items-center gap-1 bg-white/5 hover:bg-white/10 text-white/70 border border-white/10 px-1.5 py-0.5 rounded transition-colors"><Send size={10} /> Submit</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
    </div>
  );
}
