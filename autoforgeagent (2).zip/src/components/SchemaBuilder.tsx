import React, { useCallback, useEffect, useRef } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Database, Plus, Play, Download, Save, Link as LinkIcon, AlertCircle, Code } from 'lucide-react';
import { ReactFlow, MiniMap, Controls, Background, useNodesState, useEdgesState, addEdge, Node, Edge, Connection, Position, MarkerType, ReactFlowInstance } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { toast } from '../lib/toast';

const initialNodes: Node[] = [
  {
    id: 'users',
    type: 'default',
    data: { label: (
      <div className="flex flex-col text-left p-1">
        <div className="font-bold text-[#f59e0b] text-sm flex items-center gap-1.5 border-b border-white/10 pb-1 mb-1.5"><Database size={12}/> users</div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">id</span> <span className="opacity-50">uuid</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">email</span> <span className="opacity-50">varchar(255)</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">created_at</span> <span className="opacity-50">timestamp</span></div>
      </div>
    ) },
    position: { x: 250, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #334155', borderRadius: '12px', minWidth: '150px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'comments',
    type: 'default',
    data: { label: (
      <div className="flex flex-col text-left p-1">
        <div className="font-bold text-[#f59e0b] text-sm flex items-center gap-1.5 border-b border-white/10 pb-1 mb-1.5"><Database size={12}/> comments</div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">id</span> <span className="opacity-50">uuid</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">post_id</span> <span className="opacity-50">uuid</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">content</span> <span className="opacity-50">text</span></div>
      </div>
    ) },
    position: { x: 750, y: 150 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #334155', borderRadius: '12px', minWidth: '150px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'profiles',
    type: 'default',
    data: { label: (
      <div className="flex flex-col text-left p-1">
        <div className="font-bold text-[#f59e0b] text-sm flex items-center gap-1.5 border-b border-white/10 pb-1 mb-1.5"><Database size={12}/> profiles</div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">user_id</span> <span className="opacity-50">uuid</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">avatar_url</span> <span className="opacity-50">varchar(255)</span></div>
      </div>
    ) },
    position: { x: 250, y: 300 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #334155', borderRadius: '12px', minWidth: '150px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  }
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'users', target: 'comments', animated: true, style: { stroke: '#f59e0b', strokeWidth: 2 } },
  { id: 'e2', source: 'users', target: 'profiles', animated: true, style: { stroke: '#38bdf8', strokeWidth: 2 } }
];

export function SchemaBuilder() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback((params: Connection | Edge) => setEdges((eds) => addEdge(params, eds)), [setEdges]);

  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader 
         title="Schema Builder" 
         subtitle="Visual Database Modeling"
      />
      <div className="card flex flex-col flex-1 min-h-[500px]">
          <div className="flex-1 w-full mt-2 relative" style={{ width: '100%', height: '100%', minHeight: '500px' }}>
              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                fitView
              >
                <Background color="#ccc" gap={16} />
                <Controls />
                <MiniMap />
              </ReactFlow>
          </div>
      </div>
    </div>
  );
}
