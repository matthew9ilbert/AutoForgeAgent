import { useSwarm } from "../contexts/SwarmContext";
import { Send } from "lucide-react";
import React, { useState } from 'react';
import { toast } from '../lib/toast';
import { WorkspaceHeader } from './WorkspaceHeader';

export function Installer() {
  const [installState, setInstallState] = useState<'idle' | 'installing' | 'done'>('idle');
  const [logs, setLogs] = useState<string[]>([]);
  const { launchTask, status } = useSwarm();
  const [taskDesc, setTaskDesc] = useState('');
  
  const handleInstall = () => {
    setInstallState('installing');
    setLogs(['Initializing ReAct Loop scaffolding...']);
    
    const steps = [
      'Connecting to Google Gemini API (via AI Studio)...',
      'Configuring secondary cognitive tasks (Pollinations.ai)...',
      'Mapping Tool Layer: list_workspace -> os.listdir()',
      'Mapping Tool Layer: read_file -> open(file, \'r\')',
      'Mapping Tool Layer: write_file -> open(file, \'w\')',
      'Mapping Tool Layer: execute_code -> exec()',
      'Initializing Autonomous Loop...',
      'Setting up Plan, Action, Observation, Verification states...',
      'Injecting System Directive...',
      'Wiring up file-system tools...',
      'Scaffolding complete. Functional baseline established.'
    ];
    
    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        const stepText = steps[currentStep];
        setLogs(prev => [...prev, stepText]);
        currentStep++;
      } else {
        clearInterval(interval);
        setInstallState('done');
        toast.success('Architecture scaffolded successfully');
      }
    }, 800);
  };
  
  const handleSubmitTask = async () => {
    if (!taskDesc.trim()) {
      toast.error('Task description cannot be empty');
      return;
    }
    try {
      const payload = `Task: ${taskDesc}\nCurrent Project State: Installer architecture scaffolding.`;
      await launchTask(payload, 'react-example', true, false);
      toast.success('Task submitted successfully');
      setTaskDesc('');
    } catch (e: any) {
      toast.error('Failed to submit task: ' + e.message);
    }
  };
  
  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader title="System Installer" subtitle="Architecture Setup" />
      <div className="card flex flex-col gap-3 flex-1 ">
        <div>
           <h2 className="text-xl font-semibold mb-2">Agentic IDE Architecture</h2>
           <p className="opacity-70 text-[0.9rem] leading-relaxed mb-3">
             Package the entire autonomous architecture into a fully updated installer. This will scaffold the ReAct (Reasoning and Acting) loop, connect the free APIs, and wire up the file-system tools automatically to provide a functional baseline.
           </p>
           {installState === 'idle' && (
             <button onClick={handleInstall} className="btn-primary py-2 px-6">
               Start Installation
             </button>
           )}
        </div>
        
        {installState === 'done' && (
          <div className="mt-4 p-4 border border-sf-border rounded-xl bg-sf-bg/50">
             <h3 className="font-semibold mb-2">Submit Follow-Up Task</h3>
             <textarea 
               value={taskDesc}
               onChange={(e) => setTaskDesc(e.target.value)}
               className="glass-input w-full h-24 mb-3"
               placeholder="Describe the task to submit to the swarm..."
             />
             <div className="flex justify-between items-center">
               <span className="text-sm opacity-70">Swarm Status: {status}</span>
               <button onClick={handleSubmitTask} className="btn-primary flex items-center gap-2">
                 <Send size={16} /> Submit Task
               </button>
             </div>
          </div>
        )}
            
        {installState !== 'idle' && (
          <div className="flex-1 bg-black/40 rounded-xl border border-sf-border p-4 font-mono text-sm overflow-y-auto min-h-[300px]">
            {logs.map((log, i) => (
              <div key={i} className="mb-2 flex gap-2">
                <span className="text-sf-accent opacity-70">[{new Date().toLocaleTimeString()}]</span>
                <span className="text-white/80">{log}</span>
              </div>
            ))}
            {installState === 'installing' && (
              <div className="animate-pulse text-sf-accent mt-4">_</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
