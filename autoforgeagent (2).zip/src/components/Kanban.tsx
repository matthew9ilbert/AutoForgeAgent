import React from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { TaskBoard } from './TaskBoard';
import { Activity } from 'lucide-react';

export function Kanban() {
  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader 
         title="Kanban Board" 
         subtitle="Task Prioritization & Routing"
      />
      <div className="card flex flex-col flex-1 min-h-[500px]">
          <div className="label mb-2 flex justify-between items-center">
              <span>Task Prioritization</span>
              <span className="text-sf-accent font-bold tracking-widest text-[0.65rem] flex items-center gap-1">
                  <Activity size={10} className="animate-pulse" />
                  Auto-Routing Enabled
              </span>
          </div>
          <div className="flex-1 w-full overflow-hidden mt-2">
              <TaskBoard />
          </div>
      </div>
    </div>
  );
}
