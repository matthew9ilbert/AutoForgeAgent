import { SettingsPanel } from "./SettingsPanel";
import { useTheme } from '../hooks/useTheme';
import { useSettings } from '../hooks/useSettings';
import React, { useState, useRef } from 'react';
import { usePersistedState } from '../hooks/usePersistedState';
import { promptForFile, promptForSaveFile, loadConfig, saveConfig, fetchBackendConfig, saveBackendConfig } from '../utils/configLoader';
import { toast } from '../lib/toast';
import { Plus, Trash2, Save, Server, Key, Network, MoreVertical, X, Globe, Database, Loader2, CheckCircle2, Eye, EyeOff } from 'lucide-react';
import { WorkspaceHeader } from './WorkspaceHeader';

type ProviderType = 'Ollama' | 'Gemini' | 'OpenAI' | 'Anthropic' | 'Google' | 'Groq' | 'Custom Provider';

interface BaseProvider {
  id: string;
  type: ProviderType;
  models: string;
}

interface OllamaProvider extends BaseProvider {
  type: 'Ollama';
  urls: string[]; // up to 5
}

interface ApiProvider extends BaseProvider {
  type: 'Gemini' | 'OpenAI' | 'Anthropic' | 'Google' | 'Groq' | 'Custom Provider';
  name: string;
  endpoint: string;
  apiKeys: string;
}

type ProviderConfig = OllamaProvider | ApiProvider;

export function Settings() {
  const { theme, setTheme } = useTheme();
  const { smartRouting, setSmartRouting } = useSettings();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [driveFolderId, setDriveFolderId] = usePersistedState<string | null>('drive_folder_id', null);
  const [providersState, setProviders] = usePersistedState<ProviderConfig[]>('app_providers_config', [
    {
      id: '1',
      type: 'OpenAI',
      name: 'OpenAI Core',
      models: 'gpt-4-turbo, gpt-3.5-turbo',
      endpoint: 'https://api.openai.com/v1',
      apiKeys: 'sk-***************************',
    },
    {
      id: '2',
      type: 'Ollama',
      models: 'llama3, mistral',
      urls: ['http://localhost:11434'],
    },
    {
      id: '3',
      type: 'Anthropic',
      name: 'Anthropic Core',
      models: 'claude-3-opus, claude-3-sonnet',
      endpoint: 'https://api.anthropic.com/v1',
      apiKeys: 'sk-ant-***********************',
    },
    {
      id: '4',
      type: 'Google',
      name: 'Google Gemini',
      models: 'gemini-1.5-pro, gemini-1.5-flash',
      endpoint: 'https://generativelanguage.googleapis.com/v1beta',
      apiKeys: 'AIzaSy***********************',
    },
    {
      id: '5',
      type: 'Groq',
      name: 'Groq LPU',
      models: 'llama3-70b-8192, mixtral-8x7b-32768',
      endpoint: 'https://api.groq.com/openai/v1',
      apiKeys: 'gsk_**************************',
    }
  ]);
  const [showAddMenu, setShowAddMenu] = useState(false);
  const providers = providersState || [];

  const [accessUrlsState, setAccessUrls] = usePersistedState<{url: string, description: string}[]>('access_urls', [
    { url: 'http://127.0.0.1:5173', description: 'SwarmForge Frontend (Main App)' },
    { url: 'http://127.0.0.1:3000', description: 'OpenHands' },
    { url: 'http://127.0.0.1:8000', description: 'SwarmForge Backend' },
    { url: 'http://127.0.0.1:11434', description: 'Ollama' },
    { url: 'http://127.0.0.1:8080', description: 'Local Supabase Studio' },
  ]);

  const [showMasked, setShowMasked] = useState<Record<string, boolean>>({});
  const accessUrls = accessUrlsState || [];

  const handleEstablishSandbox = async () => {
      setIsCreatingFolder(true);
      try {
          const config = await fetchBackendConfig();
          let token = config?.googleTokens?.Drive;
          if (!token) {
              throw new Error('Please configure your Drive token below first.');
          }
          
          const response = await fetch('https://www.googleapis.com/drive/v3/files', {
              method: 'POST',
              headers: {
                  'Authorization': `Bearer ${token}`,
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                  name: 'Sandbox Project',
                  mimeType: 'application/vnd.google-apps.folder',
              })
          });
          
          if (!response.ok) {
              throw new Error('Failed to create folder');
          }
          
          const data = await response.json();
          setDriveFolderId(data.id);
          toast.success('Sandbox Project established in Google Drive!');
      } catch (e: any) {
          console.error(e);
          toast.error(e.message || 'Failed to establish Sandbox Project');
      } finally {
          setIsCreatingFolder(false);
      }
  };

  const handleAddProvider = (type: ProviderType) => {
    const newId = Math.random().toString(36).substr(2, 9);
    if (type === 'Ollama') {
      setProviders([...providers, { id: newId, type: 'Ollama', models: '', urls: [''] }]);
    } else {
      setProviders([...providers, { id: newId, type, name: '', models: '', endpoint: '', apiKeys: '' }]);
    }
    setShowAddMenu(false);
    toast.success(`Added ${type} provider configuration`);
  };

  const handleDelete = (id: string) => {
    setProviders(providers.filter(p => p.id !== id));
    toast.error('Provider configuration removed');
  };

  const updateProvider = (id: string, updates: Partial<ProviderConfig>) => {
    setProviders(providers.map(p => p.id === id ? { ...p, ...updates } as ProviderConfig : p));
  };

  const handleSave = () => {
    toast.success('Configuration saved to local storage');
  };

  const handleExportConfig = async () => {
    const config = { providers, accessUrls };
    try {
      const fileHandle = await promptForSaveFile();
      if (fileHandle) {
        await saveConfig(config, fileHandle);
        toast.success('Config saved to disk');
      } else {
        // Fallback to Blob download
        const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'config.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        toast.success('config.json exported');
      }
    } catch (err) {
      toast.error('Failed to export config');
    }
  };

  const handleAdvancedImport = async () => {
    try {
      const fileHandle = await promptForFile();
      if (fileHandle) {
        const config = await loadConfig(fileHandle);
        if (config) {
          if (config.providers) setProviders(config.providers);
          if (config.accessUrls) setAccessUrls(config.accessUrls);
          toast.success('Config loaded from disk');
        }
      } else {
        fileInputRef.current?.click();
      }
    } catch (err) {
      toast.error('Failed to import config');
    }
  };

  const handleImportConfig = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const config = JSON.parse(e.target?.result as string);
        if (config.providers) setProviders(config.providers);
        if (config.accessUrls) setAccessUrls(config.accessUrls);
        toast.success('config.json imported successfully');
      } catch (err) {
        toast.error('Failed to parse config.json');
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col gap-3 w-full min-h-full max-w-7xl mx-auto p-4 pb-24">
      <WorkspaceHeader 
        title="AI Configuration" 
        subtitle="LLM Models & Environment Nodes"
        actions={
          <div className="flex gap-2">
            <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={handleImportConfig} />
            <button onClick={handleAdvancedImport} className="btn-secondary">Import Config</button>
            <button onClick={handleExportConfig} className="btn-secondary">Export Config</button>
            <button onClick={handleSave} className="btn-primary"><Save size={16} /> Save Changes</button>
          </div>
        }
      />
      
      <div className="flex flex-col gap-3 pr-2">
        <div className="flex justify-between items-center mb-2 px-2 mt-3">
            <div className="label !mb-0">Provider Nodes</div>
            <div className="relative">
                <button className="btn-secondary" onClick={() => setShowAddMenu(!showAddMenu)}><Plus size={14} /></button>
                {showAddMenu && (
                    <div className="absolute top-full right-0 mt-2 w-[160px] bg-sf-panel/95 backdrop-blur-3xl border border-sf-border rounded-xl shadow-2xl p-2 z-50 flex flex-col gap-1">
                        <div className="text-[0.65rem] uppercase tracking-wider font-bold opacity-50 px-2 py-1 mb-1">Add Provider</div>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('Ollama')}>Ollama</button>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('Gemini')}>Gemini</button>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('OpenAI')}>OpenAI</button>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('Custom Provider')}>Custom Provider</button>
                    </div>
                )}
            </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
        {providers.map(provider => (
          <div key={provider.id} className="card p-4 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-3 relative group">
            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                <button className="btn-icon !bg-[#FF453A]/10 hover:!bg-[#FF453A]/20 !border-[#FF453A]/20 !text-[#FF453A]" onClick={() => handleDelete(provider.id)}><Trash2 size={14} /></button>
            </div>
            
            <div className="flex items-center gap-3 border-b border-sf-border pb-4">
                <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                    <Server size={20} />
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-lg">{provider.type === 'Ollama' ? 'Ollama' : (provider as ApiProvider).name || provider.type}</span>
                    <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">{provider.type} Node</span>
                </div>
            </div>

            {provider.type === 'Ollama' ? (
                <div className="grid grid-cols-1 gap-3 pt-2">
                    <div>
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">AI Models (comma separated)</label>
                        <input type="text" value={provider.models} onChange={(e) => updateProvider(provider.id, { models: e.target.value })} className="glass-input w-full " placeholder="llama3, mistral" />
                    </div>
                    <div>
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">Access URLs (up to 5)</label>
                        <div className="flex flex-col gap-2">
                            {provider.urls.map((url, i) => (
                                <div key={i} className="flex gap-2">
                                    <input type="text" value={url} onChange={(e) => {
                                        const newUrls = [...provider.urls];
                                        newUrls[i] = e.target.value;
                                        updateProvider(provider.id, { urls: newUrls });
                                    }} className="glass-input w-full " placeholder="http://localhost:11434" />
                                    {provider.urls.length > 1 && (
                                        <button className="btn-icon shrink-0" onClick={() => {
                                            const newUrls = provider.urls.filter((_, idx) => idx !== i);
                                            updateProvider(provider.id, { urls: newUrls });
                                        }}><X size={14} /></button>
                                    )}
                                </div>
                            ))}
                            {provider.urls.length < 5 && (
                                <button className="btn-secondary self-start" onClick={() => {
                                    updateProvider(provider.id, { urls: [...provider.urls, ''] });
                                }}>+ Add URL</button>
                            )}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                    <div className="md:col-span-2">
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">Provider Name</label>
                        <input type="text" value={(provider as ApiProvider).name} onChange={(e) => updateProvider(provider.id, { name: e.target.value })} className="glass-input w-full " placeholder="e.g. OpenAI Production" />
                    </div>
                    <div className="md:col-span-2">
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">AI Models (comma separated)</label>
                        <input type="text" value={provider.models} onChange={(e) => updateProvider(provider.id, { models: e.target.value })} className="glass-input w-full " placeholder="gpt-4-turbo, gpt-3.5-turbo" />
                    </div>
                    <div>
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">{provider.type === 'Custom Provider' ? 'Custom Base URL' : 'API Endpoint'}</label>
                        <input type="text" value={(provider as ApiProvider).endpoint} onChange={(e) => updateProvider(provider.id, { endpoint: e.target.value })} className="glass-input w-full " placeholder="https://api.openai.com/v1" />
                    </div>
                    <div className="md:col-span-2">
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">API Keys (comma separated)</label>
                        <div className="relative">
                                <input 
                                type={showMasked[provider.id] ? "text" : "password"} 
                                value={(provider as ApiProvider).apiKeys} 
                                onChange={(e) => updateProvider(provider.id, { apiKeys: e.target.value })} 
                                onBlur={(e) => {
                                    if (e.target.value && e.target.value.includes('*')) {
                                        toast.error(`Please provide a valid API key for ${provider.type}. The placeholder contains asterisks.`);
                                    } else if (e.target.value && e.target.value.length < 10) {
                                        toast.error(`API key for ${provider.type} seems too short.`);
                                    }
                                }}
                                className="glass-input w-full pl-9 pr-10" 
                                placeholder="sk-..." 
                            />
                            <Key size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                            <button
                                onClick={() => setShowMasked({ ...showMasked, [provider.id]: !showMasked[provider.id] })}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
                            >
                                {showMasked[provider.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                            </button>
                        </div>
                    </div>
                </div>
            )}
          </div>
        ))}
        </div>
        {providers.length === 0 && (
            <div className="text-center opacity-50 p-4 border border-dashed border-sf-border rounded-2xl">
                No AI Providers configured. Add one to get started.
            </div>
        )}


        <div className="label !mb-0 px-2 mt-3">Agentic Engine</div>
        <div className="card p-4 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-3 relative">
            <div className="flex items-center gap-3 border-b border-sf-border pb-4">
                <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                    <Server size={20} />
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-lg">Smart Model Routing</span>
                    <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">Automated AI Orchestration</span>
                </div>
            </div>
            <div className="flex items-center justify-between pt-2">
                <div className="flex flex-col gap-1">
                    <span className="font-medium text-white/90">Enable Smart Routing</span>
                    <span className="text-sm text-white/50">Automatically routes specialized coding tasks to the best equipped model (e.g., DeepSeek for bugs, Qwen for UI).</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" checked={smartRouting} onChange={(e) => setSmartRouting(e.target.checked)} />
                    <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sf-accent"></div>
                </label>
            </div>
        </div>

        <div className="label !mb-0 px-2 mt-3">Access URLs & Ports</div>
        <div className="card p-4 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-3 relative">
            <div className="flex items-center gap-3 border-b border-sf-border pb-4">
                <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                    <Globe size={20} />
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-lg">System Ports</span>
                    <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">Local Infrastructure</span>
                </div>
            </div>
            <div className="flex flex-col gap-3 pt-2">
                {accessUrls.map((item, i) => (
                    <div key={i} className="flex gap-3 items-center">
                        <input type="text" value={item.url} onChange={(e) => {
                            const newUrls = [...accessUrls];
                            newUrls[i].url = e.target.value;
                            setAccessUrls(newUrls);
                        }} 
                        onBlur={(e) => {
                            if (e.target.value && !/^https?:\/\//.test(e.target.value)) {
                                toast.error('URL must start with http:// or https://');
                            }
                        }}
                        className="glass-input w-[220px] font-mono text-[0.8rem]" placeholder="http://127.0.0.1:..." />
                        <span className="text-white/50 text-[0.85rem] font-bold">→</span>
                        <input type="text" value={item.description} onChange={(e) => {
                            const newUrls = [...accessUrls];
                            newUrls[i].description = e.target.value;
                            setAccessUrls(newUrls);
                        }} className="glass-input flex-grow text-[0.85rem]" placeholder="Description" />
                        <button className="btn-icon shrink-0" onClick={() => {
                            setAccessUrls(accessUrls.filter((_, idx) => idx !== i));
                        }}><X size={14} /></button>
                    </div>
                ))}
                <button className="btn-secondary self-start mt-1" onClick={() => {
                    setAccessUrls([...accessUrls, { url: '', description: '' }]);
                }}>+ Add Port</button>
            </div>
        </div>

        <div className="label !mb-0 px-2 mt-3">Workspace Integrations</div>
        <div className="card p-4 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-3 relative mb-6">
            <div className="flex items-center gap-3 border-b border-sf-border pb-4">
                <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                    <Database size={20} />
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-lg">Google Workspace</span>
                    <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">Drive, Docs, Sheets, Gmail, Calendar & More</span>
                </div>
            </div>
            <div className="flex items-center justify-between pt-2 border-b border-sf-border/50 pb-4">
                <div className="flex flex-col gap-1">
                    <span className="font-medium text-white/90">Sandbox Project Drive Directory</span>
                    <span className="text-sm text-white/50">Establish this project's cloud drive directory in your Google Drive.</span>
                </div>
                {driveFolderId ? (
                    <div className="flex items-center gap-2 bg-sf-accent/10 border border-sf-accent/30 text-sf-accent px-3 py-1.5 rounded-lg text-sm font-semibold">
                        <CheckCircle2 size={16} /> Established
                    </div>
                ) : (
                    <button onClick={handleEstablishSandbox} disabled={isCreatingFolder} className="btn-primary flex items-center gap-2">
                        {isCreatingFolder ? <Loader2 size={16} className="animate-spin" /> : null}
                        Establish Sandbox Project
                    </button>
                )}
            </div>
            <div className="flex items-center justify-between pt-2">
                <div className="flex flex-col gap-1">
                    <span className="font-medium text-white/90">Connected APIs</span>
                    <span className="text-sm text-white/50">Drive, Sheets, Gmail, Calendar, Docs, Tasks, Chat, Forms, Keep, Contacts, Meet, Picker</span>
                </div>
                <span className="text-[#30D158] font-bold text-sm bg-[#30D158]/10 px-3 py-1 rounded-full">Connected</span>
            </div>
        </div>        <SettingsPanel />
      </div>
    </div>
  );
}

