import { toast as sonnerToast, ToastT } from 'sonner';

let lastToastTime = 0;
const TOAST_THROTTLE_MS = 10000; // Limit to 1 toast per 10 seconds

export const toast = {
  success: (msg: string, options?: any) => {
    const now = Date.now();
    if (now - lastToastTime > TOAST_THROTTLE_MS) {
      lastToastTime = now;
      sonnerToast.success(msg, options);
    }
  },
  error: (msg: string, options?: any) => {
    const now = Date.now();
    if (now - lastToastTime > TOAST_THROTTLE_MS) {
      lastToastTime = now;
      sonnerToast.error(msg, options);
    }
  },
  info: (msg: string, options?: any) => {
    const now = Date.now();
    if (now - lastToastTime > TOAST_THROTTLE_MS) {
      lastToastTime = now;
      sonnerToast.info(msg, options);
    }
  },
  warning: (msg: string, options?: any) => {
    const now = Date.now();
    if (now - lastToastTime > TOAST_THROTTLE_MS) {
      lastToastTime = now;
      sonnerToast.warning(msg, options);
    }
  }
};
