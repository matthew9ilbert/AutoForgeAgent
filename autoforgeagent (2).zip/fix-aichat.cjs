const fs = require('fs');

const initialMessage = `Autonomous AI App Factory
# Agentic IDE / Vibe Coding Architecture

### Mission
Build an autonomous AI software engineering platform that provides a seamless "agentic IDE" experience comparable to leading AI development environments. The platform shall function as a unified development operating system where the AI plans, edits, executes, validates, previews, and iteratively improves software with minimal user intervention while maintaining transparency, safety, and recoverability.
The user should primarily communicate objectives in natural language. The platform is responsible for determining implementation details, selecting tools, executing workflows, validating outcomes, and presenting progress.

### Core Development Philosophy
Every software modification shall follow a continuous autonomous engineering loop.
Observe -> Understand -> Plan -> Select Tools -> Execute -> Observe Results -> Validate -> Repair (if needed) -> Repeat -> Complete -> Document -> Archive Knowledge

The platform shall continue iterating until the defined success criteria are met or a configured policy requires user approval.

### Unified Agentic Workspace
The development environment shall integrate all major activities into a single workspace.
Components include:
- AI Assistant
- Code Editor
- File Explorer
- Terminal
- Runtime
- Live Preview
- Logs
- Agent Activity Feed
- Background Tasks
- Notifications
- Memory Panel

The user should never need to manually synchronize changes between these components.

### Instant Feedback Loop
The application shall minimize friction through:
- Automatic file synchronization
- Live code updates
- Hot reload
- Embedded previews
- Automatic log streaming
- Immediate test execution
- Continuous diagnostics

Whenever practical, users should see the impact of changes immediately.

### Safe Execution Environment
All AI-generated modifications shall execute inside an isolated workspace.
Requirements include: Workspace snapshots, File versioning, Rollback capability, Preview before deployment, Automatic backup, Crash recovery, Checkpoints.
No destructive change should occur without a recovery path.

### Autonomous Development Loop
Each objective follows this lifecycle:
1. Analyze the request.
2. Build an implementation plan.
3. Decompose into tasks.
4. Select the required agents.
5. Select the appropriate models.
6. Execute one task.
7. Observe outputs.
8. Validate against success criteria.
9. Repair failures.
10. Repeat until complete.

The system should avoid asking the user for routine implementation decisions that can be resolved through established project policies.

### Continuous Quality Gates
Every implementation must satisfy automated validation before progressing.
Required checks include: Build success, Static analysis, Unit tests, Integration tests, Security scanning, Accessibility validation, Documentation completeness, Performance thresholds.
Failed validations automatically generate follow-up repair work.

### User Experience Goals
The finished platform should provide an experience where the user can describe an idea in natural language and observe autonomous progress through planning, implementation, testing, previews, and validation within a single integrated workspace.
The environment should emphasize rapid feedback, continuous visibility, explainable automation, safe execution, and high-confidence iterative development rather than isolated code generation.`;

let code = fs.readFileSync('src/components/AIChat.tsx', 'utf8');

code = code.replace(
    /content: 'Hello! I am your Agentic AI assistant[^']*'/,
    "content: initialMessage"
);
code = code.replace(
    /export function AIChat/,
    "const initialMessage = `" + initialMessage.replace(/`/g, "\\`") + "`;\n\nexport function AIChat"
);

code = code.replace(
    /\{msg.content\}/,
    `<div className="whitespace-pre-wrap">{msg.content}</div>`
);

fs.writeFileSync('src/components/AIChat.tsx', code);
