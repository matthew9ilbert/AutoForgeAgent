const fs = require('fs');
let code = fs.readFileSync('src/components/Settings.tsx', 'utf8');
code = code.replace("  const handleEstablishSandbox = async () => {", "  const [showMasked, setShowMasked] = useState<Record<string, boolean>>({});\n\n  const handleEstablishSandbox = async () => {");
fs.writeFileSync('src/components/Settings.tsx', code);
