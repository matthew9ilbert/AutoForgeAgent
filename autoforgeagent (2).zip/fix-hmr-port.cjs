const fs = require('fs');

let viteConfig = fs.readFileSync('vite.config.ts', 'utf8');
viteConfig = viteConfig.replace(
    /hmr:\s*false/g,
    'hmr: { port: 0, strictPort: false }'
);
fs.writeFileSync('vite.config.ts', viteConfig);

let serverConfig = fs.readFileSync('server.ts', 'utf8');
serverConfig = serverConfig.replace(
    /hmr:\s*false/g,
    'hmr: { port: 0, strictPort: false }'
);
fs.writeFileSync('server.ts', serverConfig);
