const fs = require('fs');
let code = fs.readFileSync('src/main.tsx', 'utf8');

const suppression = `
// Suppress Monaco Editor cancellation errors from polluting the console
window.addEventListener('unhandledrejection', (event) => {
  if (event.reason && event.reason.name === 'Canceled' || (event.reason && event.reason.message === 'Canceled') || (event.reason && event.reason.type === 'cancelation')) {
    event.preventDefault();
  }
});
`;

if (!code.includes('unhandledrejection')) {
  code = code.replace("import './index.css';", "import './index.css';\n" + suppression);
  fs.writeFileSync('src/main.tsx', code);
}
