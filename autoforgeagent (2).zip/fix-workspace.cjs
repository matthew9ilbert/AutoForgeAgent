const fs = require('fs');
let code = fs.readFileSync('src/components/RightWorkspace.tsx', 'utf8');

// Fix 1: Add isContainerReady state
code = code.replace(
    `const [showEditor, setShowEditor] = useState(false);`,
    `const [showEditor, setShowEditor] = useState(false);\n  const [isContainerReady, setIsContainerReady] = useState(false);`
);

// Fix 2: Modify useEffect for showEditor to ensure container is ready
code = code.replace(
    `useEffect(() => {\n    let timer = setTimeout(() => setShowEditor(true), 100);\n    return () => clearTimeout(timer);\n  }, []);`,
    `useEffect(() => {\n    setIsContainerReady(true);\n    let timer = setTimeout(() => setShowEditor(true), 200);\n    return () => {\n      clearTimeout(timer);\n      setShowEditor(false);\n    };\n  }, []);`
);

// Fix 3: Add condition for editor render
code = code.replace(
    `{showEditor && (`,
    `{showEditor && isContainerReady && (`
);

fs.writeFileSync('src/components/RightWorkspace.tsx', code);
