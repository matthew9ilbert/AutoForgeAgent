const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
    `hmr: false`,
    `hmr: process.env.DISABLE_HMR === 'true' ? false : { port: 24678, strictPort: false }`
);

fs.writeFileSync('server.ts', code);
