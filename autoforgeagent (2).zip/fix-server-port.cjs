const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const oldBlock = `  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(\`Server running on http://localhost:\${PORT}\`);
  });

  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      console.error('Port 3000 is in use, retrying in 1s...');
      setTimeout(() => {
        server.close();
        server.listen(PORT, '0.0.0.0');
      }, 1000);
    }
  });`;

const newBlock = `  let currentPort = PORT;
  const startListening = () => {
    const server = app.listen(currentPort, '0.0.0.0', () => {
      console.log(\`Server running on http://localhost:\${currentPort}\`);
    });

    server.on('error', (e: any) => {
      if (e.code === 'EADDRINUSE') {
        console.error(\`Port \${currentPort} is in use, trying alternative port \${currentPort + 1}...\`);
        currentPort++;
        startListening();
      }
    });
  };
  startListening();`;

code = code.replace(oldBlock, newBlock);
fs.writeFileSync('server.ts', code);
