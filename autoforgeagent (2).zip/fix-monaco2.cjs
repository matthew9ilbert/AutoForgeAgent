const fs = require('fs');
let code = fs.readFileSync('src/components/RightWorkspace.tsx', 'utf8');

if (!code.includes('const containerRef = useRef<HTMLDivElement>(null)')) {
    code = code.replace(
        'const editorRef = useRef<any>(null);',
        'const editorRef = useRef<any>(null);\n  const containerRef = useRef<HTMLDivElement>(null);'
    );
    
    code = code.replace(
        `useEffect(() => {
    setIsContainerReady(true);
    let timer = setTimeout(() => setShowEditor(true), 200);`,
        `useEffect(() => {
    if (containerRef.current) {
        setIsContainerReady(true);
    }
    let timer = setTimeout(() => setShowEditor(true), 200);`
    );
    
    code = code.replace(
        `<div className="flex-grow bg-[#1e1e1e] relative overflow-hidden" onMouseLeave={() => setHoverDiagnostic(null)}>`,
        `<div ref={containerRef} className="flex-grow bg-[#1e1e1e] relative overflow-hidden" onMouseLeave={() => setHoverDiagnostic(null)}>`
    );
}

// Add onUnmount cleanup if not present
if (!code.includes('onUnmount={handleEditorWillUnmount}')) {
    code = code.replace(
        'const handleEditorDidMount = (editor: any, monaco: any) => {',
        `const handleEditorWillUnmount = (editor: any) => {
    if (editor) {
        try {
            // Explictly dispose to prevent InstantiationService leaks
            editor.dispose();
        } catch (e) {}
    }
  };

  const handleEditorDidMount = (editor: any, monaco: any) => {`
    );
    
    code = code.replace(
        `onMount={handleEditorDidMount}`,
        `onMount={handleEditorDidMount}\n                    onUnmount={handleEditorWillUnmount}`
    );
}

fs.writeFileSync('src/components/RightWorkspace.tsx', code);
