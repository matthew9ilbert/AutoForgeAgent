const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');
const replacement = `.glass-input {
    @apply bg-black/20 backdrop-blur-md border border-white/10 rounded-xl px-4 py-2 text-[0.85rem] text-sf-ink placeholder:text-white/30 focus:border-sf-accent outline-none transition-all;
  }
  
  select.glass-input option {
    @apply bg-[#1c1c1e] text-white;
  }`;
css = css.replace(/\.glass-input \{[\s\S]*?transition-all;\n  \}/, replacement);
fs.writeFileSync('src/index.css', css);
