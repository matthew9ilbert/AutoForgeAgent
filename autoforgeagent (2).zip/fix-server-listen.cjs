const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const listenBlock = `  app.listen(PORT, '0.0.0.0', () => {
    console.log(\`Server running on http://localhost:\${PORT}\`);
  });`;

const newListenBlock = `  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(\`Server running on http://localhost:\${PORT}\`);
  });

  server.on('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      console.error('Port 3000 is in use, retrying in 1s...');
      setTimeout(() => {
        server.close();
        server.listen(PORT, '0.0.0.0');
      }, 1000);
    }
  });`;

code = code.replace(listenBlock, newListenBlock);
fs.writeFileSync('server.ts', code);
