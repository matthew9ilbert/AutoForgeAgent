const fs = require('fs');

let viteConfig = fs.readFileSync('vite.config.ts', 'utf8');
viteConfig = viteConfig.replace(
    /hmr: false,/g,
    `hmr: process.env.DISABLE_HMR === 'true' ? false : { port: 24678, strictPort: false },`
);
fs.writeFileSync('vite.config.ts', viteConfig);

let serverConfig = fs.readFileSync('server.ts', 'utf8');
serverConfig = serverConfig.replace(
    /hmr: false/g,
    `hmr: process.env.DISABLE_HMR === 'true' ? false : { port: 24678, strictPort: false }`
);
fs.writeFileSync('server.ts', serverConfig);
