const fs = require('fs');
let code = fs.readFileSync('src/components/RightWorkspace.tsx', 'utf8');

// Remove onUnmount prop
code = code.replace(/\s*onUnmount=\{handleEditorWillUnmount\}/g, '');

// Remove handleEditorWillUnmount function
const regex = /const handleEditorWillUnmount = \(editor: any\) => \{[\s\S]*?catch \(e\) \{\}\n    \}\n  \};/;
code = code.replace(regex, '');

fs.writeFileSync('src/components/RightWorkspace.tsx', code);
