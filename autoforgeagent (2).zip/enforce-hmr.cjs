const fs = require('fs');

let viteConfig = fs.readFileSync('vite.config.ts', 'utf8');
viteConfig = viteConfig.replace(
    /hmr:.*?\{.*?\}.*?,/g,
    'hmr: false,'
);
viteConfig = viteConfig.replace(
    /hmr:.*?\?.*?false.*?false.*?\}?,/g,
    'hmr: false,'
);
fs.writeFileSync('vite.config.ts', viteConfig);

let serverConfig = fs.readFileSync('server.ts', 'utf8');
serverConfig = serverConfig.replace(
    /hmr:.*?\{.*?\}.*?/g,
    'hmr: false'
);
serverConfig = serverConfig.replace(
    /hmr:.*?\?.*?false.*?false.*?\}/g,
    'hmr: false'
);
fs.writeFileSync('server.ts', serverConfig);
