const fs = require('fs');
let code = fs.readFileSync('vite.config.ts', 'utf8');

code = code.replace(
    /server: \{/,
    `server: {\n      port: 3000,\n      strictPort: false,`
);

fs.writeFileSync('vite.config.ts', code);
