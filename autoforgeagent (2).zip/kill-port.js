const { execSync } = require('child_process');
try {
  console.log('Attempting to kill processes on port 3000...');
  execSync('lsof -ti:3000 | xargs kill -9');
} catch (e) {
  // Ignore if nothing is listening or no lsof
}
