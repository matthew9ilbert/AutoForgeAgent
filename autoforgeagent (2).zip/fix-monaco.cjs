const fs = require('fs');
let code = fs.readFileSync('src/components/RightWorkspace.tsx', 'utf8');

// Add a ref to store disposables
if (!code.includes('const editorDisposables = useRef<any[]>([])')) {
    code = code.replace(
        'const editorRef = useRef<any>(null);',
        'const editorRef = useRef<any>(null);\n  const editorDisposables = useRef<any[]>([]);'
    );
}

// Update the handleEditorDidMount to clear previous disposables and store the new ones
code = code.replace(
    'const handleEditorDidMount = (editor: any, monaco: any) => {',
    `const handleEditorDidMount = (editor: any, monaco: any) => {
    editorDisposables.current.forEach(d => {
        if (d && typeof d.dispose === 'function') d.dispose();
    });
    editorDisposables.current = [];`
);

// Capture the onMouseMove disposable
code = code.replace(
    'editor.onMouseMove((e) => {',
    'const mouseMoveDisposable = editor.onMouseMove((e: any) => {'
);

// After the mouse move block (find the setTimeout), push to disposables
code = code.replace(
    /      setTimeout\(\(\) => {/g,
    `      editorDisposables.current.push(mouseMoveDisposable);
      setTimeout(() => {`
);

// Add cleanup to useEffect
if (!code.includes('editorDisposables.current.forEach')) {
    code = code.replace(
        `clearTimeout(timer);\n      setShowEditor(false);\n    };\n  }, []);`,
        `clearTimeout(timer);\n      setShowEditor(false);\n      editorDisposables.current.forEach(d => {\n        if (d && typeof d.dispose === 'function') d.dispose();\n      });\n    };\n  }, []);`
    );
}

fs.writeFileSync('src/components/RightWorkspace.tsx', code);
