const fs = require('fs');

let settingsCode = fs.readFileSync('src/components/Settings.tsx', 'utf8');

settingsCode = settingsCode.replace(
    `const [providers, setProviders] = usePersistedState<ProviderConfig[]>('app_providers_config', [`,
    `const [providersState, setProviders] = usePersistedState<ProviderConfig[]>('app_providers_config', [`
);
settingsCode = settingsCode.replace(
    `  const [showAddMenu, setShowAddMenu] = useState(false);`,
    `  const [showAddMenu, setShowAddMenu] = useState(false);\n  const providers = providersState || [];`
);

settingsCode = settingsCode.replace(
    `const [accessUrls, setAccessUrls] = usePersistedState<{url: string, description: string}[]>('access_urls', [`,
    `const [accessUrlsState, setAccessUrls] = usePersistedState<{url: string, description: string}[]>('access_urls', [`
);
settingsCode = settingsCode.replace(
    `  const [showMasked, setShowMasked] = useState<Record<string, boolean>>({});`,
    `  const [showMasked, setShowMasked] = useState<Record<string, boolean>>({});\n  const accessUrls = accessUrlsState || [];`
);

fs.writeFileSync('src/components/Settings.tsx', settingsCode);
