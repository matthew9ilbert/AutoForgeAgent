import React, { useState } from 'react';
import { toast } from '../lib/toast';
import { Plus, Trash2, Save, Server, Key, Network, MoreVertical, X, Globe } from 'lucide-react';
import { WorkspaceHeader } from './WorkspaceHeader';

type ProviderType = 'Ollama' | 'Gemini' | 'OpenAI' | 'Custom Provider';

interface BaseProvider {
  id: string;
  type: ProviderType;
  models: string;
}

interface OllamaProvider extends BaseProvider {
  type: 'Ollama';
  urls: string[]; // up to 5
}

interface ApiProvider extends BaseProvider {
  type: 'Gemini' | 'OpenAI' | 'Custom Provider';
  name: string;
  endpoint: string;
  apiKeys: string;
}

type ProviderConfig = OllamaProvider | ApiProvider;

export function Settings() {
  const [providers, setProviders] = useState<ProviderConfig[]>([
    {
      id: '1',
      type: 'OpenAI',
      name: 'OpenAI Core',
      models: 'gpt-4-turbo, gpt-3.5-turbo',
      endpoint: 'https://api.openai.com/v1',
      apiKeys: 'sk-***************************',
    },
    {
      id: '2',
      type: 'Ollama',
      models: 'llama3, mistral',
      urls: ['http://localhost:11434'],
    }
  ]);
  const [showAddMenu, setShowAddMenu] = useState(false);

  const [accessUrls, setAccessUrls] = useState<{url: string, description: string}[]>([
    { url: 'http://127.0.0.1:5173', description: 'SwarmForge Frontend (Main App)' },
    { url: 'http://127.0.0.1:3000', description: 'OpenHands' },
    { url: 'http://127.0.0.1:8000', description: 'SwarmForge Backend' },
    { url: 'http://127.0.0.1:11434', description: 'Ollama' },
  ]);

  const handleAddProvider = (type: ProviderType) => {
    const newId = Math.random().toString(36).substr(2, 9);
    if (type === 'Ollama') {
      setProviders([...providers, { id: newId, type: 'Ollama', models: '', urls: [''] }]);
    } else {
      setProviders([...providers, { id: newId, type, name: '', models: '', endpoint: '', apiKeys: '' }]);
    }
    setShowAddMenu(false);
    toast.success(`Added ${type} provider configuration`);
  };

  const handleDelete = (id: string) => {
    setProviders(providers.filter(p => p.id !== id));
    toast.error('Provider configuration removed');
  };

  const updateProvider = (id: string, updates: Partial<ProviderConfig>) => {
    setProviders(providers.map(p => p.id === id ? { ...p, ...updates } as ProviderConfig : p));
  };

  const handleSave = () => {
    toast.success('Configuration saved successfully');
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="AI Configuration" 
        subtitle="LLM Models & Environment Nodes"
        actions={
          <button onClick={handleSave} className="btn-primary"><Save size={12} /> Save Changes</button>
        }
      />
      
      <div className="flex flex-col gap-4 pr-2">
        <div className="flex justify-between items-center mb-2 px-2 mt-4">
            <div className="label !mb-0">Provider Nodes</div>
            <div className="relative">
                <button className="btn-secondary" onClick={() => setShowAddMenu(!showAddMenu)}><Plus size={14} /></button>
                {showAddMenu && (
                    <div className="absolute top-full right-0 mt-2 w-[160px] bg-sf-panel/95 backdrop-blur-3xl border border-sf-border rounded-xl shadow-2xl p-2 z-50 flex flex-col gap-1">
                        <div className="text-[0.65rem] uppercase tracking-wider font-bold opacity-50 px-2 py-1 mb-1">Add Provider</div>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('Ollama')}>Ollama</button>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('Gemini')}>Gemini</button>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('OpenAI')}>OpenAI</button>
                        <button className="text-left px-3 py-2 text-[0.85rem] font-medium rounded-lg hover:bg-white/5 transition-colors" onClick={() => handleAddProvider('Custom Provider')}>Custom Provider</button>
                    </div>
                )}
            </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {providers.map(provider => (
          <div key={provider.id} className="card p-6 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-4 relative group">
            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                <button className="btn-icon !bg-[#FF453A]/10 hover:!bg-[#FF453A]/20 !border-[#FF453A]/20 !text-[#FF453A]" onClick={() => handleDelete(provider.id)}><Trash2 size={14} /></button>
            </div>
            
            <div className="flex items-center gap-3 border-b border-sf-border pb-4">
                <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                    <Server size={20} />
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-lg">{provider.type === 'Ollama' ? 'Ollama' : (provider as ApiProvider).name || provider.type}</span>
                    <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">{provider.type} Node</span>
                </div>
            </div>

            {provider.type === 'Ollama' ? (
                <div className="grid grid-cols-1 gap-4 pt-2">
                    <div>
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">AI Models (comma separated)</label>
                        <input type="text" value={provider.models} onChange={(e) => updateProvider(provider.id, { models: e.target.value })} className="glass-input w-full " placeholder="llama3, mistral" />
                    </div>
                    <div>
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">Access URLs (up to 5)</label>
                        <div className="flex flex-col gap-2">
                            {provider.urls.map((url, i) => (
                                <div key={i} className="flex gap-2">
                                    <input type="text" value={url} onChange={(e) => {
                                        const newUrls = [...provider.urls];
                                        newUrls[i] = e.target.value;
                                        updateProvider(provider.id, { urls: newUrls });
                                    }} className="glass-input w-full " placeholder="http://localhost:11434" />
                                    {provider.urls.length > 1 && (
                                        <button className="btn-icon shrink-0" onClick={() => {
                                            const newUrls = provider.urls.filter((_, idx) => idx !== i);
                                            updateProvider(provider.id, { urls: newUrls });
                                        }}><X size={14} /></button>
                                    )}
                                </div>
                            ))}
                            {provider.urls.length < 5 && (
                                <button className="btn-secondary self-start" onClick={() => {
                                    updateProvider(provider.id, { urls: [...provider.urls, ''] });
                                }}>+ Add URL</button>
                            )}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                    <div className="md:col-span-2">
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">Provider Name</label>
                        <input type="text" value={(provider as ApiProvider).name} onChange={(e) => updateProvider(provider.id, { name: e.target.value })} className="glass-input w-full " placeholder="e.g. OpenAI Production" />
                    </div>
                    <div className="md:col-span-2">
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">AI Models (comma separated)</label>
                        <input type="text" value={provider.models} onChange={(e) => updateProvider(provider.id, { models: e.target.value })} className="glass-input w-full " placeholder="gpt-4-turbo, gpt-3.5-turbo" />
                    </div>
                    <div>
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">{provider.type === 'Custom Provider' ? 'Custom Base URL' : 'API Endpoint'}</label>
                        <input type="text" value={(provider as ApiProvider).endpoint} onChange={(e) => updateProvider(provider.id, { endpoint: e.target.value })} className="glass-input w-full " placeholder="https://api.openai.com/v1" />
                    </div>
                    <div className="md:col-span-2">
                        <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-1.5 ml-1">API Keys (comma separated)</label>
                        <div className="relative">
                            <input type="password" value={(provider as ApiProvider).apiKeys} onChange={(e) => updateProvider(provider.id, { apiKeys: e.target.value })} className="glass-input w-full  pl-9" placeholder="sk-..." />
                            <Key size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
                        </div>
                    </div>
                </div>
            )}
          </div>
        ))}
        </div>
        {providers.length === 0 && (
            <div className="text-center opacity-50 p-8 border border-dashed border-sf-border rounded-2xl">
                No AI Providers configured. Add one to get started.
            </div>
        )}

        <div className="label !mb-0 px-2 mt-4">Access URLs & Ports</div>
        <div className="card p-6 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm flex flex-col gap-4 relative">
            <div className="flex items-center gap-3 border-b border-sf-border pb-4">
                <div className="p-2 bg-sf-accent/10 rounded-xl text-sf-accent">
                    <Globe size={20} />
                </div>
                <div className="flex flex-col">
                    <span className="font-semibold text-lg">System Ports</span>
                    <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50">Local Infrastructure</span>
                </div>
            </div>
            <div className="flex flex-col gap-3 pt-2">
                {accessUrls.map((item, i) => (
                    <div key={i} className="flex gap-3 items-center">
                        <input type="text" value={item.url} onChange={(e) => {
                            const newUrls = [...accessUrls];
                            newUrls[i].url = e.target.value;
                            setAccessUrls(newUrls);
                        }} className="glass-input w-[220px] font-mono text-[0.8rem]" placeholder="http://127.0.0.1:..." />
                        <span className="text-white/50 text-[0.85rem] font-bold">→</span>
                        <input type="text" value={item.description} onChange={(e) => {
                            const newUrls = [...accessUrls];
                            newUrls[i].description = e.target.value;
                            setAccessUrls(newUrls);
                        }} className="glass-input flex-grow text-[0.85rem]" placeholder="Description" />
                        <button className="btn-icon shrink-0" onClick={() => {
                            setAccessUrls(accessUrls.filter((_, idx) => idx !== i));
                        }}><X size={14} /></button>
                    </div>
                ))}
                <button className="btn-secondary self-start mt-1" onClick={() => {
                    setAccessUrls([...accessUrls, { url: '', description: '' }]);
                }}>+ Add Port</button>
            </div>
        </div>

      </div>
    </div>
  );
}

