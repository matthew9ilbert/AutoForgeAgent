import React, { useState, useEffect, useMemo } from 'react';
import { toast } from '../lib/toast';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Folder, FolderOpen, FileText, FileCode, FileJson, Image, Trash2, Edit3, Download, Plus, File, Search, Cloud, CloudUpload, CloudLightning, CheckCircle2 } from 'lucide-react';

type FileNode = {
  id: string;
  name: string;
  type: 'dir' | 'file';
  size?: string;
  content?: string;
  originalContent?: string;
  language?: string;
  children?: FileNode[];
};

const initialFileSystem: FileNode[] = [
  {
    id: 'src',
    name: 'src',
    type: 'dir',
    children: [
      {
        id: 'src/components',
        name: 'components',
        type: 'dir',
        children: [
          { id: 'src/components/Dashboard.tsx', name: 'Dashboard.tsx', type: 'file', size: '2.1 KB', language: 'typescript', content: "import React from 'react';\n\nexport function Dashboard() {\n  return <h1>Dashboard</h1>;\n}", originalContent: "import React from 'react';\n\nexport function Dashboard() {\n  return <h1>Dashboard</h1>;\n}" },
          { id: 'src/components/Files.tsx', name: 'Files.tsx', type: 'file', size: '4.2 KB', language: 'typescript', content: "export function Files() {\n  // File browser implementation\n}", originalContent: "export function Files() {\n  // File browser implementation\n}" },
          { id: 'src/components/Installer.tsx', name: 'Installer.tsx', type: 'file', size: '3.5 KB', language: 'typescript', content: "import React from 'react';\n\nexport function Installer() {\n  return <div>Installer logic...</div>;\n}", originalContent: "import React from 'react';\n\nexport function Installer() {\n  return <div>Installer logic...</div>;\n}" },
          { id: 'src/components/TerminalView.tsx', name: 'TerminalView.tsx', type: 'file', size: '2.8 KB', language: 'typescript', content: "import React from 'react';\n\nexport function TerminalView() {\n  return <div>Terminal...</div>;\n}", originalContent: "import React from 'react';\n\nexport function TerminalView() {\n  return <div>Terminal...</div>;\n}" }
        ]
      },
      { id: 'src/App.tsx', name: 'App.tsx', type: 'file', size: '1.5 KB', language: 'typescript', content: "import React from \"react\";\n\nexport default function App() {\n  return <div>App</div>;\n}" },
      { id: 'src/index.css', name: 'index.css', type: 'file', size: '800 B', language: 'css', content: "@tailwind base;\n@tailwind components;\n@tailwind utilities;" },
      { id: 'src/main.tsx', name: 'main.tsx', type: 'file', size: '320 B', language: 'typescript', content: "import React from 'react';\nimport ReactDOM from 'react-dom/client';\nimport App from './App';\nimport './index.css';\n\nReactDOM.createRoot(document.getElementById('root')!).render(\n  <React.StrictMode>\n    <App />\n  </React.StrictMode>\n);" }
    ]
  },
  {
    id: 'public',
    name: 'public',
    type: 'dir',
    children: [
      { id: 'public/vite.svg', name: 'vite.svg', type: 'file', size: '1.1 KB', language: 'xml', content: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"></svg>' }
    ]
  },
  { id: 'package.json', name: 'package.json', type: 'file', size: '1.2 KB', language: 'json', content: '{\n  "name": "swarmforge",\n  "version": "1.0.0",\n  "dependencies": {\n    "react": "^18.2.0"\n  }\n}' },
  { id: 'tsconfig.json', name: 'tsconfig.json', type: 'file', size: '450 B', language: 'json', content: '{\n  "compilerOptions": {\n    "target": "ES2020",\n    "useDefineForClassFields": true,\n    "lib": ["ES2020", "DOM", "DOM.Iterable"]\n  }\n}' },
  { id: 'vite.config.ts', name: 'vite.config.ts', type: 'file', size: '200 B', language: 'typescript', content: 'import { defineConfig } from "vite";\nimport react from "@vitejs/plugin-react";\n\nexport default defineConfig({\n  plugins: [react()],\n});' },
];

export function Files() {
  const [fileSystem, setFileSystem] = useState<FileNode[]>(initialFileSystem);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set(['src', 'src/components']));
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [isDiffMode, setIsDiffMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [syncState, setSyncState] = useState<'synced' | 'syncing' | 'error'>('synced');

  const toggleDir = (id: string) => {
    const next = new Set(expandedDirs);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setExpandedDirs(next);
  };

  const getFileIcon = (name: string) => {
    if (name.endsWith('.tsx') || name.endsWith('.ts') || name.endsWith('.js')) return <FileCode size={16} className="text-[#0A84FF]" />;
    if (name.endsWith('.json')) return <FileJson size={16} className="text-[#FF9F0A]" />;
    if (name.endsWith('.css')) return <FileCode size={16} className="text-[#FF453A]" />;
    if (name.match(/\.(jpg|jpeg|png|svg|gif)$/i)) return <Image size={16} className="text-[#5E5CE6]" />;
    if (name.endsWith('.md')) return <FileText size={16} className="text-[#30D158]" />;
    return <File size={16} className="text-sf-ink opacity-60" />;
  };

  const updateFileContent = (id: string, newContent: string) => {
    setSyncState('syncing');
    
    const updateNode = (nodes: FileNode[]): FileNode[] => {
      return nodes.map(node => {
        if (node.id === id) {
          return { ...node, content: newContent };
        }
        if (node.children) {
          return { ...node, children: updateNode(node.children) };
        }
        return node;
      });
    };
    
    setFileSystem(prev => updateNode(prev));
    
    if (selectedFile && selectedFile.id === id) {
      setSelectedFile(prev => prev ? { ...prev, content: newContent } : null);
    }
    
    // Simulate auto-save delay
    setTimeout(() => {
      setSyncState('synced');
    }, 1000);
  };

  // Flatten tree for search
  const flattenedFiles = useMemo(() => {
    const result: FileNode[] = [];
    const flatten = (nodes: FileNode[]) => {
      for (const node of nodes) {
        if (node.type === 'file') {
          result.push(node);
        } else if (node.children) {
          flatten(node.children);
        }
      }
    };
    flatten(fileSystem);
    return result;
  }, [fileSystem]);

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const query = searchQuery.toLowerCase();
    return flattenedFiles.filter(f => 
      f.name.toLowerCase().includes(query) || 
      (f.content && f.content.toLowerCase().includes(query))
    );
  }, [searchQuery, flattenedFiles]);

  const renderTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map(node => {
      const isExpanded = expandedDirs.has(node.id);
      const isSelected = selectedFile?.id === node.id;
      
      return (
        <div key={node.id} className="flex flex-col">
          <div 
            className={`flex items-center gap-2 py-1.5 px-2 rounded-md cursor-pointer transition-colors select-none ${isSelected ? 'bg-sf-accent/20 text-sf-ink' : 'hover:bg-sf-border/50 text-sf-ink/80 hover:text-sf-ink'}`}
            style={{ paddingLeft: `${depth * 16 + 8}px` }}
            onClick={() => {
              if (node.type === 'dir') {
                toggleDir(node.id);
              } else {
                setSelectedFile(node);
                setSearchQuery(''); // Clear search on select
              }
            }}
          >
            {node.type === 'dir' ? (
              isExpanded ? <FolderOpen size={16} className="text-sf-accent shrink-0" /> : <Folder size={16} className="text-sf-accent shrink-0" />
            ) : (
              getFileIcon(node.name)
            )}
            <span className="text-[0.9rem] truncate">{node.name}</span>
          </div>
          {node.type === 'dir' && isExpanded && node.children && (
            <div className="flex flex-col">
              {renderTree(node.children, depth + 1)}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader
        title="Filesystem Workspace"
        subtitle="Source Code & Assets"
        actions={
          <div className="flex flex-col sm:flex-row gap-3 items-center">
            <div className={`flex items-center gap-1.5 text-[0.7rem] font-bold tracking-wider px-2.5 py-1 rounded-full border transition-all shadow-sm ${syncState === 'syncing' ? 'bg-[#FF9F0A]/20 border-[#FF9F0A]/30 text-[#FF9F0A]' : syncState === 'synced' ? 'bg-[#30D158]/20 border-[#30D158]/30 text-[#30D158]' : 'bg-[#FF453A]/20 border-[#FF453A]/30 text-[#FF453A]'}`}>
               {syncState === 'syncing' ? (
                 <><CloudUpload size={14} className="animate-pulse" /> SYNCING</>
               ) : syncState === 'synced' ? (
                 <><CheckCircle2 size={14} /> SYNCED</>
               ) : (
                 <><CloudLightning size={14} /> OFFLINE</>
               )}
            </div>
            <div className="flex gap-2 shrink-0">
              <button className="btn-icon" onClick={() => toast.info('New Folder modal opened')} title="New Folder"><Folder size={14} /></button>
              <button className="btn-secondary" onClick={() => toast.info('New File modal opened')}><Plus size={12} /><span>New File</span></button>
            </div>
          </div>
        }
      />
      <div className="w-full relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-sf-ink opacity-40" />
        <input 
          type="text" 
          placeholder="Search files & content..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="glass-input pl-10 w-full text-sm py-2.5"
        />
      </div>
      <div className="flex flex-col md:flex-row gap-4">
        <div className="card w-full md:w-[260px] lg:w-[300px] shrink-0 flex flex-col p-0 border border-sf-border h-fit">
          <div className="label shrink-0 p-4 border-b border-sf-border !mb-0 bg-sf-panel/40 backdrop-blur-md sticky top-0 flex justify-between items-center z-10">
             <span>Explorer</span>
             {searchResults && <span className="text-sf-accent bg-sf-accent/10 px-2 py-0.5 rounded-full text-[10px] font-bold">MATCHES</span>}
          </div>
          <div className="flex flex-col py-2 px-1">
            {searchResults ? (
              searchResults.length > 0 ? (
                searchResults.map(file => (
                  <div 
                    key={file.id} 
                    className="flex items-center gap-3 py-2 px-3 rounded-xl cursor-pointer transition-colors hover:bg-sf-border/30 text-sf-ink/80 hover:text-sf-ink active:scale-[0.98] mx-1 my-0.5"
                    onClick={() => {
                      setSelectedFile(file);
                    }}
                  >
                    {getFileIcon(file.name)}
                    <div className="flex flex-col overflow-hidden">
                      <span className="text-[0.9rem] truncate text-sf-ink font-semibold tracking-tight">{file.name}</span>
                      <span className="text-[0.65rem] truncate opacity-50 font-mono mt-0.5">{file.id}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-sm opacity-50 italic">No files found matching "{searchQuery}"</div>
              )
            ) : (
              renderTree(fileSystem)
            )}
          </div>
        </div>

        <div className="card flex-grow flex flex-col min-w-0 p-0 bg-[#000000]/40 backdrop-blur-3xl shadow-lg border border-sf-border min-h-[500px]">
          {selectedFile ? (
            <>
              <div className="flex items-center justify-between border-b border-sf-border p-4 shrink-0 bg-sf-panel/40 backdrop-blur-md sticky top-0 z-10">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="shrink-0 p-2 bg-sf-border/30 rounded-lg">{getFileIcon(selectedFile.name)}</div>
                  <div className="min-w-0 flex items-center gap-3">
                    <div className="font-semibold truncate text-[0.95rem] tracking-tight">{selectedFile.name}</div>
                    <div className="text-[0.7rem] font-mono opacity-50 px-2 py-0.5 bg-sf-border/50 rounded-md hidden sm:block uppercase tracking-wider">{selectedFile.size || '--'}</div>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button className={`!px-2 !py-1 !text-[0.75rem] border rounded-lg transition-all shadow-sm active:scale-95 font-bold ${isDiffMode ? 'bg-sf-accent/20 border-sf-accent/50 text-sf-accent' : 'bg-white/5 hover:bg-white/15 border-white/5 text-sf-ink/80 hover:text-sf-ink'}`} onClick={() => setIsDiffMode(!isDiffMode)} title="Toggle Diff View">Diff</button>
                  <button className="btn-icon" onClick={() => toast.info(`File modifications will be saved to ${selectedFile.name}`)} title="Edit"><Edit3 size={14} /></button>
                  <button className="btn-icon" onClick={() => toast.info(`Downloading ${selectedFile.name}`)} title="Download"><Download size={14} /></button>
                  <button className="btn-icon !bg-[#FF453A]/10 hover:!bg-[#FF453A]/20 !border-[#FF453A]/20 !text-[#FF453A] ml-2" onClick={() => toast.error(`Confirm deletion of ${selectedFile.name}`)} title="Delete"><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="flex-grow overflow-hidden flex relative group">
                <button className="absolute top-4 right-4 btn-icon z-10 opacity-0 group-hover:opacity-100 bg-sf-panel/80 hover:bg-sf-panel backdrop-blur-md" onClick={() => toast.success('Copied to clipboard')} title="Copy content"><FileText size={14} /></button>
                {isDiffMode ? (
                  <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-sf-border">
                    <div className="flex-1 p-4 md:p-6 bg-[#ef4444]/[0.02] relative overflow-y-auto">
                      <div className="absolute top-0 right-0 bg-[#ef4444]/20 text-[#ef4444] text-[0.65rem] uppercase tracking-wider font-bold px-3 py-1.5 rounded-bl-xl backdrop-blur-md">Original</div>
                      <textarea 
                        className="w-full h-full bg-transparent text-sf-ink/80 font-mono text-[0.85rem] resize-none outline-none leading-relaxed"
                        value={selectedFile.originalContent ?? ''}
                        readOnly
                        spellCheck={false}
                      />
                    </div>
                    <div className="flex-1 p-4 md:p-6 bg-[#30D158]/[0.02] relative overflow-y-auto">
                      <div className="absolute top-0 right-0 bg-[#30D158]/20 text-[#30D158] text-[0.65rem] uppercase tracking-wider font-bold px-3 py-1.5 rounded-bl-xl backdrop-blur-md">Current</div>
                      <textarea 
                        className="w-full h-full bg-transparent text-sf-ink font-mono text-[0.85rem] resize-none outline-none leading-relaxed"
                        value={selectedFile.content ?? ''}
                        onChange={(e) => updateFileContent(selectedFile.id, e.target.value)}
                        spellCheck={false}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-full p-4 md:p-6 overflow-y-auto bg-black/10">
                    <textarea 
                      className="w-full h-full min-h-[300px] bg-transparent text-sf-ink font-mono text-[0.85rem] resize-none outline-none leading-relaxed"
                      value={selectedFile.content ?? ''}
                      onChange={(e) => updateFileContent(selectedFile.id, e.target.value)}
                      spellCheck={false}
                    />
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex-grow flex flex-col items-center justify-center text-center opacity-40">
              <div className="bg-white/5 p-6 rounded-3xl mb-4">
                <FileCode size={48} className="text-sf-ink" strokeWidth={1.5} />
              </div>
              <div className="font-semibold text-lg tracking-tight">No file selected</div>
              <div className="text-[0.85rem] mt-2 max-w-[200px] opacity-70">Select a file from the explorer to preview its contents</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
