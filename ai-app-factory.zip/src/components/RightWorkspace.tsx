import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useLocation } from 'react-router';
import Editor from '@monaco-editor/react';
import { Files } from './Files';
import { TerminalView } from './TerminalView';
import { Layout, Code, MonitorPlay, Palette, Terminal as TerminalIcon } from 'lucide-react';

export function RightWorkspace() {
  const [activeTab, setActiveTab] = useState('code');
  const location = useLocation();
  const isDashboard = location.pathname === '/';
  
  const [terminalHeight, setTerminalHeight] = useState(350);
  const [isTerminalOpen, setIsTerminalOpen] = useState(true);
  const isDragging = useRef(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    document.body.style.cursor = 'row-resize';
    document.body.style.userSelect = 'none';
  };

  const handleMouseUp = useCallback(() => {
    if (isDragging.current) {
      isDragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging.current) return;
    
    // Calculate new height from bottom of window
    const newHeight = window.innerHeight - e.clientY;
    
    // Constrain height
    if (newHeight >= 100 && newHeight <= window.innerHeight - 150) {
      setTerminalHeight(newHeight);
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  const actualTerminalHeight = isDashboard ? terminalHeight : 36;

  return (
    <div className="flex-grow h-full flex flex-col overflow-hidden relative bg-sf-bg">
      <div className="h-[52px] shrink-0 border-b border-sf-border flex items-center justify-center px-4 bg-sf-panel/80 backdrop-blur-xl z-20 overflow-x-auto whitespace-nowrap scrollbar-hide">
        <div className="flex p-1 bg-black/40 rounded-xl w-full max-w-[400px] border border-white/5 shadow-inner">
          <Tab id="files" active={activeTab === 'files'} onClick={() => setActiveTab('files')} icon={<Layout size={14} />} label="Files" />
          <Tab id="code" active={activeTab === 'code'} onClick={() => setActiveTab('code')} icon={<Code size={14} />} label="Code" />
          <Tab id="preview" active={activeTab === 'preview'} onClick={() => setActiveTab('preview')} icon={<MonitorPlay size={14} />} label="Preview" />
          <Tab id="canvas" active={activeTab === 'canvas'} onClick={() => setActiveTab('canvas')} icon={<Palette size={14} />} label="Canvas" />
        </div>
        <div className="absolute right-4">
          <button 
            onClick={() => setIsTerminalOpen(!isTerminalOpen)}
            className={`p-1.5 rounded-lg transition-colors ${isTerminalOpen ? 'text-sf-accent bg-sf-accent/10' : 'text-white/50 hover:bg-white/5'}`}
            title="Toggle Terminal"
          >
            <TerminalIcon size={16} />
          </button>
        </div>
      </div>
      
      <div className="flex-grow overflow-hidden relative">
        {activeTab === 'files' && (
          <div className="absolute inset-0 p-4 overflow-y-auto">
            <Files />
          </div>
        )}
        
        {activeTab === 'code' && (
          <div className="absolute inset-0 flex flex-col">
            <div className="flex-grow bg-[#1e1e1e] relative overflow-hidden">
               <Editor 
                  height="100%" 
                  defaultLanguage="typescript" 
                  theme="vs-dark"
                  defaultValue="// Select a file or start typing...\n\nexport function App() {\n  return <div>Hello World</div>;\n}\n"
                  options={{
                    minimap: { enabled: false },
                    fontSize: 13,
                    fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                    padding: { top: 16 },
                    scrollBeyondLastLine: false,
                    smoothScrolling: true,
                    cursorBlinking: "smooth",
                    cursorSmoothCaretAnimation: "on",
                    formatOnPaste: true,
                  }}
               />
            </div>
            
            {/* Terminal Resizer */}
            {isDashboard && isTerminalOpen && (
              <div 
                className="h-[3px] cursor-row-resize bg-sf-border hover:bg-sf-accent active:bg-sf-accent z-30 shrink-0 transition-colors relative"
                onMouseDown={handleMouseDown}
              >
                 <div className="absolute inset-x-0 -top-2 -bottom-2"></div>
              </div>
            )}
            
            {/* Terminal Drawer at the bottom */}
            {isTerminalOpen && (
              <div 
                style={{ height: `${actualTerminalHeight}px` }}
                className={`shrink-0 border-t border-sf-border shadow-[0_-10px_30px_rgba(0,0,0,0.5)] z-10 relative overflow-hidden transition-all duration-300`}
              >
                  <TerminalView minimized={!isDashboard} />
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'preview' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-sf-ink/40 font-mono text-sm bg-black/40">
             <MonitorPlay size={48} className="mb-4 opacity-20" />
             <p>Live Preview Offline</p>
             <p className="text-[0.65rem] mt-2 opacity-50 uppercase tracking-wider">Awaiting Build</p>
          </div>
        )}
        
        {activeTab === 'canvas' && (
          <div className="absolute inset-0 flex bg-[#0f172a] relative overflow-hidden">
             <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
             
             {/* Canvas Toolbar */}
             <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex gap-2 p-1.5 bg-black/80 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl">
                 <button className="px-3 py-1.5 text-xs font-bold rounded-lg bg-sf-accent text-white shadow-[0_0_10px_rgba(10,132,255,0.4)]">Select</button>
                 <button className="px-3 py-1.5 text-xs font-bold rounded-lg text-white/70 hover:bg-white/10 transition-colors">Layout</button>
                 <button className="px-3 py-1.5 text-xs font-bold rounded-lg text-white/70 hover:bg-white/10 transition-colors">Components</button>
             </div>
             
             {/* UI Properties Panel */}
             <div className="absolute top-0 right-0 bottom-0 w-64 bg-sf-panel border-l border-sf-border z-10 flex flex-col shadow-2xl transform transition-transform">
                 <div className="p-4 border-b border-sf-border font-bold text-sm flex items-center justify-between">
                     <span>Properties</span>
                     <span className="text-[0.65rem] bg-[#30D158]/20 text-[#30D158] px-1.5 py-0.5 rounded uppercase tracking-wider">Sync Active</span>
                 </div>
                 <div className="p-4 flex flex-col gap-4 text-sm opacity-80">
                     <div className="flex flex-col gap-1.5">
                         <label className="text-xs font-bold opacity-50 uppercase tracking-wider">Padding</label>
                         <input type="text" value="p-6" readOnly className="bg-black/20 border border-sf-border rounded p-1.5 font-mono text-xs" />
                     </div>
                     <div className="flex flex-col gap-1.5">
                         <label className="text-xs font-bold opacity-50 uppercase tracking-wider">Background</label>
                         <input type="text" value="bg-sf-bg" readOnly className="bg-black/20 border border-sf-border rounded p-1.5 font-mono text-xs" />
                     </div>
                     <p className="text-[0.75rem] opacity-50 mt-4 leading-relaxed">
                         Bi-directional sync enabled. Visual tweaks instantly update <span className="font-mono text-sf-accent">App.tsx</span>.
                     </p>
                 </div>
             </div>
             
             {/* Center Canvas Area with simulated component */}
             <div className="absolute inset-0 right-64 flex items-center justify-center p-8 z-0">
                 <div className="border border-sf-accent border-dashed p-1 w-full max-w-sm relative group cursor-pointer hover:bg-sf-accent/5 transition-colors">
                     <div className="absolute -top-6 left-0 bg-sf-accent text-white text-[0.65rem] font-bold px-2 py-0.5 rounded-t font-mono">AppContainer (div)</div>
                     
                     <div className="bg-sf-bg border border-sf-border rounded-xl p-6 shadow-2xl flex flex-col items-center gap-4 relative">
                          {/* Selection Box Simulation */}
                          <div className="absolute inset-0 border-2 border-[#30D158] opacity-0 group-hover:opacity-100 transition-opacity rounded-xl pointer-events-none"></div>
                          <div className="absolute -top-3 -right-3 opacity-0 group-hover:opacity-100 transition-opacity bg-[#30D158] text-white p-1 rounded-full shadow-lg pointer-events-none"><Palette size={12}/></div>
                          
                          <div className="h-12 w-12 rounded-full bg-sf-accent/20 flex items-center justify-center text-sf-accent"><Layout size={20}/></div>
                          <div className="text-center">
                              <h3 className="font-bold text-lg mb-1">Generated Component</h3>
                              <p className="text-[0.8rem] opacity-60">Try dragging me or changing my padding in the inspector.</p>
                          </div>
                          <button className="btn-primary w-full justify-center">Test Button</button>
                     </div>
                 </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Tab({ id, active, onClick, icon, label }: any) {
  return (
    <button 
      onClick={onClick}
      className={`flex-1 py-2 px-3 text-[0.85rem] font-semibold flex items-center justify-center gap-1.5 transition-all rounded-lg ${
        active 
        ? 'bg-sf-border/30 text-white shadow-sm' 
        : 'text-white/50 hover:bg-white/5 hover:text-white/80'
      }`}
    >
      <span className="opacity-70">{icon}</span>
      <span className="whitespace-nowrap">{label}</span>
    </button>
  );
}

