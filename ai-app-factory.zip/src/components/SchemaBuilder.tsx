import React, { useCallback } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Database, Plus, Play, Download, Save, Link as LinkIcon, AlertCircle, Code } from 'lucide-react';
import { ReactFlow, MiniMap, Controls, Background, useNodesState, useEdgesState, addEdge, Node, Edge, Connection, Position, MarkerType } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { toast } from '../lib/toast';

const initialNodes: Node[] = [
  {
    id: 'users',
    type: 'default',
    data: { label: (
      <div className="flex flex-col text-left p-1">
        <div className="font-bold text-[#f59e0b] text-sm flex items-center gap-1.5 border-b border-white/10 pb-1 mb-1.5"><Database size={12}/> users</div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">id</span> <span className="opacity-50">uuid</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">email</span> <span className="opacity-50">varchar(255)</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">created_at</span> <span className="opacity-50">timestamp</span></div>
      </div>
    ) },
    position: { x: 250, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #334155', borderRadius: '12px', minWidth: '150px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'posts',
    type: 'default',
    data: { label: (
      <div className="flex flex-col text-left p-1">
        <div className="font-bold text-[#f59e0b] text-sm flex items-center gap-1.5 border-b border-white/10 pb-1 mb-1.5"><Database size={12}/> posts</div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">id</span> <span className="opacity-50">uuid</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">user_id</span> <span className="text-[#f59e0b]">uuid (fk)</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">title</span> <span className="opacity-50">varchar(255)</span></div>
        <div className="text-[0.65rem] opacity-80 flex justify-between"><span className="text-[#38bdf8]">content</span> <span className="opacity-50">text</span></div>
      </div>
    ) },
    position: { x: 600, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #334155', borderRadius: '12px', minWidth: '150px' },
    sourcePosition: Position.Left,
    targetPosition: Position.Right,
  },
];

const initialEdges: Edge[] = [
  { 
    id: 'e-users-posts', 
    source: 'users', 
    target: 'posts', 
    animated: true,
    style: { stroke: '#f59e0b', strokeWidth: 2 },
    markerEnd: { type: MarkerType.ArrowClosed, color: '#f59e0b' }
  },
];

export function SchemaBuilder() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection | Edge) => setEdges((eds: Edge[]) => addEdge({ ...params, animated: true, style: { stroke: '#38bdf8', strokeWidth: 2 }, markerEnd: { type: MarkerType.ArrowClosed, color: '#38bdf8' } } as Edge, eds)),
    [setEdges]
  );

  const handleGenerateCode = () => {
    toast.success('Generated Drizzle schema.ts and copied to clipboard.');
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Schema Architect" 
        subtitle="Visual drag-and-drop database modeling (PostgreSQL / Drizzle)"
        actions={
          <>
            <button className="btn-secondary" onClick={() => toast.info('Adding new table...')}>
              <Plus size={14} /> New Table
            </button>
            <button className="btn-primary" onClick={handleGenerateCode}>
              <Code size={14} /> Generate schema.ts
            </button>
          </>
        }
      />

      <div className="card flex-grow p-0 overflow-hidden relative shadow-inner bg-[#0f172a]">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          fitView
          className="dark"
        >
          <Background color="#334155" gap={24} size={2} />
          <Controls className="!bg-[#1e293b] !border-[#334155] !fill-white" />
        </ReactFlow>
        
        <div className="absolute bottom-4 left-4 z-10 bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-3 flex flex-col gap-1.5 shadow-xl">
           <div className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50 flex items-center gap-1.5"><Database size={12}/> Engine Status</div>
           <div className="text-sm font-bold text-white flex items-center gap-2">
             <span className="relative flex h-2 w-2">
               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sf-accent opacity-75"></span>
               <span className="relative inline-flex rounded-full h-2 w-2 bg-sf-accent"></span>
             </span>
             PostgreSQL Driver Loaded
           </div>
           <div className="text-[0.75rem] opacity-70 mt-1">Ready to auto-sync with Drizzle ORM.</div>
        </div>
      </div>
    </div>
  );
}
