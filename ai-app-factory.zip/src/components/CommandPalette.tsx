import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router';
import { Search, File, Layout, Users, Settings, Database, Lightbulb, Terminal, ArrowRight } from 'lucide-react';

export function CommandPalette() {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    } else {
      setSearch('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const items = [
    { id: 'home', label: 'AI Workspace', icon: <Layout size={16} />, path: '/' },
    { id: 'agents', label: 'Agents', icon: <Users size={16} />, path: '/agents' },
    { id: 'schema', label: 'Schema Builder', icon: <Database size={16} />, path: '/schema' },
    { id: 'archive', label: 'Archive', icon: <Database size={16} />, path: '/archive' },
    { id: 'ideas', label: 'Ideation', icon: <Lightbulb size={16} />, path: '/ideas' },
    { id: 'settings', label: 'Settings', icon: <Settings size={16} />, path: '/settings' },
  ];

  const filteredItems = items.filter(item => item.label.toLowerCase().includes(search.toLowerCase()));

  const handleSelect = (path: string) => {
    navigate(path);
    setIsOpen(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-32 bg-black/50 backdrop-blur-sm" onClick={() => setIsOpen(false)}>
      <div 
        className="w-full max-w-xl bg-[#0f172a] border border-sf-border shadow-2xl rounded-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center px-4 py-3 border-b border-sf-border">
          <Search size={20} className="text-white/50 mr-3" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search commands, files, or settings..."
            className="w-full bg-transparent border-none outline-none text-white font-medium text-lg placeholder-white/30"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="flex gap-1 text-[0.6rem] font-bold text-white/40 uppercase tracking-wider">
            <span className="bg-white/10 px-1.5 py-0.5 rounded border border-white/5">ESC</span>
          </div>
        </div>
        
        <div className="flex flex-col max-h-[400px] overflow-y-auto p-2">
          {filteredItems.length === 0 ? (
            <div className="p-8 text-center text-white/50 text-sm">No results found for "{search}"</div>
          ) : (
            <>
              <div className="text-[0.65rem] font-bold text-white/40 uppercase tracking-wider px-3 py-2">Workspaces & Views</div>
              {filteredItems.map((item, i) => (
                <button
                  key={item.id}
                  className="flex items-center justify-between w-full p-3 hover:bg-white/5 rounded-xl transition-colors text-left group"
                  onClick={() => handleSelect(item.path)}
                >
                  <div className="flex items-center gap-3">
                    <div className="bg-sf-bg border border-white/5 p-2 rounded-lg text-white/60 group-hover:text-sf-accent transition-colors">
                      {item.icon}
                    </div>
                    <span className="font-semibold text-sm">{item.label}</span>
                  </div>
                  <ArrowRight size={14} className="text-white/30 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </>
          )}
        </div>
        
        <div className="px-4 py-3 border-t border-sf-border bg-black/20 flex items-center justify-between text-[0.7rem] text-white/40 font-medium">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5"><span className="bg-white/10 px-1 py-0.5 rounded">↑</span><span className="bg-white/10 px-1 py-0.5 rounded">↓</span> to navigate</span>
            <span className="flex items-center gap-1.5"><span className="bg-white/10 px-1.5 py-0.5 rounded">↵</span> to select</span>
          </div>
        </div>
      </div>
    </div>
  );
}
