import React from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { ShieldAlert, Package, ArrowRight, Zap, CheckCircle2 } from 'lucide-react';

export function Auditing() {
  const dependencies = [
    { name: 'moment', version: '2.29.4', status: 'warning', issue: 'High bundle size (288kB).', suggestion: 'date-fns', impact: '-260kB' },
    { name: 'lodash', version: '4.17.21', status: 'warning', issue: 'Full library imported.', suggestion: 'lodash-es', impact: 'Tree-shakable' },
    { name: 'react-router', version: '6.22.0', status: 'good', issue: null },
    { name: 'axios', version: '0.21.1', status: 'danger', issue: 'CVE-2023-45811 (SSRF vulnerability)', suggestion: 'v1.6.0', impact: 'Security Patch' }
  ];

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Dependency Intelligence" 
        subtitle="Security Audits & Bundle Optimization"
      />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-2">
          <div className="card border-t-2 border-t-[#30D158]">
              <div className="text-[0.7rem] uppercase font-bold opacity-60 mb-1">Bundle Health</div>
              <div className="text-2xl font-bold flex items-end gap-2">94<span className="text-sm opacity-50 mb-1">/100</span></div>
          </div>
          <div className="card border-t-2 border-t-[#FF453A]">
              <div className="text-[0.7rem] uppercase font-bold opacity-60 mb-1">Vulnerabilities</div>
              <div className="text-2xl font-bold flex items-end gap-2 text-[#FF453A]">1<span className="text-sm opacity-50 text-white mb-1">Critical</span></div>
          </div>
          <div className="card border-t-2 border-t-sf-accent">
              <div className="text-[0.7rem] uppercase font-bold opacity-60 mb-1">Potential Savings</div>
              <div className="text-2xl font-bold flex items-end gap-2 text-sf-accent">~310<span className="text-sm opacity-50 text-white mb-1">kB</span></div>
          </div>
      </div>

      <div className="card flex-1 flex flex-col min-h-0">
          <div className="label mb-4 flex justify-between items-center">
              <span>Package Audit Report</span>
              <button className="btn-primary !py-1.5 !px-3 text-xs">Auto-Fix All Issues</button>
          </div>
          
          <div className="flex flex-col gap-3 overflow-y-auto pr-2">
              {dependencies.map((dep, i) => (
                  <div key={i} className="p-4 rounded-xl border border-sf-border bg-sf-bg/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                              dep.status === 'danger' ? 'bg-[#FF453A]/10 text-[#FF453A]' : 
                              dep.status === 'warning' ? 'bg-[#FF9F0A]/10 text-[#FF9F0A]' : 
                              'bg-[#30D158]/10 text-[#30D158]'
                          }`}>
                              {dep.status === 'danger' ? <ShieldAlert size={20} /> : dep.status === 'warning' ? <Zap size={20} /> : <CheckCircle2 size={20} />}
                          </div>
                          <div>
                              <div className="font-bold">{dep.name} <span className="opacity-50 text-xs font-mono ml-2">v{dep.version}</span></div>
                              {dep.issue && <div className="text-sm opacity-70 mt-1">{dep.issue}</div>}
                          </div>
                      </div>
                      
                      {dep.suggestion && (
                          <div className="flex items-center gap-3 bg-black/20 p-2 px-4 rounded-lg border border-white/5">
                              <span className="text-sm opacity-60 line-through">{dep.name}</span>
                              <ArrowRight size={14} className="opacity-40" />
                              <span className="text-sm font-bold text-sf-accent">{dep.suggestion}</span>
                              <span className="text-xs bg-sf-accent/20 text-sf-accent px-2 py-0.5 rounded ml-2">{dep.impact}</span>
                              <button className="btn-secondary !p-1.5 ml-2"><CheckCircle2 size={14} /></button>
                          </div>
                      )}
                  </div>
              ))}
          </div>
      </div>
    </div>
  );
}
