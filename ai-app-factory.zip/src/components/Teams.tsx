import React, { useState, useCallback } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Network, Plus, ShieldAlert, Code2, Play, Save, Settings2 } from 'lucide-react';
import { ReactFlow, MiniMap, Controls, Background, useNodesState, useEdgesState, addEdge, Node, Edge, Connection, Position, MarkerType } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { toast } from '../lib/toast';

const initialNodes: Node[] = [
  {
    id: 'input',
    type: 'input',
    data: { label: (
      <div className="flex flex-col items-center p-2">
        <div className="font-bold text-[0.8rem]">Code Generator</div>
        <div className="text-[0.65rem] opacity-70">Model: GPT-4-Turbo</div>
      </div>
    ) },
    position: { x: 50, y: 150 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #a855f7', borderRadius: '12px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'headless',
    type: 'default',
    data: { label: (
      <div className="flex flex-col items-center p-2 gap-2">
        <Play size={24} className="text-[#38bdf8]" />
        <div className="font-bold text-[0.8rem]">Headless Browser</div>
        <div className="text-[0.65rem] opacity-70">Vitest / Playwright UI</div>
      </div>
    ) },
    position: { x: 300, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #38bdf8', borderRadius: '12px', minWidth: '140px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'auditor',
    type: 'default',
    data: { label: (
      <div className="flex flex-col items-center p-2 gap-2">
        <ShieldAlert size={24} className="text-[#FF453A]" />
        <div className="font-bold text-[0.8rem]">Unit Tests</div>
        <div className="text-[0.65rem] opacity-70">Feedback Loop (ReAct)</div>
      </div>
    ) },
    position: { x: 550, y: 100 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #FF453A', borderRadius: '12px', minWidth: '140px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: 'output',
    type: 'output',
    data: { label: (
      <div className="flex flex-col items-center p-2">
        <div className="font-bold text-[0.8rem]">Pass & Deploy</div>
        <div className="text-[0.65rem] opacity-70">Execute Writes</div>
      </div>
    ) },
    position: { x: 800, y: 150 },
    style: { background: '#1e293b', color: 'white', border: '1px solid #30D158', borderRadius: '12px' },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
];

const initialEdges: Edge[] = [
  { id: 'e-in-gen', source: 'input', target: 'headless', animated: true, style: { stroke: '#a855f7' } },
  { id: 'e-gen-aud', source: 'headless', target: 'auditor', animated: true, style: { stroke: '#38bdf8' } },
  { id: 'e-aud-out', source: 'auditor', target: 'output', animated: true, style: { stroke: '#FF453A' } },
];

export function Teams() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection | Edge) => setEdges((eds: Edge[]) => addEdge({ ...params, animated: true, style: { stroke: '#30D158' } } as Edge, eds)),
    [setEdges]
  );

  const handleDeploy = () => {
    toast.success('Pipeline configuration deployed to Swarm Engine.');
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Automated CI/CD Testing Matrix & Pipeline" 
        subtitle="Visual Node Canvas for Agent Pipelines"
        actions={
          <>
            <button className="btn-secondary" onClick={() => toast.info('Node gallery opened')}>
              <Plus size={14} /> Add Agent Node
            </button>
            <button className="btn-primary" onClick={handleDeploy}>
              <Play size={14} /> Deploy Pipeline
            </button>
          </>
        }
      />

      <div className="card flex-grow p-0 overflow-hidden relative shadow-inner bg-[#0f172a]">
        <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
            <div className="bg-sf-panel border border-sf-border rounded-lg p-1.5 flex items-center shadow-lg">
                <button className="p-1.5 hover:bg-white/10 rounded-md transition-colors"><Settings2 size={16} /></button>
            </div>
            <div className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50 bg-black/50 px-2 py-1 rounded backdrop-blur-md">
                Active Pipeline: CI/CD TDD Matrix
            </div>
        </div>
        
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          fitView
          className="dark"
        >
          <Background color="#334155" gap={24} size={2} />
          <Controls className="!bg-[#1e293b] !border-[#334155] !fill-white" />
        </ReactFlow>
      </div>
    </div>
  );
}
