import React, { useEffect, useState } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Workflow, Minimize2, Maximize2, Pause, Play, AlertTriangle } from 'lucide-react';

export function Visualizer() {
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  return (
    <div className={`flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8 ${isFullscreen ? 'fixed inset-0 z-50 bg-sf-bg p-6 max-w-none' : ''}`}>
      <WorkspaceHeader 
        title="Collaboration Visualizer" 
        subtitle="Real-Time Node Graph"
        actions={
          <button className="btn-secondary flex items-center gap-2" onClick={() => setIsFullscreen(!isFullscreen)}>
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
            {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          </button>
        }
      />
      
      <div className="card flex-1 min-h-0 relative overflow-hidden bg-[#0A0A0A] flex flex-col p-0">
        <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
        
        <div className="p-4 border-b border-white/5 flex justify-between items-center bg-black/40 backdrop-blur-md relative z-10">
           <div className="flex items-center gap-4 text-xs font-mono">
               <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#30D158] animate-pulse"></span> SYSTEM HEALTH: NOMINAL</span>
               <span className="opacity-50">|</span>
               <span className="opacity-70">ACTIVE NODES: 4</span>
           </div>
           <div className="flex gap-2">
               <button className="btn-secondary !py-1 !px-2 !text-[0.7rem]"><Pause size={12} className="mr-1 inline" /> Freeze Graph</button>
           </div>
        </div>

        {/* Mock Node Graph Interface */}
        <div className="flex-1 relative">
            {/* Connection Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <path d="M 200 150 Q 300 100 450 150" fill="none" stroke="rgba(10, 132, 255, 0.4)" strokeWidth="2" strokeDasharray="4 4" className="animate-pulse" />
                <path d="M 200 150 Q 300 250 450 300" fill="none" stroke="rgba(255, 255, 255, 0.1)" strokeWidth="2" />
                <path d="M 450 150 Q 600 200 700 250" fill="none" stroke="rgba(10, 132, 255, 0.4)" strokeWidth="2" strokeDasharray="4 4" className="animate-pulse" />
            </svg>

            {/* Nodes */}
            <div className="absolute top-[120px] left-[100px] bg-sf-panel border border-sf-accent shadow-[0_0_20px_rgba(10,132,255,0.2)] p-3 rounded-xl w-48 z-10 cursor-move">
                <div className="text-[0.65rem] font-bold text-sf-accent uppercase tracking-wider mb-1">Orchestrator</div>
                <div className="font-semibold text-sm">Swarm Supervisor</div>
                <div className="mt-2 text-xs opacity-60">Delegating Task #883...</div>
            </div>

            <div className="absolute top-[120px] left-[450px] bg-sf-bg/80 backdrop-blur-md border border-sf-border p-3 rounded-xl w-48 z-10 cursor-move">
                <div className="text-[0.65rem] font-bold text-[#FF9F0A] uppercase tracking-wider mb-1 flex items-center gap-1"><Play size={10} fill="currentColor" /> Working</div>
                <div className="font-semibold text-sm">UI Artisan</div>
                <div className="mt-2 text-xs opacity-60">Building Dashboard.tsx...</div>
            </div>

            <div className="absolute top-[270px] left-[450px] bg-sf-bg/80 backdrop-blur-md border border-sf-border p-3 rounded-xl w-48 z-10 cursor-move opacity-60">
                <div className="text-[0.65rem] font-bold text-sf-ink/50 uppercase tracking-wider mb-1">Idle</div>
                <div className="font-semibold text-sm">DB Architect</div>
                <div className="mt-2 text-xs opacity-40">Waiting for assignment</div>
            </div>

            <div className="absolute top-[220px] left-[700px] bg-sf-bg/80 backdrop-blur-md border border-sf-border p-3 rounded-xl w-48 z-10 cursor-move">
                <div className="text-[0.65rem] font-bold text-[#FF453A] uppercase tracking-wider mb-1 flex items-center gap-1"><AlertTriangle size={10} /> Blocked</div>
                <div className="font-semibold text-sm">Test Sentinel</div>
                <div className="mt-2 text-xs opacity-60">Missing coverage data</div>
            </div>
        </div>
      </div>
    </div>
  );
}
