import React, { useState } from 'react';
import { toast } from '../lib/toast';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Plus, Save, Trash2, Edit2, Shield, Settings, Brain, Database, Wrench } from 'lucide-react';

interface Agent {
  id: string;
  tag: string;
  name: string;
  role: string;
  system_prompt: string;
  goals: string[];
  temperature: number;
  ai_provider: string;
  ai_model: string;
  capabilities: string[];
  permissions: string[];
  memory: string;
  tools: string[];
}

export function Agents() {
  const [agents, setAgents] = useState<Agent[]>([
    {
      id: 'uuid-1234',
      tag: '#orchestration',
      name: 'Supervisor',
      role: 'System Orchestration',
      system_prompt: 'You are the Swarm Supervisor. Coordinate tasks, manage sub-agents, and ensure structural integrity.',
      goals: ['Route tasks correctly', 'Ensure zero-ping-pong execution'],
      temperature: 0.2,
      ai_provider: 'OpenAI Core',
      ai_model: 'gpt-4-turbo',
      capabilities: ['routing', 'planning', 'json-parsing'],
      permissions: ['read_files', 'spawn_agents'],
      memory: 'mem-super-01',
      tools: ['delegate_task', 'read_directory']
    },
    {
      id: 'uuid-5678',
      tag: '#frontend',
      name: 'UI Artisan',
      role: 'React Component Generation',
      system_prompt: 'You build pixel-perfect React components using Tailwind CSS.',
      goals: ['Create responsive UIs', 'Follow aesthetic guidelines'],
      temperature: 0.7,
      ai_provider: 'Ollama',
      ai_model: 'llama3',
      capabilities: ['react', 'tailwind', 'framer-motion'],
      permissions: ['write_files'],
      memory: 'mem-ui-02',
      tools: ['file_writer']
    }
  ]);
  
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(agents[0].id);
  
  const selectedAgent = agents.find(a => a.id === selectedAgentId);

  const handleCreate = () => {
    const newAgent: Agent = {
        id: Math.random().toString(36).substr(2, 9),
        tag: '#new',
        name: 'New Agent',
        role: 'Pending Role',
        system_prompt: '',
        goals: [],
        temperature: 0.5,
        ai_provider: '',
        ai_model: '',
        capabilities: [],
        permissions: [],
        memory: '',
        tools: []
    };
    setAgents([...agents, newAgent]);
    setSelectedAgentId(newAgent.id);
  };

  const handleUpdate = (field: keyof Agent, value: any) => {
    if (!selectedAgentId) return;
    setAgents(prev => prev.map(a => a.id === selectedAgentId ? { ...a, [field]: value } : a));
  };

  const handleDelete = () => {
    if (!selectedAgentId) return;
    setAgents(prev => prev.filter(a => a.id !== selectedAgentId));
    setSelectedAgentId(null);
    toast.error('Agent node terminated.');
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
        <div className="flex justify-between items-center bg-sf-panel border border-sf-accent/30 p-4 rounded-xl mb-2 mx-6 mt-6 shadow-[0_0_20px_rgba(10,132,255,0.1)]">
        <div className="flex items-center gap-4">
            <div className="bg-sf-accent/20 p-3 rounded-lg text-sf-accent"><Wrench size={24}/></div>
            <div>
                <h3 className="font-bold text-lg">Custom Tool & API Builder</h3>
                <p className="text-[0.85rem] opacity-70">Give agents hands. Define custom webhooks, web search, or database query tools to assign directly into agent registries.</p>
            </div>
        </div>
        <button className="btn-primary" onClick={() => toast.info('Opening Custom Tool Builder')}><Plus size={14}/> Create New Tool</button>
      </div>
      <WorkspaceHeader title="Agent Directory" subtitle="Node Configuration" />
        <div className="flex flex-col md:flex-row w-full gap-6 flex-1 min-h-0">
        
      <div className="w-full md:w-[320px] shrink-0 flex flex-col gap-4">
          <div className="flex justify-between items-center px-1 mb-1">
      <span className="label !mb-0">Directory</span>
      <button className="btn-secondary" onClick={handleCreate}><Plus size={12} /> New</button>
   </div>
   <div className="card p-2 space-y-2 overflow-y-auto flex-1">
            {agents.map(agent => (
                <div 
                    key={agent.id} 
                    className={`p-4 rounded-2xl cursor-pointer transition-all border ${selectedAgentId === agent.id ? 'bg-sf-accent/10 border-sf-accent shadow-sm' : 'bg-sf-bg/50 border-sf-border hover:bg-sf-bg hover:border-sf-border/80'}`}
                    onClick={() => setSelectedAgentId(agent.id)}
                >
                    <div className="flex justify-between items-start mb-1">
                        <span className="font-semibold text-[0.95rem] tracking-tight">{agent.name}</span>
                        <span className="text-[0.65rem] font-mono opacity-60 bg-white/5 px-2 py-0.5 rounded-md">{agent.tag}</span>
                    </div>
                    <div className="text-[0.75rem] opacity-70 font-medium truncate">{agent.role}</div>
                </div>
            ))}
          </div>
      </div>

      <div className="card flex-grow flex flex-col p-0 min-w-0 overflow-hidden bg-[#000000]/40 backdrop-blur-3xl border border-sf-border">
          {selectedAgent ? (
              <>
                  <div className="p-4 border-b border-sf-border bg-sf-panel/50 backdrop-blur-md sticky top-0 z-10 flex justify-between items-center shrink-0">
                      <div className="flex items-center gap-3">
                          <div className="bg-sf-accent/20 p-2 rounded-xl text-sf-accent"><Brain size={20} /></div>
                          <div>
                              <div className="font-semibold">{selectedAgent.name} Config</div>
                              <div className="text-[0.65rem] font-mono opacity-50 uppercase tracking-wider">ID: {selectedAgent.id}</div>
                          </div>
                      </div>
                      <div className="flex gap-2">
                          <button className="btn-icon !bg-[#FF453A]/10 hover:!bg-[#FF453A]/20 !border-[#FF453A]/20 !text-[#FF453A]" onClick={handleDelete} title="Delete Agent">
                              <Trash2 size={14} />
                          </button>
                          <button className="btn-primary" onClick={() => toast.success('Agent saved to SQLite database!')}><Save size={12} /> Save</button>
                      </div>
                  </div>
                  
                  <div className="flex flex-col p-6 space-y-8 overflow-y-auto flex-1">
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="col-span-2 md:col-span-1">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Display Name</label>
                              <input type="text" value={selectedAgent.name} onChange={e => handleUpdate('name', e.target.value)} className="glass-input w-full" />
                          </div>
                          <div className="col-span-2 md:col-span-1">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Categorical Tag</label>
                              <input type="text" value={selectedAgent.tag} onChange={e => handleUpdate('tag', e.target.value)} className="glass-input w-full font-mono" placeholder="#frontend" />
                          </div>
                          
                          <div className="col-span-2">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Primary Role</label>
                              <input type="text" value={selectedAgent.role} onChange={e => handleUpdate('role', e.target.value)} className="glass-input w-full" />
                          </div>

                          <div className="col-span-2">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">System Prompt</label>
                              <textarea value={selectedAgent.system_prompt} onChange={e => handleUpdate('system_prompt', e.target.value)} className="glass-input w-full min-h-[120px] font-mono text-[0.85rem] resize-y" spellCheck={false} />
                          </div>
                          
                          <div className="col-span-2 md:col-span-1">
                              <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">Goals (comma separated)</label>
                              <textarea value={selectedAgent.goals.join(', ')} onChange={e => handleUpdate('goals', e.target.value.split(',').map(s => s.trim()))} className="glass-input w-full min-h-[80px]" />
                          </div>

                          <div className="col-span-2 md:col-span-1 flex flex-col gap-6">
                              <div>
                                  <div className="flex justify-between items-center mb-2 ml-1">
                                      <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60">Temperature</label>
                                      <span className="text-[0.75rem] font-mono text-sf-accent">{selectedAgent.temperature}</span>
                                  </div>
                                  <input type="range" min="0" max="1" step="0.1" value={selectedAgent.temperature} onChange={e => handleUpdate('temperature', parseFloat(e.target.value))} className="w-full accent-sf-accent" />
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                  <div>
                                      <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">AI Provider</label>
                                      <input type="text" value={selectedAgent.ai_provider} onChange={e => handleUpdate('ai_provider', e.target.value)} className="glass-input w-full" />
                                  </div>
                                  <div>
                                      <label className="block text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-2 ml-1">AI Model</label>
                                      <input type="text" value={selectedAgent.ai_model} onChange={e => handleUpdate('ai_model', e.target.value)} className="glass-input w-full" />
                                  </div>
                              </div>
                          </div>

                          <div className="col-span-2 grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-sf-border/50">
                              <div>
                                  <label className="flex items-center gap-2 text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-3 ml-1"><Database size={14} /> Capabilities</label>
                                  <input type="text" value={selectedAgent.capabilities.join(', ')} onChange={e => handleUpdate('capabilities', e.target.value.split(',').map(s=>s.trim()))} className="glass-input w-full text-[0.8rem]" placeholder="react, regex" />
                              </div>
                              <div>
                                  <label className="flex items-center gap-2 text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-3 ml-1"><Shield size={14} /> Permissions</label>
                                  <input type="text" value={selectedAgent.permissions.join(', ')} onChange={e => handleUpdate('permissions', e.target.value.split(',').map(s=>s.trim()))} className="glass-input w-full text-[0.8rem]" placeholder="write_files" />
                              </div>
                              <div>
                                  <label className="flex items-center gap-2 text-[0.75rem] font-bold uppercase tracking-wider opacity-60 mb-3 ml-1"><Wrench size={14} /> Tools</label>
                                  <input type="text" value={selectedAgent.tools.join(', ')} onChange={e => handleUpdate('tools', e.target.value.split(',').map(s=>s.trim()))} className="glass-input w-full text-[0.8rem]" placeholder="file_writer" />
                              </div>
                          </div>
                      </div>
                  </div>
              </>
          ) : (
              <div className="flex-grow flex flex-col items-center justify-center opacity-40">
                  <Brain size={48} className="mb-4" strokeWidth={1.5} />
                  <div className="text-lg font-semibold">No Agent Selected</div>
                  <div className="text-sm mt-1">Select an agent from the directory to configure</div>
              </div>
          )}
            </div>
    </div>
    </div>
  );
}