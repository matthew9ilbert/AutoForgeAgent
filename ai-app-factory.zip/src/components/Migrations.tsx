import React, { useState } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { DatabaseZap, Code2, ArrowRight, CheckCircle2, Play } from 'lucide-react';

export function Migrations() {
  const [prompt, setPrompt] = useState('');
  
  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="NL Schema Migrations" 
        subtitle="Natural Language Database Elovution"
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-0">
          <div className="card flex flex-col h-full">
              <div className="label text-sf-accent flex items-center gap-2"><DatabaseZap size={16} /> Migration Architect</div>
              <p className="text-sm opacity-70 mb-4 mt-2">
                  Describe schema changes in plain English. The AI will generate secure migration scripts, update the ORM (Prisma/Drizzle), and adapt the UI bindings.
              </p>
              
              <textarea 
                  className="glass-input flex-1 p-4 resize-none mb-4"
                  placeholder="e.g. Add a subscription tier to the user model, make it default to 'free', and link it to a new Payments table."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
              />
              
              <button className="btn-primary flex items-center justify-center gap-2 py-3">
                  <Play size={18} /> Generate Migration Plan
              </button>
          </div>
          
          <div className="flex flex-col gap-4">
              <div className="card border-sf-accent/30 bg-sf-panel">
                  <div className="label mb-3">Generated Migration Script</div>
                  <pre className="text-xs font-mono bg-black/50 p-4 rounded-xl overflow-x-auto text-sf-ink/80 border border-white/5">
                      <code>
{`-- CreateEnum
CREATE TYPE "Tier" AS ENUM ('free', 'pro', 'enterprise');

-- AlterTable
ALTER TABLE "User" ADD COLUMN "subscriptionTier" "Tier" NOT NULL DEFAULT 'free';

-- CreateTable
CREATE TABLE "Payment" (
    "id" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "userId" TEXT NOT NULL,
    CONSTRAINT "Payment_pkey" PRIMARY KEY ("id")
);`}
                      </code>
                  </pre>
              </div>
              
              <div className="card bg-sf-bg flex-1 flex flex-col justify-center">
                  <div className="flex flex-col gap-3">
                      <div className="flex items-center gap-3 opacity-50">
                          <CheckCircle2 size={16} />
                          <span className="text-sm">Analyzed prompt intent</span>
                      </div>
                      <div className="flex items-center gap-3 opacity-50">
                          <CheckCircle2 size={16} />
                          <span className="text-sm">Generated SQL migration (V4)</span>
                      </div>
                      <div className="flex items-center gap-3 text-sf-accent font-bold">
                          <Code2 size={16} />
                          <span className="text-sm">Pending ORM update (schema.prisma)...</span>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}
