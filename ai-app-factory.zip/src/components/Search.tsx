import React, { useState } from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Search as SearchIcon, Code, FileText, ArrowRight, Wand2 } from 'lucide-react';

export function Search() {
  const [query, setQuery] = useState('');
  
  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Semantic Code Search" 
        subtitle="AI-Powered Structural Search & Refactoring"
      />
      
      <div className="card flex flex-col gap-4">
        <div className="relative">
            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-sf-accent" size={20} />
            <input 
                type="text" 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder='Try: "Find all places we handle authentication errors"' 
                className="glass-input w-full pl-12 pr-4 py-4 text-lg bg-sf-bg/50 border-sf-accent/30 focus:border-sf-accent"
            />
            <button className="absolute right-3 top-1/2 -translate-y-1/2 btn-primary !py-2 !px-4 text-sm flex items-center gap-2">
                <Wand2 size={16} /> Semantic Search
            </button>
        </div>
        
        <div className="flex gap-2">
            <span className="text-xs font-bold text-sf-ink/40 uppercase tracking-wider mt-1">Suggested:</span>
            <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs cursor-pointer hover:bg-white/10 transition-colors">"Update deprecated API endpoints"</span>
                <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs cursor-pointer hover:bg-white/10 transition-colors">"Extract inline styles to Tailwind"</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-0">
          <div className="card flex flex-col flex-1 overflow-hidden">
              <div className="label">Search Results (Structural Intent)</div>
              <div className="flex flex-col gap-3 mt-4 overflow-y-auto flex-1 pr-2">
                  {[1,2,3].map(i => (
                      <div key={i} className="p-4 rounded-xl border border-sf-border bg-sf-bg/30">
                          <div className="flex items-center gap-2 mb-2">
                              <FileText size={14} className="text-sf-accent" />
                              <span className="font-mono text-xs opacity-70">src/components/Auth{i}.tsx</span>
                          </div>
                          <pre className="text-[0.7rem] font-mono text-sf-ink/80 p-3 bg-black/40 rounded-lg overflow-x-auto">
                              <code>
{`try {
  await login(user);
} catch (e) {
  // Matched: Authentication Error Handling
  toast.error(e.message);
}`}
                              </code>
                          </pre>
                      </div>
                  ))}
              </div>
          </div>
          
          <div className="card flex flex-col flex-1 overflow-hidden bg-sf-panel border border-sf-accent/20">
              <div className="label text-sf-accent">Refactoring Engine</div>
              <div className="mt-4 flex-1 flex flex-col">
                  <p className="text-sm opacity-70 mb-4">Execute complex refactoring patterns simultaneously across all semantic matches.</p>
                  
                  <textarea 
                    className="glass-input flex-1 p-4 font-mono text-sm resize-none"
                    placeholder="Describe refactoring pattern... e.g. 'Standardize all auth errors to use the GlobalErrorHandler.capture() method instead of toast.'"
                  ></textarea>
                  
                  <div className="mt-4 flex justify-end gap-3">
                      <button className="btn-secondary">Preview Changes</button>
                      <button className="btn-primary">Apply Refactor</button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}
