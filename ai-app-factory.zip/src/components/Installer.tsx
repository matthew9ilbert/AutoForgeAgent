import React, { useState } from 'react';
import { toast } from '../lib/toast';
import { WorkspaceHeader } from './WorkspaceHeader';

export function Installer() {
  const [installState, setInstallState] = useState<'idle' | 'installing' | 'done'>('idle');
  const [logs, setLogs] = useState<string[]>([]);

  const handleInstall = () => {
    setInstallState('installing');
    setLogs(['Initializing ReAct Loop scaffolding...']);
    
    const steps = [
      'Connecting to Google Gemini API (via AI Studio)...',
      'Configuring secondary cognitive tasks (Pollinations.ai)...',
      'Mapping Tool Layer: list_workspace -> os.listdir()',
      'Mapping Tool Layer: read_file -> open(file, \'r\')',
      'Mapping Tool Layer: write_file -> open(file, \'w\')',
      'Mapping Tool Layer: execute_code -> exec()',
      'Initializing Autonomous Loop...',
      'Setting up Plan, Action, Observation, Verification states...',
      'Injecting System Directive...',
      'Wiring up file-system tools...',
      'Scaffolding complete. Functional baseline established.'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        const stepText = steps[currentStep];
        setLogs(prev => [...prev, stepText]);
        currentStep++;
      } else {
        clearInterval(interval);
        setInstallState('done');
        toast.success('Architecture scaffolded successfully');
      }
    }, 800);
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader title="System Installer" subtitle="Architecture Setup" />
      <div className="card flex flex-col gap-6">
        <div>
           <h2 className="text-xl font-semibold mb-2">Agentic IDE Architecture</h2>
           <p className="opacity-70 text-[0.9rem] leading-relaxed mb-6">
             Package the entire autonomous architecture into a fully updated installer. This will scaffold the ReAct (Reasoning and Acting) loop, connect the free APIs, and wire up the file-system tools automatically to provide a functional baseline.
           </p>
           
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
              <div className="bg-sf-bg border border-sf-border p-5 rounded-xl flex flex-col gap-2">
                 <div className="font-semibold text-sf-accent">1. LLM Engine</div>
                 <div className="text-sm opacity-80">Google Gemini API (via AI Studio) for complex logic and structured data output (function calling). Pollinations.ai for lightweight, zero-auth text and vision ingestion.</div>
              </div>
              <div className="bg-sf-bg border border-sf-border p-5 rounded-xl flex flex-col gap-2">
                 <div className="font-semibold text-sf-accent">3. Autonomous Loop</div>
                 <div className="text-sm opacity-80">Plan &rarr; Action (JSON tool request) &rarr; Observation (app parses/executes) &rarr; Verification (catches errors & retries).</div>
              </div>
           </div>

           <div className="mb-8">
              <div className="label">2. Tool Layer Mapping</div>
              <div className="overflow-x-auto bg-sf-bg border border-sf-border rounded-xl">
                 <table className="w-full text-left text-sm">
                    <thead className="border-b border-sf-border bg-sf-panel/50">
                       <tr>
                          <th className="p-3 font-semibold">Tool Name</th>
                          <th className="p-3 font-semibold">Action</th>
                          <th className="p-3 font-semibold">Purpose</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-sf-border opacity-80">
                       <tr>
                          <td className="p-3 font-mono text-sf-accent">list_workspace</td>
                          <td className="p-3 font-mono">os.listdir()</td>
                          <td className="p-3">Allows the AI to read your project directory.</td>
                       </tr>
                       <tr>
                          <td className="p-3 font-mono text-sf-accent">read_file</td>
                          <td className="p-3 font-mono">open(file, 'r')</td>
                          <td className="p-3">Lets the AI analyze existing code or error logs.</td>
                       </tr>
                       <tr>
                          <td className="p-3 font-mono text-sf-accent">write_file</td>
                          <td className="p-3 font-mono">open(file, 'w')</td>
                          <td className="p-3">Allows the AI to create or patch modules.</td>
                       </tr>
                       <tr>
                          <td className="p-3 font-mono text-sf-accent">execute_code</td>
                          <td className="p-3 font-mono">exec()</td>
                          <td className="p-3">Lets the AI run the script to test for crashes.</td>
                       </tr>
                    </tbody>
                 </table>
              </div>
           </div>

           {installState === 'idle' && (
             <button onClick={handleInstall} className="btn-primary w-full sm:w-auto">Initialize Installer</button>
           )}
           {installState === 'installing' && (
             <button disabled className="btn-primary opacity-50 w-full sm:w-auto flex items-center gap-2 justify-center">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                Scaffolding Architecture...
             </button>
           )}
           {installState === 'done' && (
             <button disabled className="btn-primary !bg-[#30D158] w-full sm:w-auto text-[#111]">Installed Successfully</button>
           )}
        </div>

        {logs.length > 0 && (
            <div className="mt-4 bg-sf-bg border border-sf-border rounded-xl p-5 flex-grow flex flex-col min-h-[200px]">
                <div className="label">Installation Log</div>
                <div className="font-mono text-[0.8rem] space-y-3 mt-2 opacity-80 overflow-y-auto">
                    {logs.map((log, i) => (
                        <div key={i} className="flex gap-3">
                           <span className="opacity-40">[{new Date().toLocaleTimeString('en-US', { hour12: false })}]</span>
                           <span className={log.includes('complete') ? 'text-[#30D158] font-bold' : ''}>{log}</span>
                        </div>
                    ))}
                </div>
            </div>
        )}
      </div>
    </div>
  );
}