import React, { useEffect, useState, useRef } from 'react';
import { toast } from '../lib/toast';
import { useSwarm } from '../contexts/SwarmContext';
import { ChevronUp, ChevronDown, Activity, CheckCircle2, XCircle, AlertCircle, Play, Square, Users, Settings2, Pause, FastForward } from 'lucide-react';
import { WorkspaceHeader } from './WorkspaceHeader';

export function Dashboard() {
  const { activity, launchTask } = useSwarm();
  const [prompt, setPrompt] = useState('');
  const [taskTitle, setTaskTitle] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [showAgentSelect, setShowAgentSelect] = useState(false);
  const [selectedAgents, setSelectedAgents] = useState<string[]>([]);
  const [priority, setPriority] = useState('4');

  const availableAgents = ['Swarm Supervisor', 'Core Dev', 'Test Sentinel', 'UI Artisan', 'Shield'];

  useEffect(() => {
    const now = new Date();
    const yy = String(now.getFullYear()).slice(-2);
    const MM = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const HH = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    setTaskTitle(`${yy}${MM}${dd}${HH}${mm}${ss}`);
  }, []);

  const activeTasks = [
    { id: 'task-883', name: 'DB Schema Generation', progress: 100, agent: 'Core Dev', status: 'completed' },
    { id: 'task-884', name: 'UI Component Scaffolding', progress: 40, agent: 'UI Artisan', status: 'running' },
    { id: 'task-885', name: 'Security Audit', progress: 15, agent: 'Shield', status: 'paused' },
  ];

  const handleStart = async () => {
    if (!prompt.trim()) {
      toast.error('Directive cannot be empty');
      return;
    }
    setIsRunning(true);
    setIsPaused(false);
    await launchTask(prompt, 'SYS_TASK', true, true);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
    toast.info(isPaused ? 'Resuming task execution' : 'Task execution paused');
  };

  const handleStop = () => {
    setIsRunning(false);
    setIsPaused(false);
    toast.error('Execution terminated');
  };

  const handleChangeOfPlans = () => {
    setIsRunning(false);
    setIsPaused(false);
    toast.warning('Change of Plans triggered! Forcing immediate deliverable...');
  };

  const handleCancelTask = (taskId: string) => {
    toast.error(`Cancelled task ${taskId}`);
  };

  const toggleAgent = (agent: string) => {
    setSelectedAgents(prev => prev.includes(agent) ? prev.filter(a => a !== agent) : [...prev, agent]);
  };

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
        <WorkspaceHeader title="Control Center" subtitle="SwarmForge IDE Dashboard" />
        
        {/* Task Assignment Module - Full Width */}
        <div className="card flex flex-col shrink-0">
                    <div className="label flex justify-between items-center mb-2">
                        <span>Task Assignment Module</span>
                        {isRunning && !isPaused && <span className="text-sf-accent animate-pulse font-bold tracking-widest text-[0.65rem]">● RUNNING</span>}
                        {isPaused && <span className="text-[#FF9F0A] animate-pulse font-bold tracking-widest text-[0.65rem]">● PAUSED</span>}
                    </div>
                    
                    <div className="flex flex-col gap-3 flex-grow">
                        <input
                            type="text"
                            value={taskTitle}
                            onChange={(e) => setTaskTitle(e.target.value)}
                            placeholder="Task ID"
                            className="glass-input text-sf-ink font-mono text-[0.85rem] py-2 w-full max-w-[200px] opacity-70"
                        />
                        
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Enter directive, instructions, file links..."
                            className="w-full bg-transparent text-sf-ink font-sans text-[1rem] border-none outline-none resize-none placeholder:text-sf-ink placeholder:opacity-30 flex-grow min-h-[200px]"
                            spellCheck={false}
                        />
                        
                        <div className="flex flex-wrap items-center gap-3 pt-2 mt-2 border-t border-sf-border/50">
                            <label className="flex items-center gap-2 text-[0.75rem] text-sf-ink/70 cursor-pointer hover:text-white transition-colors">
                                <input type="checkbox" className="accent-sf-accent" defaultChecked />
                                <span>Auto-optimize context</span>
                            </label>
                            <label className="flex items-center gap-2 text-[0.75rem] text-sf-ink/70 cursor-pointer hover:text-white transition-colors">
                                <input type="checkbox" className="accent-sf-accent" defaultChecked />
                                <span>Streamlined Pipeline</span>
                            </label>
                            <label className="flex items-center gap-2 text-[0.75rem] text-sf-ink/70 cursor-pointer hover:text-white transition-colors">
                                <input type="checkbox" className="accent-sf-accent" />
                                <span>Parallel execution</span>
                            </label>
                        </div>
                    </div>
                    
                    <div className="flex flex-col gap-3 mt-3 pt-3 border-t border-sf-border/50">
                        <div className="flex flex-wrap gap-3 items-center justify-between">
                            <div className="flex gap-3 items-center flex-wrap">
                                <div className="relative">
                                    <button className="btn-secondary !py-1.5 !px-3 !text-[0.8rem]" onClick={() => setShowAgentSelect(!showAgentSelect)}>
                                        <Users size={14} />
                                        <span>Assignees ({selectedAgents.length})</span>
                                        <ChevronDown size={14} className="opacity-50 ml-1" />
                                    </button>
                                    {showAgentSelect && (
                                        <div className="absolute top-full left-0 mt-2 w-[240px] bg-sf-panel/95 backdrop-blur-3xl border border-sf-border rounded-xl shadow-2xl p-2 z-50">
                                            <div className="text-[0.7rem] uppercase font-bold opacity-50 px-2 py-1 mb-1">Available Agents</div>
                                            {availableAgents.map(agent => (
                                                <label key={agent} className="flex items-center gap-2 p-2 hover:bg-white/5 rounded-lg cursor-pointer transition-colors">
                                                    <input 
                                                        type="checkbox" 
                                                        className="accent-sf-accent"
                                                        checked={selectedAgents.includes(agent)}
                                                        onChange={(e) => toggleAgent(agent)}
                                                    />
                                                    <span className="text-[0.85rem] font-medium">{agent}</span>
                                                </label>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                <div className="flex flex-wrap items-center gap-2 bg-black/20 px-3 py-1.5 rounded-xl border border-white/5">
                                    <span className="text-[0.75rem] font-bold uppercase opacity-50">Priority</span>
                                    {[{label: 'Highest', val: '1'}, {label: 'High', val: '2'}, {label: 'Normal', val: '3'}, {label: 'Low', val: '4'}].map(p => (
                                        <label key={p.val} className="flex items-center gap-1 cursor-pointer">
                                            <input type="radio" name="priority" value={p.val} checked={priority === p.val} onChange={() => setPriority(p.val)} className="accent-sf-accent" />
                                            <span className={`text-[0.8rem] font-medium ${priority === p.val ? 'text-white' : 'opacity-60'}`}>{p.val}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                        <div className="flex gap-2 justify-end mt-2 flex-wrap">
                            {!isRunning ? (
                                <button onClick={handleStart} className="btn-primary flex items-center justify-center gap-1.5">
                                    <Play size={12} className="fill-current" />
                                    Start
                                </button>
                            ) : (
                                <>
                                    <button onClick={handlePause} className="btn-secondary flex items-center justify-center gap-1.5">
                                        {isPaused ? <Play size={12} className="fill-current" /> : <Pause size={12} className="fill-current" />}
                                        {isPaused ? 'Resume' : 'Pause'}
                                    </button>
                                    <button onClick={handleStop} className="btn-secondary !bg-[#FF453A]/10 !text-[#FF453A] !border-[#FF453A]/20 hover:!bg-[#FF453A]/20 flex items-center justify-center gap-1.5">
                                        <Square size={12} className="fill-current" />
                                        Stop
                                    </button>
                                </>
                            )}
                            <button onClick={handleChangeOfPlans} className="btn-primary !bg-[#FF9F0A] hover:!bg-[#FF9F0A]/90 !shadow-[0_0_15px_rgba(255,159,10,0.3)] flex items-center justify-center gap-1.5">
                                <FastForward size={12} className="fill-current" />
                                <span className="hidden sm:inline">Change of Plans</span>
                                <span className="sm:hidden">Change</span>
                            </button>
                        </div>
                    </div>
                </div>
        
        {/* Bottom Row - Split */}
        <div className="flex flex-col md:flex-row gap-6 w-full flex-1 min-h-[600px]">
            <div className="flex flex-col w-full md:w-1/2 flex-1 min-h-0">
                <div className="card flex flex-col flex-1 overflow-hidden"><div className="label">Active Swarm Tasks</div>
                    <div className="flex flex-col space-y-3 mt-2 overflow-y-auto flex-1 pr-2">
                        <div className="flex items-center justify-between p-3 bg-sf-bg/50 rounded-2xl border border-sf-border shadow-sm">
                            <div className="flex flex-col gap-1 w-full">
                               <div className="flex justify-between items-center w-full">
                                  <span className="font-semibold text-sm">System Success Rate</span>
                                  <span className="text-sf-accent font-mono text-sm font-semibold">94.2%</span>
                               </div>
                               <div className="w-full bg-sf-border h-1.5 rounded-full mt-1 overflow-hidden">
                                  <div className="bg-sf-accent h-full w-[94.2%] rounded-full shadow-[0_0_8px_rgba(10,132,255,0.8)]"></div>
                               </div>
                            </div>
                        </div>
                        
                        {activeTasks.map(task => {
                            let statusColor = 'text-sf-accent';
                            let bgStatusColor = 'bg-sf-accent';
                            let statusText = task.status;
                            
                            if (task.status === 'running') {
                                statusColor = 'text-[#FF9F0A]';
                                bgStatusColor = 'bg-[#FF9F0A]';
                                statusText = 'processing';
                            } else if (task.status === 'paused') {
                                statusColor = 'text-[#FF453A]';
                                bgStatusColor = 'bg-[#FF453A]';
                                statusText = 'error';
                            } else if (task.status === 'completed') {
                                statusColor = 'text-[#30D158]';
                                bgStatusColor = 'bg-[#30D158]';
                                statusText = 'success';
                            }

                            return (
                            <div key={task.id} className="flex flex-col gap-2 p-3 bg-sf-bg/50 rounded-2xl border border-sf-border relative group shadow-sm transition-all hover:bg-sf-bg">
                               <div className="flex justify-between items-center">
                                  <div className="flex flex-col">
                                     <span className="font-semibold text-[0.9rem] tracking-tight">{task.name}</span>
                                     <span className="text-[0.65rem] opacity-60 font-medium mt-0.5 uppercase tracking-wider">{task.id} • {task.agent}</span>
                                  </div>
                                  <div className="flex items-center gap-3">
                                      <span className={`text-[0.65rem] font-bold uppercase tracking-wider ${statusColor}`}>{statusText}</span>
                                      
                                      {/* Circular Progress Indicator */}
                                      <div className="relative w-8 h-8 flex items-center justify-center">
                                          <svg className="w-8 h-8 transform -rotate-90" viewBox="0 0 36 36">
                                              <path
                                                  className="text-sf-border"
                                                  strokeWidth="3"
                                                  stroke="currentColor"
                                                  fill="none"
                                                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                              />
                                              <path
                                                  className={statusColor}
                                                  strokeWidth="3"
                                                  strokeDasharray={`${task.progress}, 100`}
                                                  strokeLinecap="round"
                                                  stroke="currentColor"
                                                  fill="none"
                                                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                                              />
                                          </svg>
                                          <span className="absolute text-[0.55rem] font-bold">{task.progress}%</span>
                                      </div>
                                  </div>
                               </div>
                            </div>
                        )})}
                    </div>
                </div>
            </div>
            
            <div className="flex flex-col w-full md:w-1/2 flex-1 min-h-0">
                <div className="card flex flex-col flex-1 overflow-hidden">
                    <div className="label">Swarm Event Stream</div>
                    <div className="flex flex-col space-y-2 mt-2 overflow-y-auto flex-1 font-mono text-[0.8rem] pr-2">
                        {activity.length === 0 ? (
                            <div className="text-sf-ink/40 text-center mt-4">No recent activity</div>
                        ) : (
                            activity.map(log => (
                                <div key={log.task_id + log.timestamp + Math.random()} className="flex items-start gap-3 border-b border-sf-border/50 pb-2 last:border-0 hover:bg-sf-bg/50 p-1.5 rounded transition-colors">
                                    <span className="text-sf-ink/40 shrink-0">[{log.timestamp.split('T')[1].split('.')[0]}]</span>
                                    <span className={`font-semibold shrink-0 min-w-[90px] ${log.status === 'error' ? 'text-[#ef4444]' : log.status === 'intervention' ? 'text-[#FF9F0A]' : log.status === 'completed' ? 'text-[#30D158]' : 'text-sf-accent'}`}>
                                        {log.agent}
                                    </span>
                                    <span className="text-sf-ink/90 break-words font-medium">
                                        {log.status === 'running' && log.message.startsWith('Analyzing') ? (
                                            <span className="text-[#a855f7] italic">{log.message}</span>
                                        ) : (
                                            log.message
                                        )}
                                    </span>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
}
