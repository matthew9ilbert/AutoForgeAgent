import React from 'react';

interface WorkspaceHeaderProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export function WorkspaceHeader({ title, subtitle, actions }: WorkspaceHeaderProps) {
  return (
    <div className="shrink-0 pt-0 pb-0 px-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex flex-col">
          <h1>{title}</h1>
          {subtitle && <div className="text-[0.7rem] uppercase tracking-wider font-bold opacity-50 mt-1">{subtitle}</div>}
      </div>
      {actions && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-hide shrink-0">
              {actions}
          </div>
      )}
    </div>
  );
}
