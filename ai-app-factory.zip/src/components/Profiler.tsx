import React from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { Activity, Zap, Cpu, MemoryStick, AlertTriangle } from 'lucide-react';

export function Profiler() {
  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Real-Time Performance Profiler" 
        subtitle="Continuous React Optimization"
      />
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-2">
          <div className="card">
              <div className="flex items-center gap-2 text-[0.7rem] uppercase font-bold opacity-60 mb-2"><Activity size={14} /> FPS</div>
              <div className="text-3xl font-bold text-[#30D158]">60</div>
          </div>
          <div className="card">
              <div className="flex items-center gap-2 text-[0.7rem] uppercase font-bold opacity-60 mb-2"><Cpu size={14} /> CPU TIME</div>
              <div className="text-3xl font-bold">12<span className="text-sm opacity-50 ml-1">ms</span></div>
          </div>
          <div className="card">
              <div className="flex items-center gap-2 text-[0.7rem] uppercase font-bold opacity-60 mb-2"><MemoryStick size={14} /> HEAP</div>
              <div className="text-3xl font-bold">48<span className="text-sm opacity-50 ml-1">MB</span></div>
          </div>
          <div className="card border-t-2 border-[#FF9F0A]">
              <div className="flex items-center gap-2 text-[0.7rem] uppercase font-bold opacity-60 mb-2 text-[#FF9F0A]"><AlertTriangle size={14} /> WASTED RENDERS</div>
              <div className="text-3xl font-bold text-[#FF9F0A]">14</div>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-0">
          <div className="card flex flex-col min-h-0">
              <div className="label mb-4">Flame Graph (Live)</div>
              <div className="flex-1 relative flex flex-col justify-end gap-1 p-4 bg-black/40 rounded-xl border border-white/5">
                  <div className="w-full h-8 bg-sf-accent/40 rounded flex items-center justify-center text-xs font-mono">App (34ms)</div>
                  <div className="flex gap-1 w-full h-8">
                      <div className="w-1/3 bg-[#30D158]/40 rounded flex items-center justify-center text-[0.6rem] font-mono">Sidebar (4ms)</div>
                      <div className="w-2/3 bg-[#FF9F0A]/40 rounded flex items-center justify-center text-[0.6rem] font-mono">Dashboard (28ms)</div>
                  </div>
                  <div className="flex gap-1 w-full h-8 justify-end">
                      <div className="w-1/4 bg-transparent"></div>
                      <div className="w-[41.6%] bg-[#FF453A]/40 border border-[#FF453A] rounded flex items-center justify-center text-[0.6rem] font-mono shadow-[0_0_10px_rgba(255,69,58,0.3)]">HeavyChart (22ms)</div>
                  </div>
              </div>
          </div>
          
          <div className="card flex flex-col min-h-0">
              <div className="label text-sf-accent">AI Optimization Suggestions</div>
              <div className="flex flex-col gap-3 mt-4 overflow-y-auto pr-2">
                  <div className="p-4 rounded-xl border border-sf-border bg-sf-panel">
                      <div className="flex items-center gap-2 font-bold mb-2 text-[#FF9F0A]">
                          <AlertTriangle size={16} /> Missing useCallback
                      </div>
                      <p className="text-sm opacity-70 mb-3">
                          <code className="text-sf-accent">handleDataFilter</code> in <code className="text-white">Dashboard.tsx</code> is recreated every render, causing <code className="text-white">HeavyChart</code> to re-render unnecessarily.
                      </p>
                      <button className="btn-secondary !py-1.5 text-xs w-full"><Zap size={14} className="inline mr-1" /> Apply useCallback Fix</button>
                  </div>
                  
                  <div className="p-4 rounded-xl border border-sf-border bg-sf-bg/50">
                      <div className="flex items-center gap-2 font-bold mb-2">
                          <Activity size={16} /> Code Splitting Opportunity
                      </div>
                      <p className="text-sm opacity-70 mb-3">
                          The <code className="text-white">Settings</code> module is 400kB and not needed on initial load. Consider wrapping it in <code className="text-sf-accent">React.lazy()</code>.
                      </p>
                      <button className="btn-secondary !py-1.5 text-xs w-full"><Zap size={14} className="inline mr-1" /> Auto-Implement Lazy Loading</button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
}
