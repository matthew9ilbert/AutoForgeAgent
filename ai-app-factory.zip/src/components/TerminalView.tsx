import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Terminal, Play, Package, TestTube2, Trash2, Server, Bot, Sparkles } from 'lucide-react';

export function TerminalView({ minimized = false }: { minimized?: boolean }) {
  const [history, setHistory] = useState<{type: 'cmd'|'out'|'err', text: string}[]>([
    { type: 'out', text: 'SwarmForge OS Terminal v1.0.0' },
    { type: 'out', text: 'Type "help" for a list of available commands.' }
  ]);
  
  const [serverHistory] = useState<{type: 'cmd'|'out'|'err', text: string}[]>([
    { type: 'out', text: 'Server restarting...' },
    { type: 'out', text: 'Server stopped.' },
    { type: 'out', text: 'Server started on port 3000.' },
    { type: 'out', text: 'Pre-warming 1 paths...' },
    { type: 'cmd', text: '> react-example@0.0.0 dev' },
    { type: 'cmd', text: '> tsx server.ts --port 3000 --host 0.0.0.0' },
    { type: 'out', text: 'Server running on http://localhost:3000' },
    { type: 'out', text: 'Pre-warming completed.' },
    { type: 'out', text: 'CONNECTED' },
  ]);

  const [input, setInput] = useState('');
  const [cmdHistory, setCmdHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const endRef = useRef<HTMLDivElement>(null);
  const serverEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const executeCommand = (cmd: string) => {
    if (!cmd.trim()) return;
    
    setHistory(prev => [...prev, { type: 'cmd', text: `$ ${cmd}` }]);
    setCmdHistory(prev => [...prev, cmd]);
    setHistoryIndex(-1);
    
    setTimeout(() => {
      if (cmd === 'help') {
        setHistory(prev => [...prev, { type: 'out', text: 'Available commands:\n  help    - Show this message\n  clear   - Clear terminal output\n  ls      - List directory contents\n  npm     - Node package manager\n  git     - Source control\n  node    - Run Node.js' }]);
      } else if (cmd === 'clear') {
        setHistory([]);
      } else if (cmd.startsWith('npm')) {
        setHistory(prev => [...prev, { type: 'out', text: `> Running ${cmd}...\n> Completed successfully in 1.2s` }]);
      } else {
        const errorText = `bash: ${cmd.split(' ')[0]}: command not found`;
        setHistory(prev => [...prev, { type: 'err', text: errorText }]);
        
        // AI Assistant Auto-trigger for errors
        setTimeout(() => {
            setHistory(prev => [...prev, { type: 'out', text: `🤖 [AI Assistant] Analyzing stderr for "${cmd.split(' ')[0]}"...` }]);
            setTimeout(() => {
                setHistory(prev => [...prev, { type: 'out', text: `💡 Solution: The command '${cmd.split(' ')[0]}' is missing from the environment.\nWould you like me to install it via npm or run a specific fix? (ReAct loop engaged)` }]);
            }, 800);
        }, 400);
      }
    }, 150);
  };

  const handleCommand = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeCommand(input);
      setInput('');
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (historyIndex < cmdHistory.length - 1) {
        const nextIndex = historyIndex + 1;
        setHistoryIndex(nextIndex);
        setInput(cmdHistory[nextIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIndex = historyIndex - 1;
        setHistoryIndex(nextIndex);
        setInput(cmdHistory[nextIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInput('');
      }
    }
  };


  const [activeTab, setActiveTab] = useState<'app'|'backend'>('app');
  

  return (
    <div className="flex flex-col h-full w-full bg-[#000000]/60 relative overflow-hidden" id="terminal-container">
      {!minimized && (
        <div className="flex-grow flex flex-col relative overflow-hidden h-full">
            <div className="h-[36px] shrink-0 flex items-center justify-between px-2 overflow-x-auto whitespace-nowrap scrollbar-hide border-b border-sf-border bg-sf-panel/50 backdrop-blur-md">
                <div className="flex items-center gap-1 shrink-0">
                  <button 
                    className={`px-3 py-1.5 rounded-lg flex items-center gap-2 text-[0.7rem] uppercase tracking-wider font-bold transition-colors ${activeTab === 'app' ? 'bg-sf-accent/20 text-sf-accent' : 'text-sf-ink/50 hover:text-sf-ink hover:bg-white/5'}`}
                    onClick={() => setActiveTab('app')}
                  >
                    <Terminal size={14} />
                    App Terminal
                  </button>
                  <button 
                    className={`px-3 py-1.5 rounded-lg flex items-center gap-2 text-[0.7rem] uppercase tracking-wider font-bold transition-colors ${activeTab === 'backend' ? 'bg-[#30D158]/20 text-[#30D158]' : 'text-sf-ink/50 hover:text-sf-ink hover:bg-white/5'}`}
                    onClick={() => setActiveTab('backend')}
                  >
                    <Server size={14} />
                    Backend Logs
                  </button>
                </div>
                {activeTab === 'app' && (
                  <div className="flex gap-1 shrink-0 ml-4">
                    <button className="btn-secondary !px-2 !py-1 !text-[0.75rem] rounded-lg" onClick={() => { executeCommand('npm install'); inputRef.current?.focus(); }}>
                      <Package size={12} />
                      <span className="font-semibold hidden sm:block">Install</span>
                    </button>
                    <button className="btn-secondary !px-2 !py-1 !text-[0.75rem] rounded-lg" onClick={() => { executeCommand('npm run build'); inputRef.current?.focus(); }}>
                      <Play size={12} />
                      <span className="font-semibold hidden sm:block">Build</span>
                    </button>
                    <button className="btn-secondary !px-2 !py-1 !text-[0.75rem] rounded-lg" onClick={() => { executeCommand('npm test'); inputRef.current?.focus(); }}>
                      <TestTube2 size={12} />
                      <span className="font-semibold hidden sm:block">Test</span>
                    </button>
                    <div className="w-[1px] bg-sf-border mx-1 my-1"></div>
                    <button className="btn-icon !p-1" onClick={() => setHistory([])} title="Clear Terminal">
                      <Trash2 size={14} />
                    </button>
                  </div>
                )}
            </div>
            
            <div className="flex-grow flex flex-col p-4 relative overflow-hidden">
                {activeTab === 'app' ? (
                  <>
                    <div className="flex-1 overflow-y-auto font-mono text-[0.85rem] leading-relaxed flex flex-col space-y-1 scroll-smooth">
                      {history.map((line, i) => (
                        <div key={i} className={`whitespace-pre-wrap font-medium ${line.type === 'err' ? 'text-[#FF453A]' : line.type === 'cmd' ? 'text-white' : 'text-sf-ink/70'}`}>
                          {line.text}
                        </div>
                      ))}
                      <div ref={endRef} />
                    </div>
                    <div className="flex items-center gap-2 mt-2 pt-2 border-t border-sf-border/30 shrink-0">
                      <span className="font-mono text-sf-accent font-bold">$</span>
                      <input 
                        ref={inputRef}
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleCommand}
                        className="flex-1 bg-transparent text-white font-mono text-[0.85rem] font-medium outline-none placeholder:text-white/20"
                        spellCheck={false}
                        placeholder="Enter command..."
                        autoFocus={!minimized}
                      />
                    </div>
                  </>
                ) : (
                  <div className="flex-1 overflow-y-auto font-mono text-[0.85rem] leading-relaxed flex flex-col space-y-1 scroll-smooth">
                    {serverHistory.map((line, i) => (
                      <div key={i} className={`whitespace-pre-wrap font-medium ${line.type === 'err' ? 'text-[#FF453A]' : line.type === 'cmd' ? 'text-white' : 'text-sf-ink/50'}`}>
                        {line.text}
                      </div>
                    ))}
                    <div ref={serverEndRef} />
                  </div>
                )}
            </div>
        </div>
      )}
      
      {minimized && (
        <div className="h-[36px] shrink-0 flex items-center justify-between px-4 overflow-x-auto whitespace-nowrap scrollbar-hide border-b border-sf-border bg-sf-panel/50 backdrop-blur-md">
          <div className="flex items-center gap-2 shrink-0">
            <Terminal size={14} className="text-sf-accent" />
            <span className="text-[0.7rem] uppercase tracking-wider font-bold opacity-70">Terminal & Logs</span>
          </div>
        </div>
      )}
    </div>
  );
}

