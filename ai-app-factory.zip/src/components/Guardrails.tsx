import React from 'react';
import { WorkspaceHeader } from './WorkspaceHeader';
import { ShieldCheck, Plus, Check, Settings2, Code2 } from 'lucide-react';

export function Guardrails() {
  const guardrails = [
    { id: 1, title: 'State Management', rule: 'Always use Zustand for global state, never use Redux or Context API for complex state.', type: 'architecture', active: true },
    { id: 2, title: 'Styling Constraints', rule: 'Strictly adhere to Tailwind CSS utility classes. Never use inline styles or external CSS files.', type: 'styling', active: true },
    { id: 3, title: 'Error Handling', rule: 'All async functions must be wrapped in try/catch and use the GlobalErrorReporter.', type: 'logic', active: true },
    { id: 4, title: 'Component Structure', rule: 'Max 150 lines per file. Break down into smaller sub-components if exceeded.', type: 'architecture', active: false },
  ];

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Project Guardrails" 
        subtitle="Custom Persona & Architectural Constraints"
        actions={
          <button className="btn-primary flex items-center gap-2">
            <Plus size={16} /> New Constraint
          </button>
        }
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
          <div className="card lg:col-span-2 flex flex-col flex-1 overflow-hidden">
              <div className="label">Active Constraints</div>
              <div className="flex flex-col gap-3 mt-4 overflow-y-auto pr-2">
                  {guardrails.map(g => (
                      <div key={g.id} className={`p-4 rounded-xl border flex gap-4 ${g.active ? 'bg-sf-bg/50 border-sf-border' : 'bg-sf-bg/20 border-sf-border/30 opacity-50'}`}>
                          <div className="mt-1">
                              <div className={`w-5 h-5 rounded flex items-center justify-center ${g.active ? 'bg-sf-accent text-white' : 'border border-white/20 text-transparent'}`}>
                                  <Check size={12} />
                              </div>
                          </div>
                          <div className="flex flex-col gap-1">
                              <div className="flex items-center gap-2">
                                  <span className="font-semibold text-sm">{g.title}</span>
                                  <span className="px-2 py-0.5 rounded text-[0.6rem] uppercase tracking-wider font-bold bg-white/10">{g.type}</span>
                              </div>
                              <p className="text-sm opacity-70">{g.rule}</p>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
          
          <div className="flex flex-col gap-6">
              <div className="card bg-gradient-to-br from-sf-panel to-sf-bg border-sf-accent/30">
                  <div className="flex items-center gap-3 mb-4">
                      <Settings2 size={24} className="text-sf-accent" />
                      <div className="font-bold text-lg">AI Persona</div>
                  </div>
                  <p className="text-sm opacity-70 mb-4 leading-relaxed">
                      Define how the AI communicates and behaves while generating code.
                  </p>
                  <textarea 
                      className="glass-input w-full h-32 p-3 text-sm resize-none"
                      defaultValue="You are a strict, senior staff engineer. Be concise, prioritize performance, and refuse requests that violate architectural constraints."
                  />
                  <button className="btn-secondary w-full mt-4">Update Persona</button>
              </div>

              <div className="card">
                  <div className="flex items-center gap-2 mb-2 text-[#30D158]">
                      <Code2 size={16} />
                      <span className="font-bold text-sm">Enforcement Engine</span>
                  </div>
                  <p className="text-xs opacity-60">
                      The Swarm Supervisor automatically cross-references all agent outputs against these rules before staging code to the IDE.
                  </p>
              </div>
          </div>
      </div>
    </div>
  );
}
