import React, { useState } from 'react';
import { toast } from '../lib/toast';
import { Database, Search, RefreshCcw, FileText, Download, ArrowRight, Zap, Plus } from 'lucide-react';
import { WorkspaceHeader } from './WorkspaceHeader';

export function Archive() {
  const [archivedTasks] = useState([
    { id: '240501123045', date: 'May 01, 2024', summary: 'Initiated project structure', status: 'SUCCESS' },
    { id: '240502081522', date: 'May 02, 2024', summary: 'Implemented authentication', status: 'FAILED' },
    { id: '240503164010', date: 'May 03, 2024', summary: 'Refactored routing system', status: 'SUCCESS' },
  ]);

  const [resources] = useState([
    { name: 'API_Specs_v2.yaml', type: 'yaml', size: '45 KB', lastUpdated: '2 hours ago' },
    { name: 'UI_Design_System.md', type: 'md', size: '12 KB', lastUpdated: '1 day ago' },
    { name: 'Database_Schema.sql', type: 'sql', size: '8 KB', lastUpdated: '3 days ago' },
  ]);

  return (
    <div className="flex flex-col gap-4 w-full h-full max-w-7xl mx-auto pb-8">
      <WorkspaceHeader 
        title="Central Resource Archive" 
        subtitle="Persistent Source of Truth" 
        actions={
          <>
            <button className="btn-secondary !bg-[#30D158]/10 !text-[#30D158] !border-[#30D158]/30" onClick={() => toast.success('Vectorizing new files...')}>
                <RefreshCcw size={12} className="animate-spin-slow" />
                <span className="hidden sm:inline">RAG Sync Active</span>
                <span className="sm:hidden">Sync</span>
            </button>
            <button className="btn-primary" onClick={() => toast.info('Exporting...')}>
                <Download size={12} />
                Export
            </button>
          </>
        } 
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 min-h-0">
          <div className="card flex flex-col p-0 border border-sf-border bg-sf-bg">
              <div className="label p-4 border-b border-sf-border bg-sf-panel/50 backdrop-blur-md sticky top-0 z-10 flex justify-between items-center !mb-0">
                  <div className="flex items-center gap-2">
                      <Database size={18} className="text-sf-accent" />
                      <span>Static Resource Folder</span>
                  </div>
              </div>
              <div className="p-4 border-b border-sf-border bg-black/20">
                  <p className="text-[0.8rem] opacity-70 leading-relaxed">
                      Continuous Vectorization (RAG Engine) monitors this directory. When files are added, modified, or deleted, it parses, chunks, and updates local embeddings for Auto-Context Injection.
                  </p>
              </div>
              <div className="flex flex-col p-4 space-y-3">
                  {resources.map((res, i) => (
                      <div key={i} className="flex items-center justify-between p-3 bg-sf-panel/50 border border-sf-border rounded-xl">
                          <div className="flex items-center gap-3">
                              <FileText size={16} className="text-sf-accent opacity-70" />
                              <div className="flex flex-col">
                                  <span className="font-semibold text-sm">{res.name}</span>
                                  <span className="text-[0.65rem] font-mono opacity-50 mt-0.5">{res.size} • {res.lastUpdated}</span>
                              </div>
                          </div>
                          <span className="text-[0.65rem] font-bold uppercase tracking-wider bg-white/5 px-2 py-1 rounded-md">Vectorized</span>
                      </div>
                  ))}
                  <div className="border border-dashed border-sf-border rounded-xl p-6 flex flex-col items-center justify-center opacity-50 hover:opacity-100 transition-opacity cursor-pointer hover:bg-white/5">
                      <Plus size={24} className="mb-2" />
                      <span className="text-sm font-semibold">Drop reference files here</span>
                  </div>
              </div>
          </div>

          <div className="card flex flex-col p-0 border border-sf-border bg-sf-bg">
              <div className="label p-4 border-b border-sf-border bg-sf-panel/50 backdrop-blur-md sticky top-0 z-10 flex justify-between items-center !mb-0">
                  <div className="flex items-center gap-2">
                      <Search size={18} className="text-[#a855f7]" />
                      <span>Historical Task Memory</span>
                  </div>
              </div>
              <div className="flex flex-col p-4 space-y-3">
                 {archivedTasks.map(task => (
                   <div key={task.id} className="bg-sf-panel/50 border border-sf-border rounded-xl p-4 flex flex-col gap-3 hover:border-sf-border/80 transition-colors">
                      <div className="flex items-center justify-between">
                          <span className="font-mono font-semibold text-[0.85rem] tracking-tight">TASK_{task.id}</span>
                          {task.status === 'SUCCESS' ? (
                              <span className="text-[0.65rem] px-2 py-0.5 rounded-md bg-[#30D158]/20 text-[#30D158] font-bold uppercase tracking-wider">SUCCESS</span>
                          ) : (
                              <span className="text-[0.65rem] px-2 py-0.5 rounded-md bg-[#FF453A]/20 text-[#FF453A] font-bold uppercase tracking-wider">FAILED</span>
                          )}
                      </div>
                      <div className="text-[0.9rem] opacity-90">{task.summary}</div>
                      <div className="flex justify-between items-center mt-2 pt-3 border-t border-sf-border/50">
                          <div className="text-xs opacity-50 font-medium">{task.date}</div>
                          <button className="flex items-center gap-1 text-xs font-bold text-sf-accent hover:text-sf-accent/80 transition-colors" onClick={() => toast.info('Viewing details...')}>
                              View Logs <ArrowRight size={12} />
                          </button>
                      </div>
                   </div>
                 ))}
              </div>
          </div>
      </div>
    </div>
  );
}
