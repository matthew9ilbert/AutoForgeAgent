import React, { useState, useEffect, useRef, useCallback } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router';
import { Dashboard } from './components/Dashboard';
import { Settings } from './components/Settings';
import { SchemaBuilder } from './components/SchemaBuilder';
import { Agents } from './components/Agents';
import { Teams } from './components/Teams';
import { Archive } from './components/Archive';
import { Ideas } from './components/Ideas';
import { Testing } from './components/Testing';
import { Visualizer } from './components/Visualizer';
import { Search } from './components/Search';
import { Guardrails } from './components/Guardrails';
import { Auditing } from './components/Auditing';
import { Migrations } from './components/Migrations';
import { Profiler } from './components/Profiler';
import { Installer } from './components/Installer';
import { RightWorkspace } from './components/RightWorkspace';
import { CommandPalette } from './components/CommandPalette';
import { SwarmProvider } from './contexts/SwarmContext';
import { Toaster } from 'sonner';
import { Layers, MessageSquare, Users, Network, Database, Lightbulb, Settings as SettingsIcon, Book, DatabaseBackup, Activity, TestTube, Search as SearchIcon, ShieldCheck, DatabaseZap, Workflow, Compass } from 'lucide-react';

function ActivityBar() {
  const location = useLocation();
  const navItems = [
    { label: 'AI Workspace', path: '/', icon: <MessageSquare size={20} /> },
    { label: 'TDD Loop', path: '/testing', icon: <TestTube size={20} /> },
    { label: 'Visualizer', path: '/visualizer', icon: <Workflow size={20} /> },
    { label: 'Code Search', path: '/search', icon: <SearchIcon size={20} /> },
    { label: 'Auditing', path: '/auditing', icon: <ShieldCheck size={20} /> },
    { label: 'Migrations', path: '/migrations', icon: <DatabaseZap size={20} /> },
    { label: 'Profiler', path: '/profiler', icon: <Activity size={20} /> },
    { label: 'Guardrails', path: '/guardrails', icon: <Compass size={20} /> },
    { label: 'Agents', path: '/agents', icon: <Users size={20} /> },
    { label: 'Ideation', path: '/ideas', icon: <Lightbulb size={20} /> },
  ];
  return (
    <aside className="w-[60px] sm:w-[68px] shrink-0 h-full border-r border-sf-border bg-sf-panel flex flex-col items-center py-4 gap-4 z-20 relative safe-pl safe-pt safe-pb">
      <div className="bg-sf-accent text-white p-2.5 rounded-xl mb-4 shadow-lg shadow-sf-accent/20">
        <Layers size={22} />
      </div>
      
      <div className="flex flex-col gap-3 flex-grow justify-start w-full items-center">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              title={item.label}
              className={`p-3 rounded-xl transition-all ${
                isActive ? 'bg-sf-accent/20 text-sf-accent border border-sf-accent/30' : 'text-sf-ink/50 hover:bg-white/5 hover:text-sf-ink border border-transparent'
              }`}
            >
              {item.icon}
            </Link>
          );
        })}
      </div>
      
      <div className="mt-auto mb-2 flex flex-col items-center gap-4">
        <Link
          to="/settings"
          title="Settings"
          className={`p-3 rounded-xl transition-all ${
            location.pathname === '/settings' ? 'bg-sf-accent/20 text-sf-accent border border-sf-accent/30' : 'text-sf-ink/50 hover:bg-white/5 hover:text-sf-ink border border-transparent'
          }`}
        >
          <SettingsIcon size={20} />
        </Link>
         <div className="relative flex h-3 w-3" title="Network Online">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#30D158] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-[#30D158]"></span>
          </div>
      </div>
    </aside>
  );
}

export default function App() {
  const [leftPaneWidth, setLeftPaneWidth] = useState(420);
  const isDragging = useRef(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    isDragging.current = true;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  };

  const handleMouseUp = useCallback(() => {
    if (isDragging.current) {
      isDragging.current = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging.current) return;
    
    // Activity bar is ~60-68px wide
    const activityBarWidth = window.innerWidth >= 640 ? 68 : 60;
    const newWidth = e.clientX - activityBarWidth;
    
    // Constrain width
    if (newWidth >= 280 && newWidth <= window.innerWidth - 300) {
      setLeftPaneWidth(newWidth);
    }
  }, []);

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  const handleGlobalInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    // Dismiss keyboard on exterior tap by blurring active element if it's an input/textarea
    const target = e.target as HTMLElement;
    if (
      document.activeElement &&
      document.activeElement instanceof HTMLElement &&
      document.activeElement.tagName !== 'BODY' &&
      target.tagName !== 'INPUT' &&
      target.tagName !== 'TEXTAREA' &&
      target.tagName !== 'SELECT' &&
      !target.isContentEditable
    ) {
      document.activeElement.blur();
    }
  };

  return (
    <SwarmProvider>
      <Router>
        <CommandPalette />
        <Toaster theme="dark" position="bottom-right" toastOptions={{ className: 'backdrop-blur-xl bg-sf-panel border-sf-border text-sf-ink rounded-2xl shadow-xl' }} />
        <div 
          className="h-[100dvh] w-full flex overflow-hidden bg-sf-bg relative"
          onMouseDownCapture={handleGlobalInteraction}
          onTouchStartCapture={handleGlobalInteraction}
        >
          <ActivityBar />
          
          <div 
            className="shrink-0 h-full overflow-hidden relative flex flex-col bg-sf-bg z-10 shadow-2xl"
            style={{ width: `${leftPaneWidth}px` }}
          >
            <main className="flex flex-col overflow-y-auto overflow-x-hidden relative h-full w-full">
              <div className="flex flex-col flex-1 px-6 pb-6 pt-4 safe-pt safe-pb">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/agents" element={<Agents />} />
                <Route path="/teams" element={<Teams />} />
                <Route path="/schema" element={<SchemaBuilder />} />
                <Route path="/archive" element={<Archive />} />
                <Route path="/ideas" element={<Ideas />} />
                <Route path="/testing" element={<Testing />} />
                <Route path="/visualizer" element={<Visualizer />} />
                <Route path="/search" element={<Search />} />
                <Route path="/guardrails" element={<Guardrails />} />
                <Route path="/auditing" element={<Auditing />} />
                <Route path="/migrations" element={<Migrations />} />
                <Route path="/profiler" element={<Profiler />} />
                <Route path="/installer" element={<Installer />} />
              </Routes>
              </div>
            </main>
          </div>

          <div 
            className="w-[3px] cursor-col-resize bg-sf-border hover:bg-sf-accent active:bg-sf-accent z-30 shrink-0 transition-colors relative"
            onMouseDown={handleMouseDown}
          >
             <div className="absolute inset-y-0 -left-2 -right-2"></div>
          </div>
          
          <div className="flex-grow h-full min-w-0 relative z-0">
             <RightWorkspace />
          </div>
        </div>
      </Router>
    </SwarmProvider>
  );
}
