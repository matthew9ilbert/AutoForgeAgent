console.log("Checking UI");
