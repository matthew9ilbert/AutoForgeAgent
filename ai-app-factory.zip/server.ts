import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize SQLite database
const db = new Database('app_factory.db');
db.pragma('journal_mode = WAL');

// Define Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS prompts (
    id TEXT PRIMARY KEY,
    title TEXT,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    prompt_id TEXT,
    status TEXT,
    assigned_agent TEXT,
    logs TEXT,
    supervisor TEXT,
    framework TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (prompt_id) REFERENCES prompts(id)
  );

  CREATE TABLE IF NOT EXISTS agent_policies (
    id TEXT PRIMARY KEY,
    name TEXT,
    description TEXT,
    is_active BOOLEAN
  );

  CREATE TABLE IF NOT EXISTS user_profile (
    id TEXT PRIMARY KEY,
    habits TEXT,
    preferences TEXT,
    priorities TEXT,
    morals TEXT,
    learning_history TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pipeline_tasks (
    id TEXT PRIMARY KEY,
    title TEXT,
    description TEXT,
    priority INTEGER,
    status TEXT,
    agents TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS ideas (
    id TEXT PRIMARY KEY,
    title TEXT,
    description TEXT,
    status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  INSERT OR IGNORE INTO user_profile (id, habits, preferences, priorities, morals, learning_history)
  VALUES ('default', 
    '{"techStack":"React, TypeScript, Tailwind","codingStyle":"modular, functional","tooling":"Git, Vitest"}',
    '{"ui":"Dark mode, high contrast","communication":"concise","autonomy":"high"}',
    '{"shortTerm":"speed to prototype","longTerm":"scalable architecture"}',
    '{"security":"strict data privacy","standards":"no raw SQL","ethics":"inclusive design"}',
    '["Initial profile loaded."]'
  );
`);

// Mock Autonomous Daemon
function startAutonomousDaemon() {
  setInterval(() => {
    try {
      // Find RUNNING tasks
      const runningTasks = db.prepare("SELECT * FROM tasks WHERE status = 'RUNNING'").all();
      
      for (const task of runningTasks as any[]) {
        const updateStmt = db.prepare("UPDATE tasks SET logs = logs || ? WHERE id = ?");
        
        // Randomly simulate progress logs
        const mockLogs = [
          "\\n[Daemon] Analyzing project constraints...",
          "\\n[RoutingDirector] Assigning sub-tasks to specialized agents...",
          "\\n[Supervisor: gemini-3.5-flash] Initiating Society of Minds debate round...",
          "\\n[Deputy: qwen3:14b] Critiquing architecture proposal...",
          "\\n[Creative: gpt-5.4] Generating alternative UI paradigms...",
          "\\n[Specialist: qwen2.5-coder] Implementing core algorithms...",
          "\\n[Swarm] Reaching consensus and finalizing module..."
        ];
        
        const randomLog = mockLogs[Math.floor(Math.random() * mockLogs.length)];
        updateStmt.run(randomLog, task.id);

        // Random chance to auto-complete after some logs
        if (task.logs.length > 500 && Math.random() > 0.8) {
           const completeStmt = db.prepare("UPDATE tasks SET status = 'COMPLETED', logs = logs || ? WHERE id = ?");
           completeStmt.run("\\n[Daemon] Task fully realized. Execution successfully finalized.", task.id);
        }
      }
    } catch (e) {
      console.error("Daemon error:", e);
    }
  }, 5000);
}

startAutonomousDaemon();

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Swarm Supervisor and Daemon operational.' });
});

app.get('/api/prompts', (req, res) => {
  const prompts = db.prepare('SELECT * FROM prompts ORDER BY created_at DESC').all();
  res.json(prompts);
});

app.post('/api/prompts', (req, res) => {
  const { title, content } = req.body;
  const id = uuidv4();
  const stmt = db.prepare('INSERT INTO prompts (id, title, content) VALUES (?, ?, ?)');
  stmt.run(id, title, content);
  res.json({ id, title, content });
});

app.get('/api/tasks', (req, res) => {
  const tasks = db.prepare('SELECT * FROM tasks ORDER BY created_at DESC').all();
  res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
  const { prompt_id, supervisor, framework } = req.body;
  const id = uuidv4();
  // Simple mock of swarm supervisor assignment
  const assigned_agent = 'RoutingDirector (Swarm)';
  const stmt = db.prepare('INSERT INTO tasks (id, prompt_id, status, assigned_agent, logs, supervisor, framework) VALUES (?, ?, ?, ?, ?, ?, ?)');
  
  const initialLogs = `[System] Task dispatched to Swarm Supervisor (${supervisor}).\n[System] Framework initialized: ${framework}.\n[System] Awaiting human-in-the-loop approval before autonomous execution starts.`;
  
  stmt.run(id, prompt_id, 'QUEUED', assigned_agent, initialLogs, supervisor, framework);
  res.json({ id, prompt_id, status: 'QUEUED', assigned_agent });
});

app.post('/api/tasks/:id/approve', (req, res) => {
  const { id } = req.params;
  const stmt = db.prepare('UPDATE tasks SET status = ?, logs = logs || ? WHERE id = ?');
  stmt.run('RUNNING', '\\n[Supervisor] Gate cleared: Approval granted.\\n[Daemon] Autonomous execution started. Model: Ollama qwen2.5-coder.', id);
  res.json({ success: true, id });
});

app.post('/api/tasks/:id/fail', (req, res) => {
  const { id } = req.params;
  const stmt = db.prepare('UPDATE tasks SET status = ?, logs = logs || ? WHERE id = ?');
  stmt.run('FAILED', '\\n[Supervisor] Execution rejected by human-in-the-loop. Terminating.', id);
  res.json({ success: true, id });
});

app.post('/api/tasks/:id/complete', (req, res) => {
  const { id } = req.params;
  const stmt = db.prepare('UPDATE tasks SET status = ?, logs = logs || ? WHERE id = ?');
  stmt.run('COMPLETED', '\\n[Supervisor] Forced completion executed.', id);
  res.json({ success: true, id });
});

// Profile Routes
app.get('/api/profile', (req, res) => {
  const profile = db.prepare("SELECT * FROM user_profile WHERE id = 'default'").get();
  if (profile) {
    try {
      res.json({
        ...profile as any,
        habits: JSON.parse((profile as any).habits),
        preferences: JSON.parse((profile as any).preferences),
        priorities: JSON.parse((profile as any).priorities),
        morals: JSON.parse((profile as any).morals),
        learning_history: JSON.parse((profile as any).learning_history)
      });
    } catch (e) {
      res.json(profile);
    }
  } else {
    res.status(404).json({ error: 'Profile not found' });
  }
});

app.post('/api/profile', (req, res) => {
  const { habits, preferences, priorities, morals, learning_history } = req.body;
  const stmt = db.prepare(`
    UPDATE user_profile 
    SET habits = ?, preferences = ?, priorities = ?, morals = ?, learning_history = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = 'default'
  `);
  
  stmt.run(
    JSON.stringify(habits), 
    JSON.stringify(preferences), 
    JSON.stringify(priorities), 
    JSON.stringify(morals), 
    JSON.stringify(learning_history)
  );
  
  res.json({ success: true });
});

// Pipeline Tasks Routes
app.get('/api/pipeline-tasks', (req, res) => {
  const tasks = db.prepare('SELECT * FROM pipeline_tasks ORDER BY created_at DESC').all();
  res.json(tasks.map((t: any) => ({ ...t, agents: JSON.parse(t.agents) })));
});

app.post('/api/pipeline-tasks', (req, res) => {
  const { title, description, priority, status, agents } = req.body;
  const id = uuidv4();
  const stmt = db.prepare('INSERT INTO pipeline_tasks (id, title, description, priority, status, agents) VALUES (?, ?, ?, ?, ?, ?)');
  stmt.run(id, title, description, priority, status, JSON.stringify(agents || []));
  res.json({ id, title, description, priority, status, agents });
});

app.put('/api/pipeline-tasks/:id', (req, res) => {
  const { status } = req.body;
  const stmt = db.prepare('UPDATE pipeline_tasks SET status = ? WHERE id = ?');
  stmt.run(status, req.params.id);
  res.json({ success: true });
});

// Ideas Routes
app.get('/api/ideas', (req, res) => {
  const ideas = db.prepare('SELECT * FROM ideas ORDER BY created_at DESC').all();
  res.json(ideas);
});

app.post('/api/ideas', (req, res) => {
  const { title, description } = req.body;
  const id = uuidv4();
  const stmt = db.prepare('INSERT INTO ideas (id, title, description, status) VALUES (?, ?, ?, ?)');
  stmt.run(id, title, description, 'pending');
  res.json({ id, title, description, status: 'pending' });
});

app.delete('/api/ideas/:id', (req, res) => {
  const stmt = db.prepare('DELETE FROM ideas WHERE id = ?');
  stmt.run(req.params.id);
  res.json({ success: true });
});

// Vite middleware for development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : {
          clientPort: 443,
          protocol: 'wss',
          timeout: 120000
        }
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
